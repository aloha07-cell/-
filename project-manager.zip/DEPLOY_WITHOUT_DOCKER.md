# 项目管理系统 - 无 Docker 部署指南

## 📋 适用场景

本指南适用于以下情况：
- 无法安装 Docker 的云电脑
- 没有 Docker 权限的环境
- 希望在本地直接运行服务的开发环境

## 🚀 部署步骤

### 1. 前置条件

#### 1.1 后端依赖
- **Python 3.11+**：https://www.python.org/downloads/
- **MySQL 8.0+**：https://dev.mysql.com/downloads/mysql/
- **Redis 7.0+**：https://redis.io/download/
- **MinIO**（可选，用于文件存储）：https://min.io/download

#### 1.2 前端依赖
- **Node.js 18+**：https://nodejs.org/en/download/
- **npm 或 yarn**：Node.js 自带 npm

### 2. 安装步骤

#### 2.1 克隆项目
```bash
git clone https://github.com/aloha07-cell/-.git
cd project-manager
```

#### 2.2 后端安装

**步骤 1：创建虚拟环境**
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

**步骤 2：安装依赖**
```bash
cd backend
pip install -r requirements.txt
```

**步骤 3：配置数据库**
1. 启动 MySQL 服务
2. 创建数据库：
   ```sql
   CREATE DATABASE project_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'pm_user'@'localhost' IDENTIFIED BY 'pm123456';
   GRANT ALL PRIVILEGES ON project_manager.* TO 'pm_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

**步骤 4：配置环境变量**
复制 `.env.example` 为 `.env` 并修改配置：
```bash
# 数据库配置
DATABASE_URL=mysql+asyncmy://pm_user:pm123456@localhost:3306/project_manager

# Redis 配置
REDIS_URL=redis://localhost:6379/0

# MinIO 配置（可选）
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=project-manager

# JWT 配置
JWT_SECRET=your-secret-key-change-in-production
```

**步骤 5：数据库迁移**
```bash
alembic upgrade head
```

**步骤 6：启动后端服务**
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

#### 2.3 前端安装

**步骤 1：安装依赖**
```bash
cd ../frontend
npm install
```

**步骤 2：配置 API 地址**
修改 `vite.config.ts` 中的代理配置：
```typescript
proxy: {
  '/api': {
    target: 'http://localhost:8000',  // 后端服务地址
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/api/, '/api'),
  },
},
```

**步骤 3：构建前端**
```bash
npm run build
```

**步骤 4：启动前端开发服务器**（开发环境）
```bash
npm run dev
```

**步骤 5：部署前端**（生产环境）
将 `dist` 目录部署到 web 服务器（如 Nginx、Apache）

### 3. 服务访问

- **后端 API**：http://localhost:8000/api/v1
- **API 文档**：http://localhost:8000/api/v1/docs
- **前端**：http://localhost:3000（开发环境）或根据部署地址

### 4. 初始化数据

运行初始化脚本创建管理员账户：
```bash
cd scripts
python init-data.py
```

默认登录信息：
- 用户名：admin@example.com
- 密码：admin123

## 🔧 常见问题

### 1. 数据库连接失败
- **问题**：后端无法连接到 MySQL
- **解决方案**：
  - 确保 MySQL 服务正在运行
  - 检查 `.env` 文件中的数据库配置
  - 验证数据库用户权限

### 2. Redis 连接失败
- **问题**：后端无法连接到 Redis
- **解决方案**：
  - 确保 Redis 服务正在运行
  - 检查 `.env` 文件中的 Redis 配置

### 3. 前端无法访问后端
- **问题**：前端 API 请求失败
- **解决方案**：
  - 确保后端服务正在运行
  - 检查 CORS 配置
  - 验证前端代理配置

### 4. 端口冲突
- **问题**：服务启动失败，提示端口被占用
- **解决方案**：
  - 检查是否有其他服务占用了 8000、3000 等端口
  - 修改服务启动端口

## 📁 目录结构

```
project-manager/
├── backend/          # 后端代码
│   ├── app/          # 应用代码
│   ├── alembic/      # 数据库迁移
│   ├── requirements.txt  # 依赖文件
│   └── tests/        # 测试代码
├── frontend/         # 前端代码
│   ├── src/          # 源代码
│   ├── package.json  # 依赖配置
│   └── vite.config.ts  # 构建配置
├── scripts/          # 脚本文件
│   └── init-data.py  # 初始化数据
├── .env.example      # 环境变量示例
└── DEPLOY_WITHOUT_DOCKER.md  # 本指南
```

## 📞 技术支持

如果遇到部署问题，请联系技术支持：
- 邮箱：support@example.com
- 文档：https://docs.example.com

---

**注意**：本部署方案适用于开发和测试环境。生产环境部署时，请使用更安全的配置，如使用 HTTPS、设置强密码等。