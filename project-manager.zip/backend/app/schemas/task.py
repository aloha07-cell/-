from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field


class TaskCreate(BaseModel):
    """创建任务"""
    title: str = Field(..., min_length=1, max_length=200, description="任务标题")
    description: str = Field(default="", description="任务描述")
    project_id: int = Field(..., description="项目ID")
    parent_id: Optional[int] = Field(default=None, description="父任务ID")
    assignee_id: Optional[int] = Field(default=None, description="指派人ID")
    milestone_id: Optional[int] = Field(default=None, description="关联里程碑ID")
    priority: str = Field(default="medium", description="优先级")
    plan_start_date: Optional[date] = Field(default=None, description="计划开始日期")
    plan_end_date: Optional[date] = Field(default=None, description="计划结束日期")
    estimated_hours: float = Field(default=0.0, ge=0, description="预估工时")
    sort_order: int = Field(default=0, description="排序序号")


class TaskUpdate(BaseModel):
    """更新任务"""
    title: Optional[str] = Field(default=None, max_length=200, description="任务标题")
    description: Optional[str] = Field(default=None, description="任务描述")
    status: Optional[str] = Field(default=None, description="任务状态")
    priority: Optional[str] = Field(default=None, description="优先级")
    assignee_id: Optional[int] = Field(default=None, description="指派人ID")
    milestone_id: Optional[int] = Field(default=None, description="关联里程碑ID")
    parent_id: Optional[int] = Field(default=None, description="父任务ID")
    plan_start_date: Optional[date] = Field(default=None, description="计划开始日期")
    plan_end_date: Optional[date] = Field(default=None, description="计划结束日期")
    actual_start_date: Optional[date] = Field(default=None, description="实际开始日期")
    actual_end_date: Optional[date] = Field(default=None, description="实际结束日期")
    estimated_hours: Optional[float] = Field(default=None, ge=0, description="预估工时")
    actual_hours: Optional[float] = Field(default=None, ge=0, description="实际工时")
    progress: Optional[int] = Field(default=None, ge=0, le=100, description="进度百分比")
    sort_order: Optional[int] = Field(default=None, description="排序序号")


class TaskResponse(BaseModel):
    """任务响应"""
    id: int
    title: str
    description: str
    wbs_code: str
    status: str
    priority: str
    project_id: int
    parent_id: Optional[int] = None
    assignee_id: Optional[int] = None
    milestone_id: Optional[int] = None
    plan_start_date: Optional[date] = None
    plan_end_date: Optional[date] = None
    actual_start_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    estimated_hours: float
    actual_hours: float
    progress: int
    sort_order: int
    created_at: datetime
    updated_at: datetime
    assignee_name: str = Field(default="", description="指派人姓名")
    children_count: int = Field(default=0, description="子任务数量")

    model_config = {"from_attributes": True}


class TaskDependencyCreate(BaseModel):
    """创建任务依赖"""
    task_id: int = Field(..., description="任务ID")
    depends_on_id: int = Field(..., description="依赖任务ID")
    dependency_type: str = Field(default="finish_to_start", description="依赖类型")


class TaskDependencyResponse(BaseModel):
    """任务依赖响应"""
    id: int
    task_id: int
    depends_on_id: int
    dependency_type: str

    model_config = {"from_attributes": True}


class TaskWbsNode(BaseModel):
    """WBS树节点"""
    id: int
    title: str
    wbs_code: str
    status: str
    priority: str
    assignee_id: Optional[int] = None
    assignee_name: str = ""
    plan_start_date: Optional[date] = None
    plan_end_date: Optional[date] = None
    progress: int
    children: List["TaskWbsNode"] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class KanbanColumn(BaseModel):
    """看板列"""
    status: str
    status_label: str
    tasks: List[TaskResponse] = Field(default_factory=list)
