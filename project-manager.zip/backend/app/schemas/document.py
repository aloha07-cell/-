from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class DocumentResponse(BaseModel):
    """文档响应"""
    id: int
    project_id: int
    name: str
    file_path: str
    file_size: int
    file_type: str
    description: str
    uploaded_by: Optional[int] = None
    version: int
    created_at: datetime
    updated_at: datetime
    uploader_name: str = Field(default="", description="上传人姓名")

    model_config = {"from_attributes": True}


class DocumentUploadResponse(BaseModel):
    """文档上传响应"""
    id: int
    name: str
    file_path: str
    file_size: int
    file_type: str
    version: int
    created_at: datetime

    model_config = {"from_attributes": True}
