from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field


class ProjectCreate(BaseModel):
    """创建项目"""
    name: str = Field(..., min_length=1, max_length=200, description="项目名称")
    code: str = Field(..., min_length=1, max_length=50, description="项目编号")
    description: str = Field(default="", description="项目描述")
    start_date: Optional[date] = Field(default=None, description="计划开始日期")
    end_date: Optional[date] = Field(default=None, description="计划结束日期")
    budget: float = Field(default=0.0, ge=0, description="预算金额")
    member_ids: List[int] = Field(default_factory=list, description="初始成员用户ID列表")


class ProjectUpdate(BaseModel):
    """更新项目"""
    name: Optional[str] = Field(default=None, max_length=200, description="项目名称")
    description: Optional[str] = Field(default=None, description="项目描述")
    status: Optional[str] = Field(default=None, description="项目状态")
    start_date: Optional[date] = Field(default=None, description="计划开始日期")
    end_date: Optional[date] = Field(default=None, description="计划结束日期")
    actual_start_date: Optional[date] = Field(default=None, description="实际开始日期")
    actual_end_date: Optional[date] = Field(default=None, description="实际结束日期")
    budget: Optional[float] = Field(default=None, ge=0, description="预算金额")
    progress: Optional[int] = Field(default=None, ge=0, le=100, description="进度百分比")


class ProjectResponse(BaseModel):
    """项目响应"""
    id: int
    name: str
    code: str
    description: str
    status: str
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    actual_start_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    budget: float
    progress: int
    creator_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    member_count: int = Field(default=0, description="成员数量")

    model_config = {"from_attributes": True}


class ProjectMemberCreate(BaseModel):
    """添加项目成员"""
    user_id: int = Field(..., description="用户ID")
    member_role: str = Field(default="member", description="成员角色")
    join_date: Optional[date] = Field(default=None, description="加入日期")


class ProjectMemberUpdate(BaseModel):
    """更新项目成员"""
    member_role: Optional[str] = Field(default=None, description="成员角色")
    leave_date: Optional[date] = Field(default=None, description="离开日期")


class ProjectMemberResponse(BaseModel):
    """项目成员响应"""
    id: int
    project_id: int
    user_id: int
    member_role: str
    join_date: Optional[date] = None
    leave_date: Optional[date] = None
    user_name: str = Field(default="", description="用户名")
    user_full_name: str = Field(default="", description="用户姓名")

    model_config = {"from_attributes": True}
