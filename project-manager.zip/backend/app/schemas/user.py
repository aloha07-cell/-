from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr


class UserCreate(BaseModel):
    """创建用户"""
    username: str = Field(..., min_length=2, max_length=50, description="用户名")
    password: str = Field(..., min_length=6, max_length=100, description="密码")
    email: str = Field(..., min_length=1, max_length=100, description="邮箱")
    full_name: str = Field(default="", max_length=100, description="姓名")
    phone: str = Field(default="", max_length=20, description="手机号")
    department_id: Optional[int] = Field(default=None, description="部门ID")
    role_ids: List[int] = Field(default_factory=list, description="角色ID列表")


class UserUpdate(BaseModel):
    """更新用户"""
    email: Optional[str] = Field(default=None, max_length=100, description="邮箱")
    full_name: Optional[str] = Field(default=None, max_length=100, description="姓名")
    phone: Optional[str] = Field(default=None, max_length=20, description="手机号")
    department_id: Optional[int] = Field(default=None, description="部门ID")
    avatar_url: Optional[str] = Field(default=None, max_length=500, description="头像URL")
    is_active: Optional[bool] = Field(default=None, description="是否激活")
    role_ids: Optional[List[int]] = Field(default=None, description="角色ID列表")


class UserResponse(BaseModel):
    """用户响应"""
    id: int
    username: str
    email: str
    full_name: str
    avatar_url: str
    department_id: Optional[int] = None
    phone: str
    is_active: bool
    last_login_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    roles: List["RoleBriefResponse"] = Field(default_factory=list, description="角色列表")
    permissions: List[str] = Field(default_factory=list, description="权限列表")

    model_config = {"from_attributes": True}


class RoleBriefResponse(BaseModel):
    """角色简要响应"""
    id: int
    name: str
    code: str

    model_config = {"from_attributes": True}


class UserListResponse(BaseModel):
    """用户列表响应"""
    id: int
    username: str
    email: str
    full_name: str
    phone: str
    is_active: bool
    department_id: Optional[int] = None
    created_at: datetime

    model_config = {"from_attributes": True}
