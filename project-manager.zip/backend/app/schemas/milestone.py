from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field


class MilestoneCreate(BaseModel):
    """创建里程碑"""
    name: str = Field(..., min_length=1, max_length=200, description="里程碑名称")
    description: str = Field(default="", max_length=500, description="里程碑描述")
    project_id: int = Field(..., description="项目ID")
    due_date: Optional[date] = Field(default=None, description="截止日期")
    sort_order: int = Field(default=0, description="排序序号")


class MilestoneUpdate(BaseModel):
    """更新里程碑"""
    name: Optional[str] = Field(default=None, max_length=200, description="里程碑名称")
    description: Optional[str] = Field(default=None, max_length=500, description="里程碑描述")
    due_date: Optional[date] = Field(default=None, description="截止日期")
    status: Optional[str] = Field(default=None, description="状态")
    actual_date: Optional[date] = Field(default=None, description="实际完成日期")
    sort_order: Optional[int] = Field(default=None, description="排序序号")


class MilestoneResponse(BaseModel):
    """里程碑响应"""
    id: int
    name: str
    description: str
    project_id: int
    due_date: Optional[date] = None
    actual_date: Optional[date] = None
    status: str
    sort_order: int
    created_at: datetime
    updated_at: datetime
    task_count: int = Field(default=0, description="关联任务数量")

    model_config = {"from_attributes": True}
