from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field


class RiskCreate(BaseModel):
    """创建风险"""
    title: str = Field(..., min_length=1, max_length=200, description="风险标题")
    description: str = Field(default="", description="风险描述")
    project_id: int = Field(..., description="项目ID")
    level: str = Field(default="medium", description="风险等级")
    probability: float = Field(default=0.5, ge=0, le=1, description="发生概率")
    impact: float = Field(default=0.5, ge=0, le=1, description="影响程度")
    mitigation_plan: str = Field(default="", description="应对措施")
    owner_id: Optional[int] = Field(default=None, description="责任人ID")
    due_date: Optional[date] = Field(default=None, description="截止日期")


class RiskUpdate(BaseModel):
    """更新风险"""
    title: Optional[str] = Field(default=None, max_length=200, description="风险标题")
    description: Optional[str] = Field(default=None, description="风险描述")
    status: Optional[str] = Field(default=None, description="风险状态")
    level: Optional[str] = Field(default=None, description="风险等级")
    probability: Optional[float] = Field(default=None, ge=0, le=1, description="发生概率")
    impact: Optional[float] = Field(default=None, ge=0, le=1, description="影响程度")
    mitigation_plan: Optional[str] = Field(default=None, description="应对措施")
    owner_id: Optional[int] = Field(default=None, description="责任人ID")
    due_date: Optional[date] = Field(default=None, description="截止日期")
    resolved_at: Optional[date] = Field(default=None, description="解决日期")


class RiskResponse(BaseModel):
    """风险响应"""
    id: int
    title: str
    description: str
    project_id: int
    status: str
    level: str
    probability: float
    impact: float
    mitigation_plan: str
    owner_id: Optional[int] = None
    due_date: Optional[date] = None
    resolved_at: Optional[date] = None
    created_at: datetime
    updated_at: datetime
    owner_name: str = Field(default="", description="责任人姓名")

    model_config = {"from_attributes": True}
