from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class RoleCreate(BaseModel):
    """创建角色"""
    name: str = Field(..., min_length=1, max_length=50, description="角色名称")
    code: str = Field(..., min_length=1, max_length=50, description="角色编码")
    description: str = Field(default="", max_length=255, description="角色描述")
    permission_ids: List[int] = Field(default_factory=list, description="权限ID列表")


class RoleUpdate(BaseModel):
    """更新角色"""
    name: Optional[str] = Field(default=None, max_length=50, description="角色名称")
    description: Optional[str] = Field(default=None, max_length=255, description="角色描述")
    permission_ids: Optional[List[int]] = Field(default=None, description="权限ID列表")


class RoleResponse(BaseModel):
    """角色响应"""
    id: int
    name: str
    code: str
    description: str
    is_system: bool
    created_at: datetime
    updated_at: datetime
    permissions: List["PermissionResponse"] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class PermissionResponse(BaseModel):
    """权限响应"""
    id: int
    name: str
    code: str
    module: str
    description: str

    model_config = {"from_attributes": True}
