from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class NotificationResponse(BaseModel):
    """通知响应"""
    id: int
    user_id: int
    title: str
    content: str
    notification_type: str
    status: str
    is_read: bool
    related_id: Optional[int] = None
    related_type: str
    created_at: datetime

    model_config = {"from_attributes": True}


class NotificationRuleCreate(BaseModel):
    """创建通知规则"""
    notification_type: str = Field(..., description="通知类型")
    channel: str = Field(default="in_app", description="通知渠道")
    is_enabled: bool = Field(default=True, description="是否启用")


class NotificationRuleUpdate(BaseModel):
    """更新通知规则"""
    channel: Optional[str] = Field(default=None, description="通知渠道")
    is_enabled: Optional[bool] = Field(default=None, description="是否启用")


class NotificationRuleResponse(BaseModel):
    """通知规则响应"""
    id: int
    user_id: int
    notification_type: str
    channel: str
    is_enabled: bool
    created_at: datetime

    model_config = {"from_attributes": True}
