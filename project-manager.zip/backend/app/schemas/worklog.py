from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field


class WorkLogCreate(BaseModel):
    """创建工时记录"""
    task_id: int = Field(..., description="任务ID")
    project_id: int = Field(..., description="项目ID")
    work_date: date = Field(..., description="工作日期")
    hours: float = Field(..., gt=0, le=24, description="工作小时数")
    content: str = Field(default="", description="工作内容")


class WorkLogUpdate(BaseModel):
    """更新工时记录"""
    work_date: Optional[date] = Field(default=None, description="工作日期")
    hours: Optional[float] = Field(default=None, gt=0, le=24, description="工作小时数")
    content: Optional[str] = Field(default=None, description="工作内容")


class WorkLogResponse(BaseModel):
    """工时记录响应"""
    id: int
    user_id: int
    task_id: int
    project_id: int
    work_date: date
    hours: float
    content: str
    created_at: datetime
    user_name: str = Field(default="", description="用户名")
    task_title: str = Field(default="", description="任务标题")

    model_config = {"from_attributes": True}
