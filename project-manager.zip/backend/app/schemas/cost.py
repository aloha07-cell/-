from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field


class CostBudgetCreate(BaseModel):
    """创建成本预算"""
    project_id: int = Field(..., description="项目ID")
    category: str = Field(default="", max_length=50, description="预算类别")
    name: str = Field(..., min_length=1, max_length=200, description="预算名称")
    amount: float = Field(..., ge=0, description="预算金额")


class CostBudgetUpdate(BaseModel):
    """更新成本预算"""
    category: Optional[str] = Field(default=None, max_length=50, description="预算类别")
    name: Optional[str] = Field(default=None, max_length=200, description="预算名称")
    amount: Optional[float] = Field(default=None, ge=0, description="预算金额")
    status: Optional[str] = Field(default=None, description="状态")


class CostBudgetResponse(BaseModel):
    """成本预算响应"""
    id: int
    project_id: int
    category: str
    name: str
    amount: float
    used_amount: float
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class CostRecordCreate(BaseModel):
    """创建成本记录"""
    project_id: int = Field(..., description="项目ID")
    budget_id: Optional[int] = Field(default=None, description="预算ID")
    cost_type: str = Field(default="other", description="费用类型")
    amount: float = Field(..., description="金额")
    description: str = Field(default="", description="费用描述")
    cost_date: date = Field(..., description="费用日期")
    invoice_url: str = Field(default="", description="发票URL")


class CostRecordUpdate(BaseModel):
    """更新成本记录"""
    budget_id: Optional[int] = Field(default=None, description="预算ID")
    cost_type: Optional[str] = Field(default=None, description="费用类型")
    amount: Optional[float] = Field(default=None, description="金额")
    description: Optional[str] = Field(default=None, description="费用描述")
    cost_date: Optional[date] = Field(default=None, description="费用日期")
    invoice_url: Optional[str] = Field(default=None, description="发票URL")


class CostRecordResponse(BaseModel):
    """成本记录响应"""
    id: int
    project_id: int
    budget_id: Optional[int] = None
    cost_type: str
    amount: float
    description: str
    cost_date: date
    invoice_url: str
    created_by: Optional[int] = None
    created_at: datetime

    model_config = {"from_attributes": True}
