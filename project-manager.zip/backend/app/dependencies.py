from typing import Optional
from functools import wraps

from fastapi import Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.utils.database import get_db
from app.core.security import decode_token, is_token_blacklisted
from app.core.exceptions import UnauthorizedException, ForbiddenException
from app.models.user import User

security = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    """获取当前登录用户（FastAPI 依赖注入）"""
    token = credentials.credentials

    # 检查令牌是否在黑名单中
    if await is_token_blacklisted(token):
        raise UnauthorizedException("令牌已失效，请重新登录")

    # 解码令牌
    payload = decode_token(token)
    if payload is None:
        raise UnauthorizedException("无效的令牌")

    token_type = payload.get("type")
    if token_type != "access":
        raise UnauthorizedException("令牌类型错误")

    user_id = payload.get("sub")
    if user_id is None:
        raise UnauthorizedException("令牌中缺少用户信息")

    # 查询用户
    result = await db.execute(select(User).where(User.id == int(user_id)))
    user = result.scalar_one_or_none()

    if user is None:
        raise UnauthorizedException("用户不存在")

    if not user.is_active:
        raise UnauthorizedException("账号已被禁用")

    return user


async def get_current_user_with_permissions(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> User:
    """获取当前用户及其权限列表"""
    from app.models.role import UserRole, Role, Permission
    from sqlalchemy.orm import selectinload

    result = await db.execute(
        select(User)
        .options(
            selectinload(User.roles).selectinload(UserRole.role).selectinload(Role.permissions)
        )
        .where(User.id == current_user.id)
    )
    user = result.scalar_one_or_none()
    if user is None:
        raise UnauthorizedException("用户不存在")

    # 提取权限编码列表
    permissions = set()
    for user_role in user.roles:
        if hasattr(user_role, 'role') and user_role.role:
            for perm in user_role.role.permissions:
                permissions.add(perm.code)

    setattr(user, 'permissions', list(permissions))
    return user


def require_permission(permission_code: str):
    """权限校验依赖注入工厂"""
    async def permission_checker(
        current_user: User = Depends(get_current_user_with_permissions),
    ) -> User:
        user_permissions = getattr(current_user, "permissions", [])
        if permission_code not in user_permissions:
            raise ForbiddenException(f"权限不足，需要 {permission_code} 权限")
        return current_user

    return permission_checker
