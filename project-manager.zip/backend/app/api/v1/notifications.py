from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, update

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.notification import (
    NotificationResponse, NotificationRuleCreate,
    NotificationRuleUpdate, NotificationRuleResponse,
)
from app.models.notification import Notification, NotificationRule
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.get("", response_model=ApiResponse, summary="获取通知列表")
async def get_notifications(
    page_params: PageParams = Depends(get_page_params),
    is_read: Optional[bool] = Query(default=None, description="是否已读"),
    notification_type: Optional[str] = Query(default=None, description="通知类型"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取当前用户的通知列表"""
    query = select(Notification).where(Notification.user_id == current_user.id)
    count_query = select(func.count()).select_from(Notification).where(
        Notification.user_id == current_user.id
    )

    if is_read is not None:
        query = query.where(Notification.is_read == is_read)
        count_query = count_query.where(Notification.is_read == is_read)
    if notification_type:
        query = query.where(Notification.notification_type == notification_type)
        count_query = count_query.where(Notification.notification_type == notification_type)

    query = query.order_by(Notification.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    notifications = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = [NotificationResponse.model_validate(n) for n in notifications]
    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/unread-count", response_model=ApiResponse, summary="获取未读通知数量")
async def get_unread_count(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取当前用户未读通知数量"""
    result = await db.execute(
        select(func.count()).select_from(Notification).where(
            Notification.user_id == current_user.id,
            Notification.is_read == False,
        )
    )
    count = result.scalar() or 0
    return ApiResponse.success(data={"unread_count": count})


@router.put("/{notification_id}/read", response_model=ApiResponse, summary="标记通知已读")
async def mark_as_read(
    notification_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """标记通知为已读"""
    result = await db.execute(
        select(Notification).where(
            Notification.id == notification_id,
            Notification.user_id == current_user.id,
        )
    )
    notification = result.scalar_one_or_none()
    if notification is None:
        raise NotFoundException("通知不存在")

    notification.is_read = True
    notification.status = "read"
    await db.commit()
    return ApiResponse.success(message="已标记为已读")


@router.put("/read-all", response_model=ApiResponse, summary="全部标记已读")
async def mark_all_as_read(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """将所有未读通知标记为已读"""
    await db.execute(
        update(Notification)
        .where(Notification.user_id == current_user.id, Notification.is_read == False)
        .values(is_read=True, status="read")
    )
    await db.commit()
    return ApiResponse.success(message="全部标记为已读")


@router.delete("/{notification_id}", response_model=ApiResponse, summary="删除通知")
async def delete_notification(
    notification_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除通知"""
    result = await db.execute(
        select(Notification).where(
            Notification.id == notification_id,
            Notification.user_id == current_user.id,
        )
    )
    notification = result.scalar_one_or_none()
    if notification is None:
        raise NotFoundException("通知不存在")

    await db.delete(notification)
    await db.commit()
    return ApiResponse.success(message="通知已删除")


# 通知规则
@router.get("/rules", response_model=ApiResponse, summary="获取通知规则列表")
async def get_notification_rules(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取当前用户的通知规则"""
    result = await db.execute(
        select(NotificationRule).where(NotificationRule.user_id == current_user.id)
    )
    rules = result.scalars().all()
    items = [NotificationRuleResponse.model_validate(r) for r in rules]
    return ApiResponse.success(data=[i.model_dump() for i in items])


@router.post("/rules", response_model=ApiResponse, summary="创建通知规则")
async def create_notification_rule(
    request: NotificationRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建通知规则"""
    rule = NotificationRule(
        user_id=current_user.id,
        notification_type=request.notification_type,
        channel=request.channel,
        is_enabled=request.is_enabled,
    )
    db.add(rule)
    await db.commit()
    await db.refresh(rule)
    return ApiResponse.success(data=NotificationRuleResponse.model_validate(rule).model_dump())


@router.put("/rules/{rule_id}", response_model=ApiResponse, summary="更新通知规则")
async def update_notification_rule(
    rule_id: int,
    request: NotificationRuleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新通知规则"""
    result = await db.execute(
        select(NotificationRule).where(
            NotificationRule.id == rule_id,
            NotificationRule.user_id == current_user.id,
        )
    )
    rule = result.scalar_one_or_none()
    if rule is None:
        raise NotFoundException("通知规则不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(rule, key, value)

    await db.commit()
    await db.refresh(rule)
    return ApiResponse.success(data=NotificationRuleResponse.model_validate(rule).model_dump())


@router.delete("/rules/{rule_id}", response_model=ApiResponse, summary="删除通知规则")
async def delete_notification_rule(
    rule_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除通知规则"""
    result = await db.execute(
        select(NotificationRule).where(
            NotificationRule.id == rule_id,
            NotificationRule.user_id == current_user.id,
        )
    )
    rule = result.scalar_one_or_none()
    if rule is None:
        raise NotFoundException("通知规则不存在")

    await db.delete(rule)
    await db.commit()
    return ApiResponse.success(message="通知规则已删除")
