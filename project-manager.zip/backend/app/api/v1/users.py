from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.utils.pagination import PageParams, PaginatedResponse, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.user import UserCreate, UserUpdate, UserResponse, UserListResponse
from app.services.user_service import UserService
from app.dependencies import get_current_user
from app.models.user import User

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建用户")
async def create_user(
    request: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建用户"""
    user = await UserService.create_user(db, request)
    return ApiResponse.success(data={"id": user.id, "username": user.username})


@router.get("", response_model=ApiResponse, summary="获取用户列表")
async def get_users(
    page_params: PageParams = Depends(get_page_params),
    keyword: Optional[str] = Query(default=None, description="搜索关键词"),
    is_active: Optional[bool] = Query(default=None, description="是否激活"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取用户列表（分页）"""
    query = select(User)
    count_query = select(func.count()).select_from(User)

    if keyword:
        like_pattern = f"%{keyword}%"
        query = query.where(
            (User.username.like(like_pattern))
            | (User.email.like(like_pattern))
            | (User.full_name.like(like_pattern))
        )
        count_query = count_query.where(
            (User.username.like(like_pattern))
            | (User.email.like(like_pattern))
            | (User.full_name.like(like_pattern))
        )

    if is_active is not None:
        query = query.where(User.is_active == is_active)
        count_query = count_query.where(User.is_active == is_active)

    query = query.order_by(User.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    users = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = [
        UserListResponse.model_validate(u) for u in users
    ]
    paginated = PaginatedData(items=items, total=total, page=page_params.page,
                               page_size=page_params.page_size,
                               total_pages=(total + page_params.page_size - 1) // page_params.page_size)
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/me", response_model=ApiResponse, summary="获取当前用户信息")
async def get_current_user_info(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """获取当前登录用户的详细信息"""
    user = await UserService.get_user_with_permissions(db, current_user.id)
    return ApiResponse.success(data=UserResponse.model_validate(user).model_dump())


@router.get("/{user_id}", response_model=ApiResponse, summary="获取用户详情")
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取用户详情"""
    user = await UserService.get_user_with_permissions(db, user_id)
    return ApiResponse.success(data=UserResponse.model_validate(user).model_dump())


@router.put("/{user_id}", response_model=ApiResponse, summary="更新用户")
async def update_user(
    user_id: int,
    request: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新用户信息"""
    user = await UserService.update_user(db, user_id, request)
    return ApiResponse.success(data={"id": user.id, "username": user.username})


@router.delete("/{user_id}", response_model=ApiResponse, summary="删除用户")
async def delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除用户（逻辑删除，设置 is_active=False）"""
    await UserService.delete_user(db, user_id)
    return ApiResponse.success(message="用户已删除")
