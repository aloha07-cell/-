from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.utils.database import get_db
from app.schemas.common import ApiResponse
from app.schemas.role import RoleCreate, RoleUpdate, RoleResponse, PermissionResponse
from app.models.role import Role, Permission
from app.models.user import User
from app.dependencies import get_current_user

router = APIRouter()


@router.get("/permissions", response_model=ApiResponse, summary="获取所有权限列表")
async def get_permissions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取系统中所有权限"""
    result = await db.execute(select(Permission).order_by(Permission.module, Permission.code))
    permissions = result.scalars().all()
    items = [PermissionResponse.model_validate(p) for p in permissions]
    return ApiResponse.success(data=items)


@router.post("", response_model=ApiResponse, summary="创建角色")
async def create_role(
    request: RoleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建角色"""
    role = Role(
        name=request.name,
        code=request.code,
        description=request.description,
        is_system=False,
    )
    db.add(role)
    await db.flush()

    if request.permission_ids:
        result = await db.execute(
            select(Permission).where(Permission.id.in_(request.permission_ids))
        )
        perms = result.scalars().all()
        role.permissions = list(perms)

    await db.commit()
    await db.refresh(role)
    return ApiResponse.success(data=RoleResponse.model_validate(role).model_dump())


@router.get("", response_model=ApiResponse, summary="获取角色列表")
async def get_roles(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取所有角色"""
    result = await db.execute(select(Role).order_by(Role.created_at.desc()))
    roles = result.scalars().all()
    items = [RoleResponse.model_validate(r) for r in roles]
    return ApiResponse.success(data=items)


@router.get("/{role_id}", response_model=ApiResponse, summary="获取角色详情")
async def get_role(
    role_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取角色详情"""
    result = await db.execute(select(Role).where(Role.id == role_id))
    role = result.scalar_one_or_none()
    if role is None:
        from app.core.exceptions import NotFoundException
        raise NotFoundException("角色不存在")
    return ApiResponse.success(data=RoleResponse.model_validate(role).model_dump())


@router.put("/{role_id}", response_model=ApiResponse, summary="更新角色")
async def update_role(
    role_id: int,
    request: RoleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新角色信息"""
    result = await db.execute(select(Role).where(Role.id == role_id))
    role = result.scalar_one_or_none()
    if role is None:
        from app.core.exceptions import NotFoundException
        raise NotFoundException("角色不存在")

    if role.is_system:
        from app.core.exceptions import BusinessException
        raise BusinessException("系统内置角色不允许修改")

    if request.name is not None:
        role.name = request.name
    if request.description is not None:
        role.description = request.description

    if request.permission_ids is not None:
        perm_result = await db.execute(
            select(Permission).where(Permission.id.in_(request.permission_ids))
        )
        perms = perm_result.scalars().all()
        role.permissions = list(perms)

    await db.commit()
    await db.refresh(role)
    return ApiResponse.success(data=RoleResponse.model_validate(role).model_dump())


@router.delete("/{role_id}", response_model=ApiResponse, summary="删除角色")
async def delete_role(
    role_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除角色"""
    result = await db.execute(select(Role).where(Role.id == role_id))
    role = result.scalar_one_or_none()
    if role is None:
        from app.core.exceptions import NotFoundException
        raise NotFoundException("角色不存在")

    if role.is_system:
        from app.core.exceptions import BusinessException
        raise BusinessException("系统内置角色不允许删除")

    await db.delete(role)
    await db.commit()
    return ApiResponse.success(message="角色已删除")
