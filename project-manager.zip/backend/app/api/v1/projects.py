from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.project import (
    ProjectCreate, ProjectUpdate, ProjectResponse,
    ProjectMemberCreate, ProjectMemberUpdate, ProjectMemberResponse,
)
from app.models.project import Project, ProjectMember
from app.models.user import User
from app.core.exceptions import NotFoundException, BusinessException
from app.dependencies import get_current_user

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建项目")
async def create_project(
    request: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建项目"""
    project = Project(
        name=request.name,
        code=request.code,
        description=request.description,
        start_date=request.start_date,
        end_date=request.end_date,
        budget=request.budget,
        creator_id=current_user.id,
    )
    db.add(project)
    await db.flush()

    # 添加创建者为项目经理
    pm_member = ProjectMember(
        project_id=project.id,
        user_id=current_user.id,
        member_role="pm",
    )
    db.add(pm_member)

    # 添加初始成员
    for uid in request.member_ids:
        if uid != current_user.id:
            member = ProjectMember(project_id=project.id, user_id=uid, member_role="member")
            db.add(member)

    await db.commit()
    await db.refresh(project)
    return ApiResponse.success(data=ProjectResponse.model_validate(project).model_dump())


@router.get("", response_model=ApiResponse, summary="获取项目列表")
async def get_projects(
    page_params: PageParams = Depends(get_page_params),
    keyword: Optional[str] = Query(default=None, description="搜索关键词"),
    status: Optional[str] = Query(default=None, description="项目状态"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目列表（分页）"""
    query = select(Project)
    count_query = select(func.count()).select_from(Project)

    if keyword:
        like_pattern = f"%{keyword}%"
        query = query.where(
            (Project.name.like(like_pattern)) | (Project.code.like(like_pattern))
        )
        count_query = count_query.where(
            (Project.name.like(like_pattern)) | (Project.code.like(like_pattern))
        )

    if status:
        query = query.where(Project.status == status)
        count_query = count_query.where(Project.status == status)

    query = query.order_by(Project.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    projects = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = []
    for p in projects:
        resp = ProjectResponse.model_validate(p)
        member_count_result = await db.execute(
            select(func.count()).select_from(ProjectMember).where(ProjectMember.project_id == p.id)
        )
        resp.member_count = member_count_result.scalar() or 0
        items.append(resp)

    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/{project_id}", response_model=ApiResponse, summary="获取项目详情")
async def get_project(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目详情"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if project is None:
        raise NotFoundException("项目不存在")

    resp = ProjectResponse.model_validate(project)
    member_count_result = await db.execute(
        select(func.count()).select_from(ProjectMember).where(ProjectMember.project_id == project.id)
    )
    resp.member_count = member_count_result.scalar() or 0
    return ApiResponse.success(data=resp.model_dump())


@router.put("/{project_id}", response_model=ApiResponse, summary="更新项目")
async def update_project(
    project_id: int,
    request: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新项目信息"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if project is None:
        raise NotFoundException("项目不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(project, key, value)

    await db.commit()
    await db.refresh(project)
    return ApiResponse.success(data=ProjectResponse.model_validate(project).model_dump())


@router.delete("/{project_id}", response_model=ApiResponse, summary="删除项目")
async def delete_project(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除项目"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if project is None:
        raise NotFoundException("项目不存在")

    await db.delete(project)
    await db.commit()
    return ApiResponse.success(message="项目已删除")


# 项目成员管理
@router.get("/{project_id}/members", response_model=ApiResponse, summary="获取项目成员列表")
async def get_project_members(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目成员列表"""
    result = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id)
    )
    members = result.scalars().all()

    items = []
    for m in members:
        resp = ProjectMemberResponse.model_validate(m)
        user_result = await db.execute(select(User).where(User.id == m.user_id))
        user = user_result.scalar_one_or_none()
        if user:
            resp.user_name = user.username
            resp.user_full_name = user.full_name
        items.append(resp)

    return ApiResponse.success(data=[i.model_dump() for i in items])


@router.post("/{project_id}/members", response_model=ApiResponse, summary="添加项目成员")
async def add_project_member(
    project_id: int,
    request: ProjectMemberCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """添加项目成员"""
    project_result = await db.execute(select(Project).where(Project.id == project_id))
    if project_result.scalar_one_or_none() is None:
        raise NotFoundException("项目不存在")

    existing = await db.execute(
        select(ProjectMember).where(
            ProjectMember.project_id == project_id,
            ProjectMember.user_id == request.user_id,
        )
    )
    if existing.scalar_one_or_none() is not None:
        raise BusinessException("该用户已是项目成员")

    member = ProjectMember(
        project_id=project_id,
        user_id=request.user_id,
        member_role=request.member_role,
        join_date=request.join_date,
    )
    db.add(member)
    await db.commit()
    await db.refresh(member)
    return ApiResponse.success(data=ProjectMemberResponse.model_validate(member).model_dump())


@router.put("/{project_id}/members/{member_id}", response_model=ApiResponse, summary="更新项目成员")
async def update_project_member(
    project_id: int,
    member_id: int,
    request: ProjectMemberUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新项目成员信息"""
    result = await db.execute(
        select(ProjectMember).where(
            ProjectMember.id == member_id,
            ProjectMember.project_id == project_id,
        )
    )
    member = result.scalar_one_or_none()
    if member is None:
        raise NotFoundException("成员不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(member, key, value)

    await db.commit()
    await db.refresh(member)
    return ApiResponse.success(data=ProjectMemberResponse.model_validate(member).model_dump())


@router.delete("/{project_id}/members/{member_id}", response_model=ApiResponse, summary="移除项目成员")
async def remove_project_member(
    project_id: int,
    member_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """移除项目成员"""
    result = await db.execute(
        select(ProjectMember).where(
            ProjectMember.id == member_id,
            ProjectMember.project_id == project_id,
        )
    )
    member = result.scalar_one_or_none()
    if member is None:
        raise NotFoundException("成员不存在")

    await db.delete(member)
    await db.commit()
    return ApiResponse.success(message="成员已移除")
