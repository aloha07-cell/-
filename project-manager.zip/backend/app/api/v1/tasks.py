from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.task import (
    TaskCreate, TaskUpdate, TaskResponse,
    TaskDependencyCreate, TaskDependencyResponse,
    TaskWbsNode, KanbanColumn,
)
from app.models.task import Task, TaskDependency, TaskStatus
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user
from app.services.task_service import TaskService

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建任务")
async def create_task(
    request: TaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建任务"""
    task = await TaskService.create_task(db, request)
    return ApiResponse.success(data=TaskResponse.model_validate(task).model_dump())


@router.get("", response_model=ApiResponse, summary="获取任务列表")
async def get_tasks(
    page_params: PageParams = Depends(get_page_params),
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    status: Optional[str] = Query(default=None, description="任务状态"),
    assignee_id: Optional[int] = Query(default=None, description="指派人ID"),
    priority: Optional[str] = Query(default=None, description="优先级"),
    keyword: Optional[str] = Query(default=None, description="搜索关键词"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取任务列表（分页）"""
    query = select(Task).where(Task.parent_id.is_(None))
    count_query = select(func.count()).select_from(Task)

    if project_id:
        query = query.where(Task.project_id == project_id)
        count_query = count_query.where(Task.project_id == project_id)
    if status:
        query = query.where(Task.status == status)
        count_query = count_query.where(Task.status == status)
    if assignee_id:
        query = query.where(Task.assignee_id == assignee_id)
        count_query = count_query.where(Task.assignee_id == assignee_id)
    if priority:
        query = query.where(Task.priority == priority)
        count_query = count_query.where(Task.priority == priority)
    if keyword:
        like_pattern = f"%{keyword}%"
        query = query.where(Task.title.like(like_pattern))
        count_query = count_query.where(Task.title.like(like_pattern))

    query = query.order_by(Task.sort_order, Task.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    tasks = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = []
    for t in tasks:
        resp = TaskResponse.model_validate(t)
        if t.assignee_id:
            user_result = await db.execute(select(User).where(User.id == t.assignee_id))
            user = user_result.scalar_one_or_none()
            if user:
                resp.assignee_name = user.full_name or user.username
        children_count = await db.execute(
            select(func.count()).select_from(Task).where(Task.parent_id == t.id)
        )
        resp.children_count = children_count.scalar() or 0
        items.append(resp)

    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/{task_id}", response_model=ApiResponse, summary="获取任务详情")
async def get_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取任务详情"""
    task = await TaskService.get_task_detail(db, task_id)
    return ApiResponse.success(data=TaskResponse.model_validate(task).model_dump())


@router.put("/{task_id}", response_model=ApiResponse, summary="更新任务")
async def update_task(
    task_id: int,
    request: TaskUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新任务"""
    task = await TaskService.update_task(db, task_id, request)
    return ApiResponse.success(data=TaskResponse.model_validate(task).model_dump())


@router.delete("/{task_id}", response_model=ApiResponse, summary="删除任务")
async def delete_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除任务"""
    await TaskService.delete_task(db, task_id)
    return ApiResponse.success(message="任务已删除")


@router.patch("/{task_id}/status", response_model=ApiResponse, summary="更新任务状态")
async def update_task_status(
    task_id: int,
    status: str = Query(..., description="新状态"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新任务状态"""
    task = await TaskService.update_status(db, task_id, status)
    return ApiResponse.success(data=TaskResponse.model_validate(task).model_dump())


@router.get("/project/{project_id}/wbs", response_model=ApiResponse, summary="获取WBS树")
async def get_wbs_tree(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目的WBS树结构"""
    tree = await TaskService.build_wbs_tree(db, project_id)
    return ApiResponse.success(data=tree)


@router.get("/project/{project_id}/kanban", response_model=ApiResponse, summary="获取看板数据")
async def get_kanban_data(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目的看板数据"""
    kanban = await TaskService.get_kanban_data(db, project_id)
    return ApiResponse.success(data=kanban)


@router.get("/project/{project_id}/critical-path", response_model=ApiResponse, summary="获取关键路径")
async def get_critical_path(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目的关键路径"""
    path = await TaskService.calculate_critical_path(db, project_id)
    return ApiResponse.success(data=path)


# 任务依赖
@router.post("/dependencies", response_model=ApiResponse, summary="创建任务依赖")
async def create_dependency(
    request: TaskDependencyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建任务依赖关系"""
    dep = TaskDependency(
        task_id=request.task_id,
        depends_on_id=request.depends_on_id,
        dependency_type=request.dependency_type,
    )
    db.add(dep)
    await db.commit()
    await db.refresh(dep)
    return ApiResponse.success(data=TaskDependencyResponse.model_validate(dep).model_dump())


@router.delete("/dependencies/{dep_id}", response_model=ApiResponse, summary="删除任务依赖")
async def delete_dependency(
    dep_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除任务依赖关系"""
    result = await db.execute(select(TaskDependency).where(TaskDependency.id == dep_id))
    dep = result.scalar_one_or_none()
    if dep is None:
        raise NotFoundException("依赖关系不存在")

    await db.delete(dep)
    await db.commit()
    return ApiResponse.success(message="依赖关系已删除")
