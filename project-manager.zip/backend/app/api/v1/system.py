from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.utils.database import get_db
from app.schemas.common import ApiResponse
from app.models.system import SystemSetting
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.get("/settings", response_model=ApiResponse, summary="获取系统设置列表")
async def get_settings(
    group_name: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取系统设置列表"""
    query = select(SystemSetting)
    if group_name:
        query = query.where(SystemSetting.group_name == group_name)
    query = query.order_by(SystemSetting.group_name, SystemSetting.key)

    result = await db.execute(query)
    settings = result.scalars().all()
    items = [
        {
            "id": s.id,
            "key": s.key,
            "value": s.value,
            "description": s.description,
            "group_name": s.group_name,
        }
        for s in settings
    ]
    return ApiResponse.success(data=items)


@router.get("/settings/{key}", response_model=ApiResponse, summary="获取系统设置")
async def get_setting(
    key: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取指定系统设置"""
    result = await db.execute(select(SystemSetting).where(SystemSetting.key == key))
    setting = result.scalar_one_or_none()
    if setting is None:
        raise NotFoundException("设置不存在")

    return ApiResponse.success(data={
        "id": setting.id,
        "key": setting.key,
        "value": setting.value,
        "description": setting.description,
        "group_name": setting.group_name,
    })


@router.put("/settings/{key}", response_model=ApiResponse, summary="更新系统设置")
async def update_setting(
    key: str,
    value: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新系统设置"""
    result = await db.execute(select(SystemSetting).where(SystemSetting.key == key))
    setting = result.scalar_one_or_none()
    if setting is None:
        raise NotFoundException("设置不存在")

    setting.value = value
    await db.commit()
    await db.refresh(setting)
    return ApiResponse.success(data={
        "id": setting.id,
        "key": setting.key,
        "value": setting.value,
    })


@router.get("/audit-logs", response_model=ApiResponse, summary="获取审计日志")
async def get_audit_logs(
    page: int = 1,
    page_size: int = 20,
    resource_type: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取审计日志列表"""
    from app.models.audit import AuditLog
    from sqlalchemy import func

    query = select(AuditLog)
    count_query = select(func.count()).select_from(AuditLog)

    if resource_type:
        query = query.where(AuditLog.resource_type == resource_type)
        count_query = count_query.where(AuditLog.resource_type == resource_type)

    query = query.order_by(AuditLog.created_at.desc())
    query = query.offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    logs = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = [
        {
            "id": log.id,
            "user_id": log.user_id,
            "username": log.username,
            "action": log.action,
            "resource_type": log.resource_type,
            "resource_id": log.resource_id,
            "detail": log.detail,
            "ip_address": log.ip_address,
            "created_at": log.created_at.isoformat() if log.created_at else None,
        }
        for log in logs
    ]
    return ApiResponse.success(data={
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size,
    })
