from fastapi import APIRouter

from app.api.v1.auth import router as auth_router
from app.api.v1.users import router as users_router
from app.api.v1.roles import router as roles_router
from app.api.v1.projects import router as projects_router
from app.api.v1.tasks import router as tasks_router
from app.api.v1.milestones import router as milestones_router
from app.api.v1.worklogs import router as worklogs_router
from app.api.v1.risks import router as risks_router
from app.api.v1.costs import router as costs_router
from app.api.v1.documents import router as documents_router
from app.api.v1.notifications import router as notifications_router
from app.api.v1.reports import router as reports_router
from app.api.v1.system import router as system_router

v1_router = APIRouter()

v1_router.include_router(auth_router, prefix="/auth", tags=["认证"])
v1_router.include_router(users_router, prefix="/users", tags=["用户管理"])
v1_router.include_router(roles_router, prefix="/roles", tags=["角色管理"])
v1_router.include_router(projects_router, prefix="/projects", tags=["项目管理"])
v1_router.include_router(tasks_router, prefix="/tasks", tags=["任务管理"])
v1_router.include_router(milestones_router, prefix="/milestones", tags=["里程碑管理"])
v1_router.include_router(worklogs_router, prefix="/worklogs", tags=["工时管理"])
v1_router.include_router(risks_router, prefix="/risks", tags=["风险管理"])
v1_router.include_router(costs_router, prefix="/costs", tags=["成本管理"])
v1_router.include_router(documents_router, prefix="/documents", tags=["文档管理"])
v1_router.include_router(notifications_router, prefix="/notifications", tags=["通知管理"])
v1_router.include_router(reports_router, prefix="/reports", tags=["报表"])
v1_router.include_router(system_router, prefix="/system", tags=["系统设置"])
