from typing import Optional
from datetime import date
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.schemas.common import ApiResponse
from app.models.project import Project, ProjectMember
from app.models.task import Task, TaskStatus
from app.models.worklog import WorkLog
from app.models.cost import CostRecord
from app.models.user import User
from app.dependencies import get_current_user

router = APIRouter()


@router.get("/project/{project_id}/overview", response_model=ApiResponse, summary="项目概览报表")
async def get_project_overview(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目概览统计数据"""
    # 任务统计
    total_tasks = await db.execute(
        select(func.count()).select_from(Task).where(Task.project_id == project_id)
    )
    done_tasks = await db.execute(
        select(func.count()).select_from(Task).where(
            Task.project_id == project_id,
            Task.status == TaskStatus.DONE,
        )
    )
    in_progress_tasks = await db.execute(
        select(func.count()).select_from(Task).where(
            Task.project_id == project_id,
            Task.status == TaskStatus.IN_PROGRESS,
        )
    )
    overdue_tasks = await db.execute(
        select(func.count()).select_from(Task).where(
            Task.project_id == project_id,
            Task.status != TaskStatus.DONE,
            Task.status != TaskStatus.CANCELLED,
            Task.plan_end_date < func.curdate(),
        )
    )

    # 成员统计
    member_count = await db.execute(
        select(func.count()).select_from(ProjectMember).where(
            ProjectMember.project_id == project_id
        )
    )

    # 工时统计
    total_hours = await db.execute(
        select(func.sum(WorkLog.hours)).where(WorkLog.project_id == project_id)
    )

    # 成本统计
    total_cost = await db.execute(
        select(func.sum(CostRecord.amount)).where(CostRecord.project_id == project_id)
    )

    data = {
        "task_statistics": {
            "total": total_tasks.scalar() or 0,
            "done": done_tasks.scalar() or 0,
            "in_progress": in_progress_tasks.scalar() or 0,
            "overdue": overdue_tasks.scalar() or 0,
            "completion_rate": round(
                (done_tasks.scalar() or 0) / max(total_tasks.scalar() or 1, 1) * 100, 1
            ),
        },
        "member_count": member_count.scalar() or 0,
        "total_hours": float(total_hours.scalar() or 0),
        "total_cost": float(total_cost.scalar() or 0),
    }
    return ApiResponse.success(data=data)


@router.get("/project/{project_id}/workload", response_model=ApiResponse, summary="成员工作负载报表")
async def get_workload_report(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目成员工作负载统计"""
    result = await db.execute(
        select(
            User.id,
            User.username,
            User.full_name,
            func.count(Task.id).label("task_count"),
            func.sum(Task.estimated_hours).label("estimated_hours"),
            func.sum(Task.actual_hours).label("actual_hours"),
            func.sum(
                func.if(Task.status == TaskStatus.DONE, 1, 0)
            ).label("done_count"),
        )
        .join(ProjectMember, ProjectMember.user_id == User.id)
        .outerjoin(Task, Task.assignee_id == User.id)
        .where(ProjectMember.project_id == project_id)
        .group_by(User.id)
    )

    rows = result.all()
    items = [
        {
            "user_id": row.id,
            "username": row.username,
            "full_name": row.full_name,
            "task_count": row.task_count or 0,
            "estimated_hours": float(row.estimated_hours or 0),
            "actual_hours": float(row.actual_hours or 0),
            "done_count": row.done_count or 0,
        }
        for row in rows
    ]
    return ApiResponse.success(data=items)


@router.get("/project/{project_id}/cost-summary", response_model=ApiResponse, summary="成本汇总报表")
async def get_cost_summary(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取项目成本汇总"""
    result = await db.execute(
        select(
            CostRecord.cost_type,
            func.count(CostRecord.id).label("record_count"),
            func.sum(CostRecord.amount).label("total_amount"),
        )
        .where(CostRecord.project_id == project_id)
        .group_by(CostRecord.cost_type)
    )

    rows = result.all()
    items = [
        {
            "cost_type": row.cost_type,
            "record_count": row.record_count or 0,
            "total_amount": float(row.total_amount or 0),
        }
        for row in rows
    ]

    total_result = await db.execute(
        select(func.sum(CostRecord.amount)).where(CostRecord.project_id == project_id)
    )
    total_amount = float(total_result.scalar() or 0)

    return ApiResponse.success(data={"items": items, "total_amount": total_amount})
