from typing import Optional
from datetime import date
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.worklog import WorkLogCreate, WorkLogUpdate, WorkLogResponse
from app.models.worklog import WorkLog
from app.models.task import Task
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建工时记录")
async def create_worklog(
    request: WorkLogCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建工时记录"""
    worklog = WorkLog(
        user_id=current_user.id,
        task_id=request.task_id,
        project_id=request.project_id,
        work_date=request.work_date,
        hours=request.hours,
        content=request.content,
    )
    db.add(worklog)
    await db.commit()
    await db.refresh(worklog)

    resp = WorkLogResponse.model_validate(worklog)
    resp.user_name = current_user.username
    return ApiResponse.success(data=resp.model_dump())


@router.get("", response_model=ApiResponse, summary="获取工时记录列表")
async def get_worklogs(
    page_params: PageParams = Depends(get_page_params),
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    task_id: Optional[int] = Query(default=None, description="任务ID"),
    user_id: Optional[int] = Query(default=None, description="用户ID"),
    start_date: Optional[date] = Query(default=None, description="开始日期"),
    end_date: Optional[date] = Query(default=None, description="结束日期"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取工时记录列表"""
    query = select(WorkLog)
    count_query = select(func.count()).select_from(WorkLog)

    if project_id:
        query = query.where(WorkLog.project_id == project_id)
        count_query = count_query.where(WorkLog.project_id == project_id)
    if task_id:
        query = query.where(WorkLog.task_id == task_id)
        count_query = count_query.where(WorkLog.task_id == task_id)
    if user_id:
        query = query.where(WorkLog.user_id == user_id)
        count_query = count_query.where(WorkLog.user_id == user_id)
    if start_date:
        query = query.where(WorkLog.work_date >= start_date)
        count_query = count_query.where(WorkLog.work_date >= start_date)
    if end_date:
        query = query.where(WorkLog.work_date <= end_date)
        count_query = count_query.where(WorkLog.work_date <= end_date)

    query = query.order_by(WorkLog.work_date.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    worklogs = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = []
    for w in worklogs:
        resp = WorkLogResponse.model_validate(w)
        user_result = await db.execute(select(User).where(User.id == w.user_id))
        user = user_result.scalar_one_or_none()
        if user:
            resp.user_name = user.username
        task_result = await db.execute(select(Task).where(Task.id == w.task_id))
        task = task_result.scalar_one_or_none()
        if task:
            resp.task_title = task.title
        items.append(resp)

    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/{worklog_id}", response_model=ApiResponse, summary="获取工时记录详情")
async def get_worklog(
    worklog_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取工时记录详情"""
    result = await db.execute(select(WorkLog).where(WorkLog.id == worklog_id))
    worklog = result.scalar_one_or_none()
    if worklog is None:
        raise NotFoundException("工时记录不存在")

    resp = WorkLogResponse.model_validate(worklog)
    user_result = await db.execute(select(User).where(User.id == worklog.user_id))
    user = user_result.scalar_one_or_none()
    if user:
        resp.user_name = user.username
    task_result = await db.execute(select(Task).where(Task.id == worklog.task_id))
    task = task_result.scalar_one_or_none()
    if task:
        resp.task_title = task.title
    return ApiResponse.success(data=resp.model_dump())


@router.put("/{worklog_id}", response_model=ApiResponse, summary="更新工时记录")
async def update_worklog(
    worklog_id: int,
    request: WorkLogUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新工时记录"""
    result = await db.execute(select(WorkLog).where(WorkLog.id == worklog_id))
    worklog = result.scalar_one_or_none()
    if worklog is None:
        raise NotFoundException("工时记录不存在")

    if worklog.user_id != current_user.id:
        from app.core.exceptions import ForbiddenException
        raise ForbiddenException("只能修改自己的工时记录")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(worklog, key, value)

    await db.commit()
    await db.refresh(worklog)
    return ApiResponse.success(data=WorkLogResponse.model_validate(worklog).model_dump())


@router.delete("/{worklog_id}", response_model=ApiResponse, summary="删除工时记录")
async def delete_worklog(
    worklog_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除工时记录"""
    result = await db.execute(select(WorkLog).where(WorkLog.id == worklog_id))
    worklog = result.scalar_one_or_none()
    if worklog is None:
        raise NotFoundException("工时记录不存在")

    if worklog.user_id != current_user.id:
        from app.core.exceptions import ForbiddenException
        raise ForbiddenException("只能删除自己的工时记录")

    await db.delete(worklog)
    await db.commit()
    return ApiResponse.success(message="工时记录已删除")
