from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.cost import (
    CostBudgetCreate, CostBudgetUpdate, CostBudgetResponse,
    CostRecordCreate, CostRecordUpdate, CostRecordResponse,
)
from app.models.cost import CostBudget, CostRecord
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


# 预算管理
@router.post("/budgets", response_model=ApiResponse, summary="创建成本预算")
async def create_budget(
    request: CostBudgetCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建成本预算"""
    budget = CostBudget(
        project_id=request.project_id,
        category=request.category,
        name=request.name,
        amount=request.amount,
    )
    db.add(budget)
    await db.commit()
    await db.refresh(budget)
    return ApiResponse.success(data=CostBudgetResponse.model_validate(budget).model_dump())


@router.get("/budgets", response_model=ApiResponse, summary="获取预算列表")
async def get_budgets(
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取预算列表"""
    query = select(CostBudget)
    if project_id:
        query = query.where(CostBudget.project_id == project_id)
    query = query.order_by(CostBudget.created_at.desc())

    result = await db.execute(query)
    budgets = result.scalars().all()
    items = [CostBudgetResponse.model_validate(b) for b in budgets]
    return ApiResponse.success(data=[i.model_dump() for i in items])


@router.put("/budgets/{budget_id}", response_model=ApiResponse, summary="更新预算")
async def update_budget(
    budget_id: int,
    request: CostBudgetUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新预算"""
    result = await db.execute(select(CostBudget).where(CostBudget.id == budget_id))
    budget = result.scalar_one_or_none()
    if budget is None:
        raise NotFoundException("预算不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(budget, key, value)

    await db.commit()
    await db.refresh(budget)
    return ApiResponse.success(data=CostBudgetResponse.model_validate(budget).model_dump())


@router.delete("/budgets/{budget_id}", response_model=ApiResponse, summary="删除预算")
async def delete_budget(
    budget_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除预算"""
    result = await db.execute(select(CostBudget).where(CostBudget.id == budget_id))
    budget = result.scalar_one_or_none()
    if budget is None:
        raise NotFoundException("预算不存在")

    await db.delete(budget)
    await db.commit()
    return ApiResponse.success(message="预算已删除")


# 成本记录
@router.post("/records", response_model=ApiResponse, summary="创建成本记录")
async def create_cost_record(
    request: CostRecordCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建成本记录"""
    record = CostRecord(
        project_id=request.project_id,
        budget_id=request.budget_id,
        cost_type=request.cost_type,
        amount=request.amount,
        description=request.description,
        cost_date=request.cost_date,
        invoice_url=request.invoice_url,
        created_by=current_user.id,
    )
    db.add(record)

    # 更新预算已使用金额
    if request.budget_id:
        budget_result = await db.execute(select(CostBudget).where(CostBudget.id == request.budget_id))
        budget = budget_result.scalar_one_or_none()
        if budget:
            budget.used_amount += request.amount

    await db.commit()
    await db.refresh(record)
    return ApiResponse.success(data=CostRecordResponse.model_validate(record).model_dump())


@router.get("/records", response_model=ApiResponse, summary="获取成本记录列表")
async def get_cost_records(
    page_params: PageParams = Depends(get_page_params),
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    cost_type: Optional[str] = Query(default=None, description="费用类型"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取成本记录列表"""
    query = select(CostRecord)
    count_query = select(func.count()).select_from(CostRecord)

    if project_id:
        query = query.where(CostRecord.project_id == project_id)
        count_query = count_query.where(CostRecord.project_id == project_id)
    if cost_type:
        query = query.where(CostRecord.cost_type == cost_type)
        count_query = count_query.where(CostRecord.cost_type == cost_type)

    query = query.order_by(CostRecord.cost_date.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    records = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = [CostRecordResponse.model_validate(r) for r in records]
    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.put("/records/{record_id}", response_model=ApiResponse, summary="更新成本记录")
async def update_cost_record(
    record_id: int,
    request: CostRecordUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新成本记录"""
    result = await db.execute(select(CostRecord).where(CostRecord.id == record_id))
    record = result.scalar_one_or_none()
    if record is None:
        raise NotFoundException("成本记录不存在")

    old_amount = record.amount
    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(record, key, value)

    # 更新预算已使用金额
    if "amount" in update_data and record.budget_id:
        budget_result = await db.execute(select(CostBudget).where(CostBudget.id == record.budget_id))
        budget = budget_result.scalar_one_or_none()
        if budget:
            budget.used_amount = budget.used_amount - old_amount + record.amount

    await db.commit()
    await db.refresh(record)
    return ApiResponse.success(data=CostRecordResponse.model_validate(record).model_dump())


@router.delete("/records/{record_id}", response_model=ApiResponse, summary="删除成本记录")
async def delete_cost_record(
    record_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除成本记录"""
    result = await db.execute(select(CostRecord).where(CostRecord.id == record_id))
    record = result.scalar_one_or_none()
    if record is None:
        raise NotFoundException("成本记录不存在")

    # 更新预算已使用金额
    if record.budget_id:
        budget_result = await db.execute(select(CostBudget).where(CostBudget.id == record.budget_id))
        budget = budget_result.scalar_one_or_none()
        if budget:
            budget.used_amount = max(0, budget.used_amount - record.amount)

    await db.delete(record)
    await db.commit()
    return ApiResponse.success(message="成本记录已删除")
