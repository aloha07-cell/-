from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.schemas.common import ApiResponse
from app.schemas.milestone import MilestoneCreate, MilestoneUpdate, MilestoneResponse
from app.models.milestone import Milestone
from app.models.task import Task
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建里程碑")
async def create_milestone(
    request: MilestoneCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建里程碑"""
    milestone = Milestone(
        name=request.name,
        description=request.description,
        project_id=request.project_id,
        due_date=request.due_date,
        sort_order=request.sort_order,
    )
    db.add(milestone)
    await db.commit()
    await db.refresh(milestone)
    return ApiResponse.success(data=MilestoneResponse.model_validate(milestone).model_dump())


@router.get("", response_model=ApiResponse, summary="获取里程碑列表")
async def get_milestones(
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取里程碑列表"""
    query = select(Milestone)
    if project_id:
        query = query.where(Milestone.project_id == project_id)
    query = query.order_by(Milestone.sort_order, Milestone.due_date)

    result = await db.execute(query)
    milestones = result.scalars().all()

    items = []
    for m in milestones:
        resp = MilestoneResponse.model_validate(m)
        task_count_result = await db.execute(
            select(func.count()).select_from(Task).where(Task.milestone_id == m.id)
        )
        resp.task_count = task_count_result.scalar() or 0
        items.append(resp)

    return ApiResponse.success(data=[i.model_dump() for i in items])


@router.get("/{milestone_id}", response_model=ApiResponse, summary="获取里程碑详情")
async def get_milestone(
    milestone_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取里程碑详情"""
    result = await db.execute(select(Milestone).where(Milestone.id == milestone_id))
    milestone = result.scalar_one_or_none()
    if milestone is None:
        raise NotFoundException("里程碑不存在")

    resp = MilestoneResponse.model_validate(milestone)
    task_count_result = await db.execute(
        select(func.count()).select_from(Task).where(Task.milestone_id == milestone.id)
    )
    resp.task_count = task_count_result.scalar() or 0
    return ApiResponse.success(data=resp.model_dump())


@router.put("/{milestone_id}", response_model=ApiResponse, summary="更新里程碑")
async def update_milestone(
    milestone_id: int,
    request: MilestoneUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新里程碑"""
    result = await db.execute(select(Milestone).where(Milestone.id == milestone_id))
    milestone = result.scalar_one_or_none()
    if milestone is None:
        raise NotFoundException("里程碑不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(milestone, key, value)

    await db.commit()
    await db.refresh(milestone)
    return ApiResponse.success(data=MilestoneResponse.model_validate(milestone).model_dump())


@router.delete("/{milestone_id}", response_model=ApiResponse, summary="删除里程碑")
async def delete_milestone(
    milestone_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除里程碑"""
    result = await db.execute(select(Milestone).where(Milestone.id == milestone_id))
    milestone = result.scalar_one_or_none()
    if milestone is None:
        raise NotFoundException("里程碑不存在")

    await db.delete(milestone)
    await db.commit()
    return ApiResponse.success(message="里程碑已删除")
