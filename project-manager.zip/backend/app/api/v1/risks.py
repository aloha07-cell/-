from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.risk import RiskCreate, RiskUpdate, RiskResponse
from app.models.risk import Risk
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.post("", response_model=ApiResponse, summary="创建风险")
async def create_risk(
    request: RiskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """创建风险"""
    risk = Risk(
        title=request.title,
        description=request.description,
        project_id=request.project_id,
        level=request.level,
        probability=request.probability,
        impact=request.impact,
        mitigation_plan=request.mitigation_plan,
        owner_id=request.owner_id,
        due_date=request.due_date,
    )
    db.add(risk)
    await db.commit()
    await db.refresh(risk)

    resp = RiskResponse.model_validate(risk)
    if request.owner_id:
        user_result = await db.execute(select(User).where(User.id == request.owner_id))
        user = user_result.scalar_one_or_none()
        if user:
            resp.owner_name = user.full_name or user.username
    return ApiResponse.success(data=resp.model_dump())


@router.get("", response_model=ApiResponse, summary="获取风险列表")
async def get_risks(
    page_params: PageParams = Depends(get_page_params),
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    status: Optional[str] = Query(default=None, description="风险状态"),
    level: Optional[str] = Query(default=None, description="风险等级"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取风险列表"""
    query = select(Risk)
    count_query = select(func.count()).select_from(Risk)

    if project_id:
        query = query.where(Risk.project_id == project_id)
        count_query = count_query.where(Risk.project_id == project_id)
    if status:
        query = query.where(Risk.status == status)
        count_query = count_query.where(Risk.status == status)
    if level:
        query = query.where(Risk.level == level)
        count_query = count_query.where(Risk.level == level)

    query = query.order_by(Risk.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    risks = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = []
    for r in risks:
        resp = RiskResponse.model_validate(r)
        if r.owner_id:
            user_result = await db.execute(select(User).where(User.id == r.owner_id))
            user = user_result.scalar_one_or_none()
            if user:
                resp.owner_name = user.full_name or user.username
        items.append(resp)

    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/{risk_id}", response_model=ApiResponse, summary="获取风险详情")
async def get_risk(
    risk_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取风险详情"""
    result = await db.execute(select(Risk).where(Risk.id == risk_id))
    risk = result.scalar_one_or_none()
    if risk is None:
        raise NotFoundException("风险不存在")

    resp = RiskResponse.model_validate(risk)
    if risk.owner_id:
        user_result = await db.execute(select(User).where(User.id == risk.owner_id))
        user = user_result.scalar_one_or_none()
        if user:
            resp.owner_name = user.full_name or user.username
    return ApiResponse.success(data=resp.model_dump())


@router.put("/{risk_id}", response_model=ApiResponse, summary="更新风险")
async def update_risk(
    risk_id: int,
    request: RiskUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """更新风险"""
    result = await db.execute(select(Risk).where(Risk.id == risk_id))
    risk = result.scalar_one_or_none()
    if risk is None:
        raise NotFoundException("风险不存在")

    update_data = request.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(risk, key, value)

    await db.commit()
    await db.refresh(risk)
    return ApiResponse.success(data=RiskResponse.model_validate(risk).model_dump())


@router.delete("/{risk_id}", response_model=ApiResponse, summary="删除风险")
async def delete_risk(
    risk_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除风险"""
    result = await db.execute(select(Risk).where(Risk.id == risk_id))
    risk = result.scalar_one_or_none()
    if risk is None:
        raise NotFoundException("风险不存在")

    await db.delete(risk)
    await db.commit()
    return ApiResponse.success(message="风险已删除")
