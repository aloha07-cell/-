from typing import Optional
from fastapi import APIRouter, Depends, Query, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
import uuid

from app.utils.database import get_db
from app.utils.pagination import PageParams, get_page_params
from app.utils.minio_client import get_minio
from app.config import settings
from app.schemas.common import ApiResponse, PaginatedData
from app.schemas.document import DocumentResponse, DocumentUploadResponse
from app.models.document import Document
from app.models.user import User
from app.core.exceptions import NotFoundException
from app.dependencies import get_current_user

router = APIRouter()


@router.post("/upload", response_model=ApiResponse, summary="上传文档")
async def upload_document(
    project_id: int = Query(..., description="项目ID"),
    description: str = Query(default="", description="文档描述"),
    file: UploadFile = File(..., description="文件"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """上传文档到MinIO"""
    minio_client = get_minio()
    file_content = await file.read()
    file_size = len(file_content)
    file_type = file.filename.rsplit(".", 1)[-1] if file.filename and "." in file.filename else ""
    object_name = f"projects/{project_id}/{uuid.uuid4().hex}_{file.filename}"

    minio_client.put_object(
        bucket_name=settings.COMPUTED_MINIO_BUCKET,
        object_name=object_name,
        data=file_content,
        length=file_size,
        content_type=file.content_type or "application/octet-stream",
    )

    doc = Document(
        project_id=project_id,
        name=file.filename or "unnamed",
        file_path=object_name,
        file_size=file_size,
        file_type=file_type,
        description=description,
        uploaded_by=current_user.id,
    )
    db.add(doc)
    await db.commit()
    await db.refresh(doc)

    resp = DocumentUploadResponse.model_validate(doc)
    return ApiResponse.success(data=resp.model_dump())


@router.get("", response_model=ApiResponse, summary="获取文档列表")
async def get_documents(
    page_params: PageParams = Depends(get_page_params),
    project_id: Optional[int] = Query(default=None, description="项目ID"),
    file_type: Optional[str] = Query(default=None, description="文件类型"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取文档列表"""
    query = select(Document)
    count_query = select(func.count()).select_from(Document)

    if project_id:
        query = query.where(Document.project_id == project_id)
        count_query = count_query.where(Document.project_id == project_id)
    if file_type:
        query = query.where(Document.file_type == file_type)
        count_query = count_query.where(Document.file_type == file_type)

    query = query.order_by(Document.created_at.desc())
    query = query.offset(page_params.offset).limit(page_params.limit)

    result = await db.execute(query)
    documents = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    items = []
    for d in documents:
        resp = DocumentResponse.model_validate(d)
        if d.uploaded_by:
            user_result = await db.execute(select(User).where(User.id == d.uploaded_by))
            user = user_result.scalar_one_or_none()
            if user:
                resp.uploader_name = user.full_name or user.username
        items.append(resp)

    paginated = PaginatedData(
        items=[i.model_dump() for i in items],
        total=total,
        page=page_params.page,
        page_size=page_params.page_size,
        total_pages=(total + page_params.page_size - 1) // page_params.page_size,
    )
    return ApiResponse.success(data=paginated.model_dump())


@router.get("/{document_id}", response_model=ApiResponse, summary="获取文档详情")
async def get_document(
    document_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取文档详情"""
    result = await db.execute(select(Document).where(Document.id == document_id))
    doc = result.scalar_one_or_none()
    if doc is None:
        raise NotFoundException("文档不存在")

    resp = DocumentResponse.model_validate(doc)
    if doc.uploaded_by:
        user_result = await db.execute(select(User).where(User.id == doc.uploaded_by))
        user = user_result.scalar_one_or_none()
        if user:
            resp.uploader_name = user.full_name or user.username
    return ApiResponse.success(data=resp.model_dump())


@router.get("/{document_id}/download-url", response_model=ApiResponse, summary="获取文档下载链接")
async def get_download_url(
    document_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """获取文档的临时下载链接"""
    result = await db.execute(select(Document).where(Document.id == document_id))
    doc = result.scalar_one_or_none()
    if doc is None:
        raise NotFoundException("文档不存在")

    minio_client = get_minio()
    url = minio_client.presigned_get_object(
        bucket_name=settings.COMPUTED_MINIO_BUCKET,
        object_name=doc.file_path,
    )
    return ApiResponse.success(data={"download_url": url, "filename": doc.name})


@router.delete("/{document_id}", response_model=ApiResponse, summary="删除文档")
async def delete_document(
    document_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """删除文档"""
    result = await db.execute(select(Document).where(Document.id == document_id))
    doc = result.scalar_one_or_none()
    if doc is None:
        raise NotFoundException("文档不存在")

    # 从MinIO删除文件
    try:
        minio_client = get_minio()
        minio_client.remove_object(
            bucket_name=settings.COMPUTED_MINIO_BUCKET,
            object_name=doc.file_path,
        )
    except Exception:
        pass

    await db.delete(doc)
    await db.commit()
    return ApiResponse.success(message="文档已删除")
