from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.utils.database import get_db
from app.schemas.common import ApiResponse
from app.schemas.auth import LoginRequest, RegisterRequest, TokenResponse, RefreshTokenRequest
from app.services.auth_service import AuthService

router = APIRouter()


@router.post("/register", response_model=ApiResponse, summary="用户注册")
async def register(request: RegisterRequest, db: AsyncSession = Depends(get_db)):
    """用户注册"""
    user = await AuthService.register(db, request)
    return ApiResponse.success(data={"id": user.id, "username": user.username})


@router.post("/login", response_model=ApiResponse, summary="用户登录")
async def login(request: LoginRequest, db: AsyncSession = Depends(get_db)):
    """用户登录，返回访问令牌和刷新令牌"""
    token_data = await AuthService.login(db, request.username, request.password)
    return ApiResponse.success(data=token_data.model_dump())


@router.post("/refresh", response_model=ApiResponse, summary="刷新令牌")
async def refresh_token(request: RefreshTokenRequest, db: AsyncSession = Depends(get_db)):
    """使用刷新令牌获取新的访问令牌"""
    token_data = await AuthService.refresh_token(db, request.refresh_token)
    return ApiResponse.success(data=token_data.model_dump())


@router.post("/logout", response_model=ApiResponse, summary="用户登出")
async def logout():
    """用户登出（由依赖注入处理令牌黑名单）"""
    return ApiResponse.success(message="登出成功")
