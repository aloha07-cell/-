import logging
from datetime import date, timedelta

from sqlalchemy import select, and_

from app.utils.database import async_session_factory
from app.models.task import Task, TaskStatus
from app.models.milestone import Milestone, MilestoneStatus
from app.models.risk import Risk, RiskStatus
from app.models.cost import CostBudget
from app.models.user import User
from app.models.project import Project
from app.models.notification import Notification, NotificationType
from app.services.notification_sender import NotificationSender

logger = logging.getLogger(__name__)


async def check_overdue_tasks() -> None:
    """检查逾期任务并发送通知"""
    async with async_session_factory() as session:
        try:
            today = date.today()
            three_days_later = today + timedelta(days=3)

            # 查找即将到期但未完成的任务（3天内到期）
            upcoming_result = await session.execute(
                select(Task).where(
                    Task.status.notin_([TaskStatus.DONE, TaskStatus.CANCELLED]),
                    Task.plan_end_date <= three_days_later,
                    Task.plan_end_date >= today,
                    Task.assignee_id.is_not(None),
                )
            )
            upcoming_tasks = upcoming_result.scalars().all()

            for task in upcoming_tasks:
                # 获取项目名称
                project_result = await session.execute(
                    select(Project).where(Project.id == task.project_id)
                )
                project = project_result.scalar_one_or_none()
                project_name = project.name if project else ""

                # 获取指派人名称
                user_result = await session.execute(
                    select(User).where(User.id == task.assignee_id)
                )
                user = user_result.scalar_one_or_none()
                assignee_name = user.full_name or user.username if user else ""

                due_date_str = task.plan_end_date.isoformat() if task.plan_end_date else ""

                # 创建应用内通知
                notification = Notification(
                    user_id=task.assignee_id,
                    title="任务即将到期",
                    content=f"任务「{task.title}」将于 {due_date_str} 到期，请尽快完成。",
                    notification_type=NotificationType.TASK_DUE_SOON,
                    status="unread",
                    is_read=False,
                    related_id=task.id,
                    related_type="task",
                )
                session.add(notification)

                # 发送企微通知
                await NotificationSender.send_task_notification(
                    task_title=task.title,
                    project_name=project_name,
                    assignee_name=assignee_name,
                    due_date=due_date_str,
                    notification_type="task_due_soon",
                )

            # 查找已逾期的任务
            overdue_result = await session.execute(
                select(Task).where(
                    Task.status.notin_([TaskStatus.DONE, TaskStatus.CANCELLED]),
                    Task.plan_end_date < today,
                    Task.assignee_id.is_not(None),
                )
            )
            overdue_tasks = overdue_result.scalars().all()

            for task in overdue_tasks:
                project_result = await session.execute(
                    select(Project).where(Project.id == task.project_id)
                )
                project = project_result.scalar_one_or_none()
                project_name = project.name if project else ""

                user_result = await session.execute(
                    select(User).where(User.id == task.assignee_id)
                )
                user = user_result.scalar_one_or_none()
                assignee_name = user.full_name or user.username if user else ""

                due_date_str = task.plan_end_date.isoformat() if task.plan_end_date else ""

                notification = Notification(
                    user_id=task.assignee_id,
                    title="任务已逾期",
                    content=f"任务「{task.title}」已于 {due_date_str} 逾期，请立即处理。",
                    notification_type=NotificationType.TASK_OVERDUE,
                    status="unread",
                    is_read=False,
                    related_id=task.id,
                    related_type="task",
                )
                session.add(notification)

                await NotificationSender.send_task_notification(
                    task_title=task.title,
                    project_name=project_name,
                    assignee_name=assignee_name,
                    due_date=due_date_str,
                    notification_type="task_overdue",
                )

            await session.commit()
            logger.info(
                f"逾期任务检查完成：即将到期 {len(upcoming_tasks)} 条，已逾期 {len(overdue_tasks)} 条"
            )
        except Exception as e:
            logger.error(f"逾期任务检查失败: {e}")
            await session.rollback()


async def check_milestone_due() -> None:
    """检查即将到期的里程碑"""
    async with async_session_factory() as session:
        try:
            today = date.today()
            seven_days_later = today + timedelta(days=7)

            result = await session.execute(
                select(Milestone).where(
                    Milestone.status == MilestoneStatus.PENDING,
                    Milestone.due_date <= seven_days_later,
                    Milestone.due_date >= today,
                )
            )
            milestones = result.scalars().all()

            for milestone in milestones:
                project_result = await session.execute(
                    select(Project).where(Project.id == milestone.project_id)
                )
                project = project_result.scalar_one_or_none()
                project_name = project.name if project else ""

                # 获取项目成员
                from app.models.project import ProjectMember
                members_result = await session.execute(
                    select(ProjectMember).where(ProjectMember.project_id == milestone.project_id)
                )
                members = members_result.scalars().all()

                for member in members:
                    notification = Notification(
                        user_id=member.user_id,
                        title="里程碑即将到期",
                        content=f"项目「{project_name}」的里程碑「{milestone.name}」将于 "
                                f"{milestone.due_date.isoformat()} 到期。",
                        notification_type=NotificationType.MILESTONE_DUE,
                        status="unread",
                        is_read=False,
                        related_id=milestone.id,
                        related_type="milestone",
                    )
                    session.add(notification)

            await session.commit()
            logger.info(f"里程碑到期检查完成：{len(milestones)} 条即将到期")
        except Exception as e:
            logger.error(f"里程碑到期检查失败: {e}")
            await session.rollback()


async def check_risk_alerts() -> None:
    """检查高风险项目"""
    async with async_session_factory() as session:
        try:
            result = await session.execute(
                select(Risk).where(
                    Risk.status == RiskStatus.OPEN,
                    Risk.level.in_(["high", "critical"]),
                )
            )
            risks = result.scalars().all()

            for risk in risks:
                project_result = await session.execute(
                    select(Project).where(Project.id == risk.project_id)
                )
                project = project_result.scalar_one_or_none()
                project_name = project.name if project else ""

                owner_name = ""
                if risk.owner_id:
                    user_result = await session.execute(
                        select(User).where(User.id == risk.owner_id)
                    )
                    user = user_result.scalar_one_or_none()
                    owner_name = user.full_name or user.username if user else ""

                if risk.owner_id:
                    notification = Notification(
                        user_id=risk.owner_id,
                        title="风险预警",
                        content=f"项目「{project_name}」存在{risk.level}级风险「{risk.title}」，请及时处理。",
                        notification_type=NotificationType.RISK_ALERT,
                        status="unread",
                        is_read=False,
                        related_id=risk.id,
                        related_type="risk",
                    )
                    session.add(notification)

                await NotificationSender.send_risk_alert(
                    risk_title=risk.title,
                    project_name=project_name,
                    risk_level=risk.level,
                    owner_name=owner_name,
                )

            await session.commit()
            logger.info(f"风险预警检查完成：{len(risks)} 条高风险")
        except Exception as e:
            logger.error(f"风险预警检查失败: {e}")
            await session.rollback()


async def check_budget_alerts() -> None:
    """检查预算使用率预警"""
    async with async_session_factory() as session:
        try:
            result = await session.execute(
                select(CostBudget).where(
                    CostBudget.status == "active",
                    CostBudget.amount > 0,
                )
            )
            budgets = result.scalars().all()

            alert_count = 0
            for budget in budgets:
                usage_rate = budget.used_amount / budget.amount if budget.amount > 0 else 0

                # 使用率超过80%时预警
                if usage_rate >= 0.8:
                    project_result = await session.execute(
                        select(Project).where(Project.id == budget.project_id)
                    )
                    project = project_result.scalar_one_or_none()
                    project_name = project.name if project else ""

                    # 获取项目经理
                    from app.models.project import ProjectMember
                    pm_result = await session.execute(
                        select(ProjectMember).where(
                            ProjectMember.project_id == budget.project_id,
                            ProjectMember.member_role == "pm",
                        )
                    )
                    pm = pm_result.scalar_one_or_none()

                    if pm:
                        notification = Notification(
                            user_id=pm.user_id,
                            title="预算预警",
                            content=f"项目「{project_name}」的预算「{budget.name}」"
                                    f"使用率已达 {usage_rate * 100:.1f}%，请关注。",
                            notification_type=NotificationType.BUDGET_ALERT,
                            status="unread",
                            is_read=False,
                            related_id=budget.id,
                            related_type="budget",
                        )
                        session.add(notification)

                    await NotificationSender.send_budget_alert(
                        project_name=project_name,
                        budget_name=budget.name,
                        used_amount=budget.used_amount,
                        total_amount=budget.amount,
                    )
                    alert_count += 1

            await session.commit()
            logger.info(f"预算预警检查完成：{alert_count} 条预警")
        except Exception as e:
            logger.error(f"预算预警检查失败: {e}")
            await session.rollback()
