import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from app.tasks.notification_tasks import check_overdue_tasks, check_milestone_due, check_risk_alerts, check_budget_alerts

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()


def init_scheduler() -> None:
    """初始化定时任务调度器"""
    # 每天早上9点检查逾期任务
    scheduler.add_job(
        check_overdue_tasks,
        CronTrigger(hour=9, minute=0),
        id="check_overdue_tasks",
        name="检查逾期任务",
        replace_existing=True,
    )

    # 每天早上9点检查即将到期的里程碑
    scheduler.add_job(
        check_milestone_due,
        CronTrigger(hour=9, minute=0),
        id="check_milestone_due",
        name="检查里程碑到期",
        replace_existing=True,
    )

    # 每天上午10点检查风险预警
    scheduler.add_job(
        check_risk_alerts,
        CronTrigger(hour=10, minute=0),
        id="check_risk_alerts",
        name="检查风险预警",
        replace_existing=True,
    )

    # 每天上午10点检查预算预警
    scheduler.add_job(
        check_budget_alerts,
        CronTrigger(hour=10, minute=0),
        id="check_budget_alerts",
        name="检查预算预警",
        replace_existing=True,
    )

    logger.info("定时任务调度器初始化完成")


def start_scheduler() -> None:
    """启动调度器"""
    if not scheduler.running:
        scheduler.start()
        logger.info("定时任务调度器已启动")


def stop_scheduler() -> None:
    """停止调度器"""
    if scheduler.running:
        scheduler.shutdown()
        logger.info("定时任务调度器已停止")
