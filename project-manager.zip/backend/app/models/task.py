from datetime import date, datetime
from enum import Enum as PyEnum

from sqlalchemy import String, Integer, Float, ForeignKey, Date, DateTime, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class TaskPriority(str, PyEnum):
    """任务优先级"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class TaskStatus(str, PyEnum):
    """任务状态"""
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    DONE = "done"
    CANCELLED = "cancelled"


class DependencyType(str, PyEnum):
    """依赖类型"""
    FINISH_TO_START = "finish_to_start"
    START_TO_START = "start_to_start"
    FINISH_TO_FINISH = "finish_to_finish"
    START_TO_FINISH = "start_to_finish"


class Task(BaseModel):
    """任务模型"""
    __tablename__ = "tasks"

    title: Mapped[str] = mapped_column(String(200), nullable=False, comment="任务标题")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="任务描述")
    wbs_code: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="WBS编码")
    status: Mapped[str] = mapped_column(
        Enum(TaskStatus), default=TaskStatus.TODO, nullable=False, comment="任务状态"
    )
    priority: Mapped[str] = mapped_column(
        Enum(TaskPriority), default=TaskPriority.MEDIUM, nullable=False, comment="优先级"
    )
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    parent_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("tasks.id", ondelete="SET NULL"), nullable=True, comment="父任务ID"
    )
    assignee_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, comment="指派人ID"
    )
    milestone_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("milestones.id", ondelete="SET NULL"), nullable=True, comment="关联里程碑ID"
    )
    plan_start_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="计划开始日期")
    plan_end_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="计划结束日期")
    actual_start_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="实际开始日期")
    actual_end_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="实际结束日期")
    estimated_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False, comment="预估工时")
    actual_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False, comment="实际工时")
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="进度百分比")
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="排序序号")

    # 关系
    project: Mapped["Project"] = relationship(back_populates="tasks")
    parent: Mapped["Task | None"] = relationship(remote_side="Task.id", foreign_keys=[parent_id])
    children: Mapped[list["Task"]] = relationship(
        back_populates="parent", foreign_keys=[parent_id], lazy="noload"
    )
    assignee: Mapped["User | None"] = relationship(back_populates="tasks", foreign_keys=[assignee_id])
    milestone: Mapped["Milestone | None"] = relationship(back_populates="tasks")
    dependencies_from: Mapped[list["TaskDependency"]] = relationship(
        back_populates="task", foreign_keys="TaskDependency.task_id", lazy="noload"
    )
    dependencies_to: Mapped[list["TaskDependency"]] = relationship(
        back_populates="depends_on", foreign_keys="TaskDependency.depends_on_id", lazy="noload"
    )
    work_logs: Mapped[list["WorkLog"]] = relationship(back_populates="task", lazy="noload")


class TaskDependency(BaseModel):
    """任务依赖关系模型"""
    __tablename__ = "task_dependencies"

    task_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, comment="任务ID"
    )
    depends_on_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, comment="依赖任务ID"
    )
    dependency_type: Mapped[str] = mapped_column(
        Enum(DependencyType), default=DependencyType.FINISH_TO_START, nullable=False, comment="依赖类型"
    )

    # 关系
    task: Mapped["Task"] = relationship(
        back_populates="dependencies_from", foreign_keys=[task_id]
    )
    depends_on: Mapped["Task"] = relationship(
        back_populates="dependencies_to", foreign_keys=[depends_on_id]
    )
