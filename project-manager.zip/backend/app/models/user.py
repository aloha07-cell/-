from sqlalchemy import String, Boolean, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class User(BaseModel):
    """用户模型"""
    __tablename__ = "users"

    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, comment="用户名")
    email: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, comment="邮箱")
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False, comment="密码哈希")
    full_name: Mapped[str] = mapped_column(String(100), nullable=False, default="", comment="姓名")
    avatar_url: Mapped[str] = mapped_column(String(500), nullable=False, default="", comment="头像URL")
    department_id: Mapped[int | None] = mapped_column(nullable=True, comment="部门ID")
    phone: Mapped[str] = mapped_column(String(20), nullable=False, default="", comment="手机号")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, comment="是否激活")
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, comment="最后登录时间")

    # 关系
    roles: Mapped[list["UserRole"]] = relationship(back_populates="user", lazy="selectin")
    tasks: Mapped[list["Task"]] = relationship(back_populates="assignee", lazy="noload")
    created_projects: Mapped[list["Project"]] = relationship(back_populates="creator", foreign_keys="Project.creator_id", lazy="noload")
    work_logs: Mapped[list["WorkLog"]] = relationship(back_populates="user", lazy="noload")
