from sqlalchemy import String, Integer, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Document(BaseModel):
    """文档模型"""
    __tablename__ = "documents"

    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="文档名称")
    file_path: Mapped[str] = mapped_column(String(500), nullable=False, comment="文件路径")
    file_size: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="文件大小(字节)")
    file_type: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="文件类型")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="文档描述")
    uploaded_by: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, comment="上传人ID"
    )
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False, comment="版本号")

    # 关系
    project: Mapped["Project"] = relationship(back_populates="documents")
    uploader: Mapped["User | None"] = relationship(lazy="joined")
