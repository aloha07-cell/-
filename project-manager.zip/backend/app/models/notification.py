from enum import Enum as PyEnum

from sqlalchemy import String, Integer, Boolean, ForeignKey, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class NotificationType(str, PyEnum):
    """通知类型"""
    SYSTEM = "system"
    TASK_ASSIGNED = "task_assigned"
    TASK_DUE_SOON = "task_due_soon"
    TASK_OVERDUE = "task_overdue"
    MILESTONE_DUE = "milestone_due"
    RISK_ALERT = "risk_alert"
    BUDGET_ALERT = "budget_alert"
    COMMENT = "comment"


class NotificationStatus(str, PyEnum):
    """通知状态"""
    UNREAD = "unread"
    READ = "read"


class NotificationChannel(str, PyEnum):
    """通知渠道"""
    IN_APP = "in_app"
    WECOM = "wecom"
    SMS = "sms"
    EMAIL = "email"


class Notification(BaseModel):
    """通知模型"""
    __tablename__ = "notifications"

    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="接收用户ID"
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False, comment="通知标题")
    content: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="通知内容")
    notification_type: Mapped[str] = mapped_column(
        Enum(NotificationType), default=NotificationType.SYSTEM, nullable=False, comment="通知类型"
    )
    status: Mapped[str] = mapped_column(
        Enum(NotificationStatus), default=NotificationStatus.UNREAD, nullable=False, comment="状态"
    )
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, comment="是否已读")
    related_id: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="关联对象ID")
    related_type: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="关联对象类型")

    # 关系


class NotificationRule(BaseModel):
    """通知规则模型"""
    __tablename__ = "notification_rules"

    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="用户ID"
    )
    notification_type: Mapped[str] = mapped_column(
        Enum(NotificationType), nullable=False, comment="通知类型"
    )
    channel: Mapped[str] = mapped_column(
        Enum(NotificationChannel), default=NotificationChannel.IN_APP, nullable=False, comment="通知渠道"
    )
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, comment="是否启用")
