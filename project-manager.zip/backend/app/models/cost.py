from datetime import date
from enum import Enum as PyEnum

from sqlalchemy import String, Integer, Float, ForeignKey, Date, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class BudgetStatus(str, PyEnum):
    """预算状态"""
    ACTIVE = "active"
    FROZEN = "frozen"
    CLOSED = "closed"


class CostType(str, PyEnum):
    """费用类型"""
    LABOR = "labor"
    MATERIAL = "material"
    EQUIPMENT = "equipment"
    OUTSOURCE = "outsource"
    TRAVEL = "travel"
    OTHER = "other"


class CostBudget(BaseModel):
    """成本预算模型"""
    __tablename__ = "cost_budgets"

    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    category: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="预算类别")
    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="预算名称")
    amount: Mapped[float] = mapped_column(Float, nullable=False, comment="预算金额")
    used_amount: Mapped[float] = mapped_column(Float, default=0.0, nullable=False, comment="已使用金额")
    status: Mapped[str] = mapped_column(
        Enum(BudgetStatus), default=BudgetStatus.ACTIVE, nullable=False, comment="状态"
    )

    # 关系
    project: Mapped["Project"] = relationship(back_populates="cost_budgets")
    records: Mapped[list["CostRecord"]] = relationship(back_populates="budget", lazy="noload")


class CostRecord(BaseModel):
    """成本记录模型"""
    __tablename__ = "cost_records"

    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    budget_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("cost_budgets.id", ondelete="SET NULL"), nullable=True, comment="预算ID"
    )
    cost_type: Mapped[str] = mapped_column(
        Enum(CostType), default=CostType.OTHER, nullable=False, comment="费用类型"
    )
    amount: Mapped[float] = mapped_column(Float, nullable=False, comment="金额")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="费用描述")
    cost_date: Mapped[date] = mapped_column(Date, nullable=False, comment="费用日期")
    invoice_url: Mapped[str] = mapped_column(String(500), nullable=False, default="", comment="发票URL")
    created_by: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, comment="记录人ID"
    )

    # 关系
    budget: Mapped["CostBudget | None"] = relationship(back_populates="records")
