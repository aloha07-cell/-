from sqlalchemy import String, Integer, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import BaseModel


class AuditLog(BaseModel):
    """审计日志模型"""
    __tablename__ = "audit_logs"

    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="操作用户ID")
    username: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="操作用户名")
    action: Mapped[str] = mapped_column(String(50), nullable=False, comment="操作类型")
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False, comment="资源类型")
    resource_id: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="资源ID")
    detail: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="操作详情")
    ip_address: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="IP地址")
    user_agent: Mapped[str] = mapped_column(String(500), nullable=False, default="", comment="用户代理")
