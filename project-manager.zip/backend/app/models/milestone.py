from datetime import date

from sqlalchemy import String, Integer, ForeignKey, Date, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from enum import Enum as PyEnum

from app.models.base import BaseModel


class MilestoneStatus(str, PyEnum):
    """里程碑状态"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    OVERDUE = "overdue"


class Milestone(BaseModel):
    """里程碑模型"""
    __tablename__ = "milestones"

    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="里程碑名称")
    description: Mapped[str] = mapped_column(String(500), nullable=False, default="", comment="里程碑描述")
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="截止日期")
    actual_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="实际完成日期")
    status: Mapped[str] = mapped_column(
        Enum(MilestoneStatus), default=MilestoneStatus.PENDING, nullable=False, comment="状态"
    )
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="排序序号")

    # 关系
    project: Mapped["Project"] = relationship(back_populates="milestones")
    tasks: Mapped[list["Task"]] = relationship(back_populates="milestone", lazy="noload")
