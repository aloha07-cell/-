from datetime import date, datetime
from enum import Enum as PyEnum

from sqlalchemy import String, Integer, ForeignKey, Date, DateTime, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class ProjectStatus(str, PyEnum):
    """项目状态"""
    PLANNING = "planning"
    IN_PROGRESS = "in_progress"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class MemberRole(str, PyEnum):
    """项目成员角色"""
    PM = "pm"
    MEMBER = "member"
    OBSERVER = "observer"


class Project(BaseModel):
    """项目模型"""
    __tablename__ = "projects"

    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="项目名称")
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, comment="项目编号")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="项目描述")
    status: Mapped[str] = mapped_column(
        Enum(ProjectStatus), default=ProjectStatus.PLANNING, nullable=False, comment="项目状态"
    )
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="计划开始日期")
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="计划结束日期")
    actual_start_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="实际开始日期")
    actual_end_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="实际结束日期")
    budget: Mapped[float] = mapped_column(default=0.0, nullable=False, comment="预算金额")
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False, comment="进度百分比")
    creator_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, comment="创建人ID"
    )

    # 关系
    creator: Mapped["User"] = relationship(back_populates="created_projects", foreign_keys=[creator_id])
    members: Mapped[list["ProjectMember"]] = relationship(back_populates="project", lazy="selectin")
    tasks: Mapped[list["Task"]] = relationship(back_populates="project", lazy="noload")
    milestones: Mapped[list["Milestone"]] = relationship(back_populates="project", lazy="noload")
    documents: Mapped[list["Document"]] = relationship(back_populates="project", lazy="noload")
    risks: Mapped[list["Risk"]] = relationship(back_populates="project", lazy="noload")
    cost_budgets: Mapped[list["CostBudget"]] = relationship(back_populates="project", lazy="noload")


class ProjectMember(BaseModel):
    """项目成员模型"""
    __tablename__ = "project_members"

    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="用户ID"
    )
    member_role: Mapped[str] = mapped_column(
        Enum(MemberRole), default=MemberRole.MEMBER, nullable=False, comment="成员角色"
    )
    join_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="加入日期")
    leave_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="离开日期")

    # 关系
    project: Mapped["Project"] = relationship(back_populates="members")
    user: Mapped["User"] = relationship(lazy="joined")
