from sqlalchemy import String, Table, Column, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel

# 多对多关联表：用户-角色
user_role_table = Table(
    "user_roles",
    BaseModel.metadata,
    Column("user_id", Integer, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", Integer, ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
)

# 多对多关联表：角色-权限
role_permission_table = Table(
    "role_permissions",
    BaseModel.metadata,
    Column("role_id", Integer, ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    Column("permission_id", Integer, ForeignKey("permissions.id", ondelete="CASCADE"), primary_key=True),
)


class Role(BaseModel):
    """角色模型"""
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, comment="角色名称")
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, comment="角色编码")
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="", comment="角色描述")
    is_system: Mapped[bool] = mapped_column(default=False, nullable=False, comment="是否系统内置角色")

    # 关系
    permissions: Mapped[list["Permission"]] = relationship(
        secondary=role_permission_table, lazy="selectin"
    )
    users: Mapped[list["UserRole"]] = relationship(back_populates="role", lazy="selectin")


class Permission(BaseModel):
    """权限模型"""
    __tablename__ = "permissions"

    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, comment="权限名称")
    code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, comment="权限编码")
    module: Mapped[str] = mapped_column(String(50), nullable=False, default="", comment="所属模块")
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="", comment="权限描述")


class UserRole(BaseModel):
    """用户角色关联模型"""
    __tablename__ = "user_roles_ext"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="用户ID")
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id", ondelete="CASCADE"), nullable=False, comment="角色ID")

    # 关系
    user: Mapped["User"] = relationship(back_populates="roles")
    role: Mapped["Role"] = relationship(back_populates="users")
