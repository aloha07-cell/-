from datetime import date
from enum import Enum as PyEnum

from sqlalchemy import String, Integer, Float, ForeignKey, Date, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class RiskStatus(str, PyEnum):
    """风险状态"""
    OPEN = "open"
    MITIGATING = "mitigating"
    CLOSED = "closed"


class RiskLevel(str, PyEnum):
    """风险等级"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Risk(BaseModel):
    """风险模型"""
    __tablename__ = "risks"

    title: Mapped[str] = mapped_column(String(200), nullable=False, comment="风险标题")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="风险描述")
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    status: Mapped[str] = mapped_column(
        Enum(RiskStatus), default=RiskStatus.OPEN, nullable=False, comment="风险状态"
    )
    level: Mapped[str] = mapped_column(
        Enum(RiskLevel), default=RiskLevel.MEDIUM, nullable=False, comment="风险等级"
    )
    probability: Mapped[float] = mapped_column(Float, default=0.5, nullable=False, comment="发生概率")
    impact: Mapped[float] = mapped_column(Float, default=0.5, nullable=False, comment="影响程度")
    mitigation_plan: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="应对措施")
    owner_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, comment="责任人ID"
    )
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True, comment="截止日期")
    resolved_at: Mapped[date | None] = mapped_column(Date, nullable=True, comment="解决日期")

    # 关系
    project: Mapped["Project"] = relationship(back_populates="risks")
    owner: Mapped["User | None"] = relationship(lazy="joined")
