from datetime import date

from sqlalchemy import String, Integer, Float, ForeignKey, Date, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class WorkLog(BaseModel):
    """工时记录模型"""
    __tablename__ = "work_logs"

    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, comment="用户ID"
    )
    task_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, comment="任务ID"
    )
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, comment="项目ID"
    )
    work_date: Mapped[date] = mapped_column(Date, nullable=False, comment="工作日期")
    hours: Mapped[float] = mapped_column(Float, nullable=False, comment="工作小时数")
    content: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="工作内容")

    # 关系
    user: Mapped["User"] = relationship(back_populates="work_logs")
    task: Mapped["Task"] = relationship(back_populates="work_logs")
