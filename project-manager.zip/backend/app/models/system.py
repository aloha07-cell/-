from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import BaseModel


class SystemSetting(BaseModel):
    """系统设置模型"""
    __tablename__ = "system_settings"

    key: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, comment="设置键")
    value: Mapped[str] = mapped_column(Text, nullable=False, default="", comment="设置值")
    description: Mapped[str] = mapped_column(String(255), nullable=False, default="", comment="设置描述")
    group_name: Mapped[str] = mapped_column(String(50), nullable=False, default="default", comment="分组名称")
