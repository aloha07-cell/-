from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.project import ProjectCreate, ProjectUpdate
from app.models.project import Project, ProjectMember
from app.models.user import User
from app.core.exceptions import NotFoundException, BusinessException


class ProjectService:
    """项目服务"""

    @staticmethod
    async def get_project_detail(db: AsyncSession, project_id: int) -> Project:
        """获取项目详情"""
        result = await db.execute(
            select(Project).where(Project.id == project_id)
        )
        project = result.scalar_one_or_none()
        if project is None:
            raise NotFoundException("项目不存在")
        return project

    @staticmethod
    async def get_project_members(db: AsyncSession, project_id: int) -> list:
        """获取项目成员"""
        result = await db.execute(
            select(ProjectMember).where(ProjectMember.project_id == project_id)
        )
        return result.scalars().all()

    @staticmethod
    async def is_project_member(
        db: AsyncSession, project_id: int, user_id: int
    ) -> bool:
        """检查用户是否为项目成员"""
        result = await db.execute(
            select(ProjectMember).where(
                ProjectMember.project_id == project_id,
                ProjectMember.user_id == user_id,
            )
        )
        return result.scalar_one_or_none() is not None

    @staticmethod
    async def update_project_progress(db: AsyncSession, project_id: int) -> int:
        """根据任务完成情况更新项目进度"""
        from app.models.task import Task, TaskStatus

        total_result = await db.execute(
            select(func.count()).select_from(Task).where(Task.project_id == project_id)
        )
        total = total_result.scalar() or 0

        if total == 0:
            return 0

        done_result = await db.execute(
            select(func.count()).select_from(Task).where(
                Task.project_id == project_id,
                Task.status == TaskStatus.DONE,
            )
        )
        done = done_result.scalar() or 0

        progress = int(done / total * 100)

        result = await db.execute(select(Project).where(Project.id == project_id))
        project = result.scalar_one_or_none()
        if project:
            project.progress = progress
            await db.commit()

        return progress
