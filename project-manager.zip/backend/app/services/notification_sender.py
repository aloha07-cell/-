import logging
from typing import Optional

import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class NotificationSender:
    """通知发送服务"""

    @staticmethod
    async def send_wecom_webhook(content: str, mentioned_list: Optional[list] = None) -> bool:
        """通过企业微信 Webhook 发送消息"""
        if not settings.WECOM_WEBHOOK_URL:
            logger.warning("企业微信 Webhook URL 未配置")
            return False

        payload = {
            "msgtype": "text",
            "text": {
                "content": content,
                "mentioned_list": mentioned_list or [],
            },
        }

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.post(settings.WECOM_WEBHOOK_URL, json=payload)
                result = response.json()
                if result.get("errcode") == 0:
                    logger.info("企业微信消息发送成功")
                    return True
                else:
                    logger.error(f"企业微信消息发送失败: {result}")
                    return False
        except Exception as e:
            logger.error(f"企业微信消息发送异常: {e}")
            return False

    @staticmethod
    async def send_wecom_markdown(title: str, content: str) -> bool:
        """通过企业微信 Webhook 发送 Markdown 消息"""
        if not settings.WECOM_WEBHOOK_URL:
            logger.warning("企业微信 Webhook URL 未配置")
            return False

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "title": title,
                "text": content,
            },
        }

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.post(settings.WECOM_WEBHOOK_URL, json=payload)
                result = response.json()
                if result.get("errcode") == 0:
                    logger.info("企业微信 Markdown 消息发送成功")
                    return True
                else:
                    logger.error(f"企业微信 Markdown 消息发送失败: {result}")
                    return False
        except Exception as e:
            logger.error(f"企业微信 Markdown 消息发送异常: {e}")
            return False

    @staticmethod
    async def send_sms(phone: str, content: str) -> bool:
        """发送短信"""
        if not settings.SMS_API_URL or not settings.SMS_API_KEY:
            logger.warning("短信服务未配置")
            return False

        payload = {
            "phone": phone,
            "content": content,
            "api_key": settings.SMS_API_KEY,
        }

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.post(settings.SMS_API_URL, json=payload)
                result = response.json()
                if result.get("code") == 0:
                    logger.info(f"短信发送成功: {phone}")
                    return True
                else:
                    logger.error(f"短信发送失败: {result}")
                    return False
        except Exception as e:
            logger.error(f"短信发送异常: {e}")
            return False

    @staticmethod
    async def send_task_notification(
        task_title: str,
        project_name: str,
        assignee_name: str,
        due_date: str,
        notification_type: str = "task_assigned",
    ) -> None:
        """发送任务相关通知"""
        if notification_type == "task_assigned":
            content = (
                f"【任务分配通知】\n"
                f"项目：{project_name}\n"
                f"任务：{task_title}\n"
                f"指派给：{assignee_name}\n"
                f"截止日期：{due_date}\n"
                f"请及时查看并处理。"
            )
            await NotificationSender.send_wecom_webhook(content)

        elif notification_type == "task_due_soon":
            content = (
                f"【任务即将到期提醒】\n"
                f"项目：{project_name}\n"
                f"任务：{task_title}\n"
                f"负责人：{assignee_name}\n"
                f"截止日期：{due_date}\n"
                f"请尽快完成。"
            )
            await NotificationSender.send_wecom_webhook(content)

        elif notification_type == "task_overdue":
            content = (
                f"【任务逾期预警】\n"
                f"项目：{project_name}\n"
                f"任务：{task_title}\n"
                f"负责人：{assignee_name}\n"
                f"截止日期：{due_date}\n"
                f"任务已逾期，请立即处理！"
            )
            await NotificationSender.send_wecom_webhook(content)

    @staticmethod
    async def send_risk_alert(
        risk_title: str,
        project_name: str,
        risk_level: str,
        owner_name: str,
    ) -> None:
        """发送风险预警通知"""
        level_map = {
            "low": "低",
            "medium": "中",
            "high": "高",
            "critical": "严重",
        }
        level_text = level_map.get(risk_level, risk_level)

        content = (
            f"【风险预警通知】\n"
            f"项目：{project_name}\n"
            f"风险：{risk_title}\n"
            f"等级：{level_text}\n"
            f"责任人：{owner_name}\n"
            f"请及时关注并制定应对措施。"
        )
        await NotificationSender.send_wecom_webhook(content)

    @staticmethod
    async def send_budget_alert(
        project_name: str,
        budget_name: str,
        used_amount: float,
        total_amount: float,
    ) -> None:
        """发送预算预警通知"""
        usage_rate = round(used_amount / max(total_amount, 0.01) * 100, 1)

        content = (
            f"【预算预警通知】\n"
            f"项目：{project_name}\n"
            f"预算项：{budget_name}\n"
            f"已使用：{used_amount:.2f} 元\n"
            f"总预算：{total_amount:.2f} 元\n"
            f"使用率：{usage_rate}%\n"
            f"请关注预算使用情况。"
        )
        await NotificationSender.send_wecom_webhook(content)
