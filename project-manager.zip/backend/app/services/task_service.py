from typing import List, Dict, Any
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.task import TaskCreate, TaskUpdate
from app.models.task import Task, TaskDependency, TaskStatus
from app.models.user import User
from app.core.exceptions import NotFoundException


class TaskService:
    """任务服务"""

    @staticmethod
    async def create_task(db: AsyncSession, request: TaskCreate) -> Task:
        """创建任务"""
        task = Task(
            title=request.title,
            description=request.description,
            project_id=request.project_id,
            parent_id=request.parent_id,
            assignee_id=request.assignee_id,
            milestone_id=request.milestone_id,
            priority=request.priority,
            plan_start_date=request.plan_start_date,
            plan_end_date=request.plan_end_date,
            estimated_hours=request.estimated_hours,
            sort_order=request.sort_order,
        )

        # 生成WBS编码
        if request.parent_id:
            parent_result = await db.execute(select(Task).where(Task.id == request.parent_id))
            parent = parent_result.scalar_one_or_none()
            if parent:
                # 获取同级任务数量
                sibling_count = await db.execute(
                    select(func.count()).select_from(Task).where(Task.parent_id == request.parent_id)
                )
                count = sibling_count.scalar() or 0
                task.wbs_code = f"{parent.wbs_code}.{count + 1}"
        else:
            # 获取顶级任务数量
            top_count = await db.execute(
                select(func.count()).select_from(Task).where(
                    Task.project_id == request.project_id,
                    Task.parent_id.is_(None),
                )
            )
            count = top_count.scalar() or 0
            task.wbs_code = str(count + 1)

        db.add(task)
        await db.commit()
        await db.refresh(task)
        return task

    @staticmethod
    async def get_task_detail(db: AsyncSession, task_id: int) -> Task:
        """获取任务详情"""
        result = await db.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task is None:
            raise NotFoundException("任务不存在")
        return task

    @staticmethod
    async def update_task(db: AsyncSession, task_id: int, request: TaskUpdate) -> Task:
        """更新任务"""
        result = await db.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task is None:
            raise NotFoundException("任务不存在")

        update_data = request.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(task, key, value)

        await db.commit()
        await db.refresh(task)
        return task

    @staticmethod
    async def update_status(db: AsyncSession, task_id: int, status: str) -> Task:
        """更新任务状态"""
        result = await db.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task is None:
            raise NotFoundException("任务不存在")

        task.status = status

        # 如果任务完成，设置实际完成日期
        if status == TaskStatus.DONE and task.actual_end_date is None:
            from datetime import date
            task.actual_end_date = date.today()
            task.progress = 100

        # 如果任务开始，设置实际开始日期
        if status == TaskStatus.IN_PROGRESS and task.actual_start_date is None:
            from datetime import date
            task.actual_start_date = date.today()

        await db.commit()
        await db.refresh(task)
        return task

    @staticmethod
    async def delete_task(db: AsyncSession, task_id: int) -> None:
        """删除任务"""
        result = await db.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task is None:
            raise NotFoundException("任务不存在")

        # 删除子任务
        children_result = await db.execute(select(Task).where(Task.parent_id == task_id))
        for child in children_result.scalars().all():
            await db.delete(child)

        # 删除依赖关系
        deps_result = await db.execute(
            select(TaskDependency).where(
                (TaskDependency.task_id == task_id) | (TaskDependency.depends_on_id == task_id)
            )
        )
        for dep in deps_result.scalars().all():
            await db.delete(dep)

        await db.delete(task)
        await db.commit()

    @staticmethod
    async def build_wbs_tree(db: AsyncSession, project_id: int) -> List[Dict[str, Any]]:
        """构建WBS树结构"""
        result = await db.execute(
            select(Task)
            .where(Task.project_id == project_id, Task.parent_id.is_(None))
            .order_by(Task.sort_order, Task.wbs_code)
        )
        root_tasks = result.scalars().all()

        tree = []
        for task in root_tasks:
            node = await TaskService._build_tree_node(db, task)
            tree.append(node)
        return tree

    @staticmethod
    async def _build_tree_node(db: AsyncSession, task: Task) -> Dict[str, Any]:
        """递归构建树节点"""
        children_result = await db.execute(
            select(Task)
            .where(Task.parent_id == task.id)
            .order_by(Task.sort_order, Task.wbs_code)
        )
        children = children_result.scalars().all()

        node = {
            "id": task.id,
            "title": task.title,
            "wbs_code": task.wbs_code,
            "status": task.status,
            "priority": task.priority,
            "assignee_id": task.assignee_id,
            "assignee_name": "",
            "plan_start_date": task.plan_start_date.isoformat() if task.plan_start_date else None,
            "plan_end_date": task.plan_end_date.isoformat() if task.plan_end_date else None,
            "progress": task.progress,
            "children": [],
        }

        if task.assignee_id:
            user_result = await db.execute(select(User).where(User.id == task.assignee_id))
            user = user_result.scalar_one_or_none()
            if user:
                node["assignee_name"] = user.full_name or user.username

        for child in children:
            child_node = await TaskService._build_tree_node(db, child)
            node["children"].append(child_node)

        return node

    @staticmethod
    async def get_kanban_data(db: AsyncSession, project_id: int) -> List[Dict[str, Any]]:
        """获取看板数据"""
        status_map = {
            TaskStatus.TODO: "待办",
            TaskStatus.IN_PROGRESS: "进行中",
            TaskStatus.REVIEW: "审核中",
            TaskStatus.DONE: "已完成",
            TaskStatus.CANCELLED: "已取消",
        }

        kanban = []
        for status, label in status_map.items():
            result = await db.execute(
                select(Task)
                .where(Task.project_id == project_id, Task.status == status, Task.parent_id.is_(None))
                .order_by(Task.sort_order, Task.priority)
            )
            tasks = result.scalars().all()

            task_list = []
            for t in tasks:
                task_dict = {
                    "id": t.id,
                    "title": t.title,
                    "wbs_code": t.wbs_code,
                    "status": t.status,
                    "priority": t.priority,
                    "assignee_id": t.assignee_id,
                    "assignee_name": "",
                    "plan_start_date": t.plan_start_date.isoformat() if t.plan_start_date else None,
                    "plan_end_date": t.plan_end_date.isoformat() if t.plan_end_date else None,
                    "progress": t.progress,
                    "estimated_hours": t.estimated_hours,
                }
                if t.assignee_id:
                    user_result = await db.execute(select(User).where(User.id == t.assignee_id))
                    user = user_result.scalar_one_or_none()
                    if user:
                        task_dict["assignee_name"] = user.full_name or user.username
                task_list.append(task_dict)

            kanban.append({
                "status": status,
                "status_label": label,
                "tasks": task_list,
            })

        return kanban

    @staticmethod
    async def calculate_critical_path(db: AsyncSession, project_id: int) -> List[Dict[str, Any]]:
        """计算关键路径（基于依赖关系和计划日期）"""
        # 获取所有任务
        result = await db.execute(
            select(Task).where(Task.project_id == project_id).order_by(Task.plan_start_date)
        )
        all_tasks = result.scalars().all()

        # 获取所有依赖关系
        deps_result = await db.execute(
            select(TaskDependency).where(
                TaskDependency.task_id.in_([t.id for t in all_tasks])
            )
        )
        dependencies = deps_result.scalars().all()

        # 构建依赖图
        task_map = {t.id: t for t in all_tasks}
        forward_deps: Dict[int, List[int]] = {}  # task_id -> [depends_on_ids]
        backward_deps: Dict[int, List[int]] = {}  # task_id -> [dependent_task_ids]

        for dep in dependencies:
            if dep.task_id not in forward_deps:
                forward_deps[dep.task_id] = []
            forward_deps[dep.task_id].append(dep.depends_on_id)

            if dep.depends_on_id not in backward_deps:
                backward_deps[dep.depends_on_id] = []
            backward_deps[dep.depends_on_id].append(dep.task_id)

        # 循环依赖检测（使用DFS + 访问标记）
        visiting: set = set()  # 当前递归路径上的节点
        visited: set = set()   # 已完成访问的节点

        def has_cycle(task_id: int) -> bool:
            if task_id in visited:
                return False
            if task_id in visiting:
                return True  # 发现循环
            visiting.add(task_id)
            for dep_id in forward_deps.get(task_id, []):
                if has_cycle(dep_id):
                    return True
            visiting.remove(task_id)
            visited.add(task_id)
            return False

        for t in all_tasks:
            if has_cycle(t.id):
                return []  # 存在循环依赖，无法计算关键路径

        # 计算最早开始/结束时间（使用迭代+栈替代递归，避免栈溢出）
        from datetime import date, timedelta
        earliest_start: Dict[int, date] = {}
        earliest_finish: Dict[int, date] = {}
        computing: set = set()  # 防止重复计算

        def calc_earliest(task_id: int) -> None:
            if task_id in computing:
                return
            computing.add(task_id)
            task = task_map[task_id]
            es = task.plan_start_date or date.today()
            deps = forward_deps.get(task_id, [])

            if deps:
                max_ef = date.min
                for dep_id in deps:
                    if dep_id not in earliest_finish:
                        calc_earliest(dep_id)
                    if earliest_finish[dep_id] > max_ef:
                        max_ef = earliest_finish[dep_id]
                if max_ef > es:
                    es = max_ef

            earliest_start[task_id] = es
            duration = task.estimated_hours / 8  # 假设每天8小时
            earliest_finish[task_id] = es + timedelta(days=max(1, int(duration)))

        for t in all_tasks:
            if t.id not in earliest_start:
                calc_earliest(t.id)

        # 计算最晚开始/结束时间
        latest_finish: Dict[int, date] = {}
        latest_start: Dict[int, date] = {}

        def calc_latest(task_id: int, project_end: date) -> None:
            task = task_map[task_id]
            lf = task.plan_end_date or project_end
            dependents = backward_deps.get(task_id, [])

            if dependents:
                min_ls = date.max
                for dep_id in dependents:
                    if dep_id not in latest_start:
                        calc_latest(dep_id, project_end)
                    if latest_start[dep_id] < min_ls:
                        min_ls = latest_start[dep_id]
                if min_ls < lf:
                    lf = min_ls

            latest_finish[task_id] = lf
            duration = task.estimated_hours / 8
            latest_start[task_id] = lf - timedelta(days=max(1, int(duration)))

        # 找到项目最晚结束时间
        project_end = max(earliest_finish.values()) if earliest_finish else date.today()
        for t in all_tasks:
            if t.id not in latest_start:
                calc_latest(t.id, project_end)

        # 找出关键路径（总浮动时间为0的任务）
        critical_tasks = []
        for t in all_tasks:
            es = earliest_start.get(t.id, date.today())
            ls = latest_start.get(t.id, date.today())
            total_float = (ls - es).days
            if total_float <= 0:
                critical_tasks.append({
                    "id": t.id,
                    "title": t.title,
                    "wbs_code": t.wbs_code,
                    "status": t.status,
                    "earliest_start": es.isoformat(),
                    "earliest_finish": earliest_finish.get(t.id, es).isoformat(),
                    "latest_start": ls.isoformat(),
                    "latest_finish": latest_finish.get(t.id, ls).isoformat(),
                    "total_float": total_float,
                })

        return critical_tasks
