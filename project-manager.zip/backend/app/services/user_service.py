from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.schemas.user import UserCreate, UserUpdate
from app.models.user import User
from app.models.role import Role, UserRole, Permission, role_permission_table
from app.core.security import hash_password
from app.core.exceptions import BusinessException, NotFoundException


class UserService:
    """用户服务"""

    @staticmethod
    async def create_user(db: AsyncSession, request: UserCreate) -> User:
        """创建用户"""
        # 检查用户名
        result = await db.execute(select(User).where(User.username == request.username))
        if result.scalar_one_or_none() is not None:
            raise BusinessException("用户名已存在")

        # 检查邮箱
        result = await db.execute(select(User).where(User.email == request.email))
        if result.scalar_one_or_none() is not None:
            raise BusinessException("邮箱已存在")

        user = User(
            username=request.username,
            email=request.email,
            hashed_password=hash_password(request.password),
            full_name=request.full_name,
            phone=request.phone,
            department_id=request.department_id,
            is_active=True,
        )
        db.add(user)
        await db.flush()

        # 分配角色
        if request.role_ids:
            for role_id in request.role_ids:
                role_result = await db.execute(select(Role).where(Role.id == role_id))
                role = role_result.scalar_one_or_none()
                if role:
                    user_role = UserRole(user_id=user.id, role_id=role.id)
                    db.add(user_role)

        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def get_user_with_permissions(db: AsyncSession, user_id: int) -> User:
        """获取用户及其权限信息"""
        result = await db.execute(
            select(User)
            .options(
                selectinload(User.roles).selectinload(UserRole.role).selectinload(Role.permissions)
            )
            .where(User.id == user_id)
        )
        user = result.scalar_one_or_none()
        if user is None:
            raise NotFoundException("用户不存在")

        # 提取权限编码列表
        permissions = set()
        for user_role in user.roles:
            if hasattr(user_role, 'role') and user_role.role:
                for perm in user_role.role.permissions:
                    permissions.add(perm.code)

        setattr(user, 'permissions', list(permissions))
        return user

    @staticmethod
    async def update_user(db: AsyncSession, user_id: int, request: UserUpdate) -> User:
        """更新用户"""
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if user is None:
            raise NotFoundException("用户不存在")

        update_data = request.model_dump(exclude_unset=True)
        role_ids = update_data.pop("role_ids", None)

        for key, value in update_data.items():
            setattr(user, key, value)

        # 更新角色
        if role_ids is not None:
            # 删除旧角色
            old_roles = await db.execute(
                select(UserRole).where(UserRole.user_id == user_id)
            )
            for old_role in old_roles.scalars().all():
                await db.delete(old_role)

            # 添加新角色
            for role_id in role_ids:
                role_result = await db.execute(select(Role).where(Role.id == role_id))
                role = role_result.scalar_one_or_none()
                if role:
                    user_role = UserRole(user_id=user.id, role_id=role.id)
                    db.add(user_role)

        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def delete_user(db: AsyncSession, user_id: int) -> None:
        """删除用户（逻辑删除）"""
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if user is None:
            raise NotFoundException("用户不存在")

        user.is_active = False
        await db.commit()
