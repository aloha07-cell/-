from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.auth import LoginRequest, RegisterRequest, TokenResponse
from app.models.user import User
from app.models.role import Role
from app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
    blacklist_token,
    is_token_blacklisted,
)
from app.core.exceptions import UnauthorizedException, BusinessException, NotFoundException


class AuthService:
    """认证服务"""

    @staticmethod
    async def register(db: AsyncSession, request: RegisterRequest) -> User:
        """用户注册"""
        # 检查用户名是否已存在
        result = await db.execute(select(User).where(User.username == request.username))
        if result.scalar_one_or_none() is not None:
            raise BusinessException("用户名已存在")

        # 检查邮箱是否已存在
        result = await db.execute(select(User).where(User.email == request.email))
        if result.scalar_one_or_none() is not None:
            raise BusinessException("邮箱已存在")

        # 分配默认角色
        role_result = await db.execute(select(Role).where(Role.code == "member"))
        default_role = role_result.scalar_one_or_none()

        user = User(
            username=request.username,
            email=request.email,
            hashed_password=hash_password(request.password),
            full_name=request.full_name,
            phone=request.phone,
            is_active=True,
        )
        db.add(user)
        await db.flush()

        if default_role:
            from app.models.role import UserRole
            user_role = UserRole(user_id=user.id, role_id=default_role.id)
            db.add(user_role)

        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def login(db: AsyncSession, username: str, password: str) -> TokenResponse:
        """用户登录"""
        result = await db.execute(select(User).where(User.username == username))
        user = result.scalar_one_or_none()

        if user is None or not verify_password(password, user.hashed_password):
            raise UnauthorizedException("用户名或密码错误")

        if not user.is_active:
            raise UnauthorizedException("账号已被禁用")

        # 更新最后登录时间
        user.last_login_at = datetime.now(timezone.utc)
        await db.commit()

        # 生成令牌
        token_data = {"sub": str(user.id), "username": user.username}
        access_token = create_access_token(token_data)
        refresh_token = create_refresh_token(token_data)

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
        )

    @staticmethod
    async def refresh_token(db: AsyncSession, refresh_token: str) -> TokenResponse:
        """刷新令牌"""
        # 检查黑名单
        if await is_token_blacklisted(refresh_token):
            raise UnauthorizedException("令牌已失效")

        payload = decode_token(refresh_token)
        if payload is None or payload.get("type") != "refresh":
            raise UnauthorizedException("无效的刷新令牌")

        user_id = payload.get("sub")
        if user_id is None:
            raise UnauthorizedException("无效的令牌")

        result = await db.execute(select(User).where(User.id == int(user_id)))
        user = result.scalar_one_or_none()
        if user is None or not user.is_active:
            raise UnauthorizedException("用户不存在或已被禁用")

        # 将旧刷新令牌加入黑名单
        await blacklist_token(refresh_token)

        # 生成新令牌
        token_data = {"sub": str(user.id), "username": user.username}
        new_access_token = create_access_token(token_data)
        new_refresh_token = create_refresh_token(token_data)

        return TokenResponse(
            access_token=new_access_token,
            refresh_token=new_refresh_token,
        )

    @staticmethod
    async def logout(access_token: str) -> None:
        """用户登出"""
        await blacklist_token(access_token)
