import logging

from fastapi import FastAPI

from app.utils.redis import init_redis, close_redis
from app.utils.minio_client import init_minio, ensure_bucket
from app.config import settings

logger = logging.getLogger(__name__)


async def startup(app: FastAPI) -> None:
    """应用启动事件"""
    logger.info("应用启动中...")

    # 初始化 Redis
    try:
        await init_redis()
        logger.info("Redis 连接成功")
    except Exception as e:
        logger.error(f"Redis 连接失败: {e}")

    # 初始化 MinIO
    try:
        init_minio()
        ensure_bucket(settings.COMPUTED_MINIO_BUCKET)
        logger.info("MinIO 连接成功，存储桶已就绪")
    except Exception as e:
        logger.error(f"MinIO 连接失败: {e}")

    logger.info("应用启动完成")


async def shutdown(app: FastAPI) -> None:
    """应用关闭事件"""
    logger.info("应用关闭中...")

    # 关闭 Redis
    try:
        await close_redis()
        logger.info("Redis 连接已关闭")
    except Exception as e:
        logger.error(f"Redis 关闭失败: {e}")

    logger.info("应用已关闭")
