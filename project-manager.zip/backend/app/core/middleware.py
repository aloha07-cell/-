import time
import logging
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.config import settings

logger = logging.getLogger(__name__)

# 限流器
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.RATE_LIMIT_DEFAULT])


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """请求日志中间件"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        method = request.method
        url = str(request.url)
        client_host = request.client.host if request.client else "unknown"

        logger.info(f"请求开始: {method} {url} - 客户端: {client_host}")

        try:
            response = await call_next(request)
        except Exception as exc:
            process_time = time.time() - start_time
            logger.error(
                f"请求异常: {method} {url} - 耗时: {process_time:.3f}s - 错误: {exc}"
            )
            raise

        process_time = time.time() - start_time
        logger.info(
            f"请求完成: {method} {url} - 状态码: {response.status_code} - "
            f"耗时: {process_time:.3f}s"
        )

        response.headers["X-Process-Time"] = f"{process_time:.3f}"
        return response
