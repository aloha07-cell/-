from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


class AppException(Exception):
    """应用基础异常"""
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class NotFoundException(AppException):
    """资源未找到异常"""
    def __init__(self, message: str = "资源未找到"):
        super().__init__(message=message, status_code=404)


class ForbiddenException(AppException):
    """权限不足异常"""
    def __init__(self, message: str = "权限不足"):
        super().__init__(message=message, status_code=403)


class BusinessException(AppException):
    """业务逻辑异常"""
    def __init__(self, message: str = "业务处理失败", status_code: int = 400):
        super().__init__(message=message, status_code=status_code)


class UnauthorizedException(AppException):
    """未认证异常"""
    def __init__(self, message: str = "未认证"):
        super().__init__(message=message, status_code=401)


def register_exception_handlers(app: FastAPI) -> None:
    """注册全局异常处理器"""

    @app.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "code": exc.status_code,
                "message": exc.message,
                "data": None,
            },
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        return JSONResponse(
            status_code=400,
            content={
                "code": 400,
                "message": str(exc),
                "data": None,
            },
        )

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=500,
            content={
                "code": 500,
                "message": "服务器内部错误",
                "data": None,
            },
        )
