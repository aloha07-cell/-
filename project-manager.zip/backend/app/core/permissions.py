from enum import Enum
from functools import wraps
from typing import List

from fastapi import HTTPException, status


class Permission(str, Enum):
    """权限常量枚举"""
    # 用户管理
    USER_VIEW = "user:view"
    USER_CREATE = "user:create"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"

    # 角色管理
    ROLE_VIEW = "role:view"
    ROLE_CREATE = "role:create"
    ROLE_UPDATE = "role:update"
    ROLE_DELETE = "role:delete"

    # 项目管理
    PROJECT_VIEW = "project:view"
    PROJECT_CREATE = "project:create"
    PROJECT_UPDATE = "project:update"
    PROJECT_DELETE = "project:delete"

    # 任务管理
    TASK_VIEW = "task:view"
    TASK_CREATE = "task:create"
    TASK_UPDATE = "task:update"
    TASK_DELETE = "task:delete"

    # 里程碑管理
    MILESTONE_VIEW = "milestone:view"
    MILESTONE_CREATE = "milestone:create"
    MILESTONE_UPDATE = "milestone:update"
    MILESTONE_DELETE = "milestone:delete"

    # 工时管理
    WORKLOG_VIEW = "worklog:view"
    WORKLOG_CREATE = "worklog:create"
    WORKLOG_UPDATE = "worklog:update"
    WORKLOG_DELETE = "worklog:delete"

    # 风险管理
    RISK_VIEW = "risk:view"
    RISK_CREATE = "risk:create"
    RISK_UPDATE = "risk:update"
    RISK_DELETE = "risk:delete"

    # 成本管理
    COST_VIEW = "cost:view"
    COST_CREATE = "cost:create"
    COST_UPDATE = "cost:update"
    COST_DELETE = "cost:delete"

    # 文档管理
    DOCUMENT_VIEW = "document:view"
    DOCUMENT_CREATE = "document:create"
    DOCUMENT_UPDATE = "document:update"
    DOCUMENT_DELETE = "document:delete"

    # 通知管理
    NOTIFICATION_VIEW = "notification:view"
    NOTIFICATION_MANAGE = "notification:manage"

    # 报表
    REPORT_VIEW = "report:view"
    REPORT_EXPORT = "report:export"

    # 系统管理
    SYSTEM_VIEW = "system:view"
    SYSTEM_MANAGE = "system:manage"

    # 审计
    AUDIT_VIEW = "audit:view"


def require_permissions(permissions: List[Permission]):
    """权限校验装饰器工厂

    用于在 API 路由中校验当前用户是否拥有所需权限。
    依赖注入的 current_user 需要携带 permissions 属性。
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user=None, **kwargs):
            if current_user is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="未认证",
                )
            user_permissions = getattr(current_user, "permissions", [])
            for perm in permissions:
                if perm.value not in user_permissions:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"权限不足，需要 {perm.value} 权限",
                    )
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator
