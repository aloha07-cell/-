from typing import TypeVar, Generic, List, Optional
from pydantic import BaseModel, Field
from fastapi import Query

T = TypeVar("T")


class PageParams(BaseModel):
    """分页参数"""
    page: int = Field(default=1, ge=1, description="页码")
    page_size: int = Field(default=20, ge=1, le=100, description="每页数量")

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        return self.page_size


class PaginatedResponse(BaseModel, Generic[T]):
    """通用分页响应"""
    items: List[T]
    total: int = Field(description="总记录数")
    page: int = Field(description="当前页码")
    page_size: int = Field(description="每页数量")
    total_pages: int = Field(description="总页数")

    @classmethod
    def create(cls, items: List[T], total: int, page_params: PageParams) -> "PaginatedResponse[T]":
        total_pages = (total + page_params.page_size - 1) // page_params.page_size
        return cls(
            items=items,
            total=total,
            page=page_params.page,
            page_size=page_params.page_size,
            total_pages=total_pages,
        )


def get_page_params(
    page: int = Query(default=1, ge=1, description="页码"),
    page_size: int = Query(default=20, ge=1, le=100, description="每页数量"),
) -> PageParams:
    """FastAPI 依赖注入：获取分页参数"""
    return PageParams(page=page, page_size=page_size)
