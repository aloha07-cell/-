from minio import Minio

from app.config import settings

minio_client: Minio | None = None


def init_minio() -> Minio:
    """初始化 MinIO 客户端"""
    global minio_client
    minio_client = Minio(
        endpoint=settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )
    return minio_client


def ensure_bucket(bucket_name: str | None = None) -> None:
    """确保存储桶存在，不存在则创建"""
    client = get_minio()
    name = bucket_name or settings.COMPUTED_MINIO_BUCKET
    if not client.bucket_exists(name):
        client.make_bucket(name)


def get_minio() -> Minio:
    """获取 MinIO 客户端实例"""
    if minio_client is None:
        raise RuntimeError("MinIO 未初始化，请先调用 init_minio()")
    return minio_client
