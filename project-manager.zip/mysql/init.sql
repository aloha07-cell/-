-- ============================================
-- 项目管理系统 - 数据库初始化脚本
-- ============================================

CREATE DATABASE IF NOT EXISTS project_manager
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE project_manager;

-- ============================================
-- 1. 用户表 (users)
-- ============================================
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `notification_rules`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `documents`;
DROP TABLE IF EXISTS `cost_records`;
DROP TABLE IF EXISTS `cost_budgets`;
DROP TABLE IF EXISTS `risks`;
DROP TABLE IF EXISTS `work_logs`;
DROP TABLE IF EXISTS `task_dependencies`;
DROP TABLE IF EXISTS `tasks`;
DROP TABLE IF EXISTS `milestones`;
DROP TABLE IF EXISTS `project_members`;
DROP TABLE IF EXISTS `projects`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `system_settings`;

CREATE TABLE `users` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    `username` VARCHAR(50) NOT NULL COMMENT '用户名',
    `email` VARCHAR(100) NOT NULL COMMENT '邮箱',
    `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `hashed_password` VARCHAR(255) NOT NULL COMMENT '密码哈希',
    `avatar` VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
    `department` VARCHAR(100) DEFAULT NULL COMMENT '部门',
    `position` VARCHAR(100) DEFAULT NULL COMMENT '职位',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态: 1-启用, 0-禁用',
    `last_login_at` DATETIME DEFAULT NULL COMMENT '最后登录时间',
    `last_login_ip` VARCHAR(50) DEFAULT NULL COMMENT '最后登录IP',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted_at` DATETIME DEFAULT NULL COMMENT '删除时间(软删除)',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    UNIQUE KEY `uk_email` (`email`),
    KEY `idx_phone` (`phone`),
    KEY `idx_department` (`department`),
    KEY `idx_status` (`status`),
    KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ============================================
-- 2. 角色表 (roles)
-- ============================================
CREATE TABLE `roles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '角色ID',
    `name` VARCHAR(50) NOT NULL COMMENT '角色名称',
    `code` VARCHAR(50) NOT NULL COMMENT '角色编码',
    `description` VARCHAR(255) DEFAULT NULL COMMENT '角色描述',
    `is_system` TINYINT NOT NULL DEFAULT 0 COMMENT '是否系统内置角色: 1-是, 0-否',
    `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态: 1-启用, 0-禁用',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色表';

-- ============================================
-- 3. 权限表 (permissions)
-- ============================================
CREATE TABLE `permissions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '权限ID',
    `name` VARCHAR(100) NOT NULL COMMENT '权限名称',
    `code` VARCHAR(100) NOT NULL COMMENT '权限编码',
    `module` VARCHAR(50) NOT NULL COMMENT '所属模块',
    `description` VARCHAR(255) DEFAULT NULL COMMENT '权限描述',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_code` (`code`),
    KEY `idx_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限表';

-- ============================================
-- 4. 用户角色关联表 (user_roles)
-- ============================================
CREATE TABLE `user_roles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `role_id` BIGINT UNSIGNED NOT NULL COMMENT '角色ID',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_role` (`user_id`, `role_id`),
    KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户角色关联表';

-- ============================================
-- 5. 角色权限关联表 (role_permissions)
-- ============================================
CREATE TABLE `role_permissions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `role_id` BIGINT UNSIGNED NOT NULL COMMENT '角色ID',
    `permission_id` BIGINT UNSIGNED NOT NULL COMMENT '权限ID',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_role_permission` (`role_id`, `permission_id`),
    KEY `idx_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色权限关联表';

-- ============================================
-- 6. 项目表 (projects)
-- ============================================
CREATE TABLE `projects` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '项目ID',
    `name` VARCHAR(200) NOT NULL COMMENT '项目名称',
    `code` VARCHAR(50) NOT NULL COMMENT '项目编码',
    `description` TEXT DEFAULT NULL COMMENT '项目描述',
    `status` VARCHAR(20) NOT NULL DEFAULT 'planning' COMMENT '状态: planning/in_progress/completed/on_hold/cancelled',
    `priority` VARCHAR(20) NOT NULL DEFAULT 'medium' COMMENT '优先级: low/medium/high/critical',
    `start_date` DATE DEFAULT NULL COMMENT '开始日期',
    `end_date` DATE DEFAULT NULL COMMENT '截止日期',
    `actual_start_date` DATE DEFAULT NULL COMMENT '实际开始日期',
    `actual_end_date` DATE DEFAULT NULL COMMENT '实际结束日期',
    `progress` DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT '进度百分比',
    `budget` DECIMAL(15,2) DEFAULT NULL COMMENT '预算金额',
    `owner_id` BIGINT UNSIGNED NOT NULL COMMENT '项目负责人ID',
    `department` VARCHAR(100) DEFAULT NULL COMMENT '所属部门',
    `cover_image` VARCHAR(500) DEFAULT NULL COMMENT '封面图片',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted_at` DATETIME DEFAULT NULL COMMENT '删除时间(软删除)',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_code` (`code`),
    KEY `idx_status` (`status`),
    KEY `idx_owner_id` (`owner_id`),
    KEY `idx_department` (`department`),
    KEY `idx_start_date` (`start_date`),
    KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目表';

-- ============================================
-- 7. 项目成员表 (project_members)
-- ============================================
CREATE TABLE `project_members` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `role` VARCHAR(50) NOT NULL DEFAULT 'member' COMMENT '项目角色: owner/manager/member/viewer',
    `join_date` DATE NOT NULL DEFAULT (CURRENT_DATE) COMMENT '加入日期',
    `leave_date` DATE DEFAULT NULL COMMENT '离开日期',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_project_user` (`project_id`, `user_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目成员表';

-- ============================================
-- 8. 任务表 (tasks)
-- ============================================
CREATE TABLE `tasks` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '任务ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `title` VARCHAR(500) NOT NULL COMMENT '任务标题',
    `description` TEXT DEFAULT NULL COMMENT '任务描述',
    `status` VARCHAR(20) NOT NULL DEFAULT 'todo' COMMENT '状态: todo/in_progress/in_review/done/cancelled',
    `priority` VARCHAR(20) NOT NULL DEFAULT 'medium' COMMENT '优先级: low/medium/high/critical',
    `type` VARCHAR(20) NOT NULL DEFAULT 'task' COMMENT '类型: task/bug/story/epic',
    `assignee_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '指派人ID',
    `reporter_id` BIGINT UNSIGNED NOT NULL COMMENT '报告人ID',
    `milestone_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '里程碑ID',
    `parent_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '父任务ID',
    `story_points` INT DEFAULT NULL COMMENT '故事点数',
    `start_date` DATE DEFAULT NULL COMMENT '开始日期',
    `due_date` DATE DEFAULT NULL COMMENT '截止日期',
    `completed_at` DATETIME DEFAULT NULL COMMENT '完成时间',
    `estimated_hours` DECIMAL(8,2) DEFAULT NULL COMMENT '预估工时',
    `actual_hours` DECIMAL(8,2) DEFAULT NULL COMMENT '实际工时',
    `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted_at` DATETIME DEFAULT NULL COMMENT '删除时间(软删除)',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_assignee_id` (`assignee_id`),
    KEY `idx_reporter_id` (`reporter_id`),
    KEY `idx_milestone_id` (`milestone_id`),
    KEY `idx_parent_id` (`parent_id`),
    KEY `idx_status` (`status`),
    KEY `idx_priority` (`priority`),
    KEY `idx_due_date` (`due_date`),
    KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务表';

-- ============================================
-- 9. 任务依赖表 (task_dependencies)
-- ============================================
CREATE TABLE `task_dependencies` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `task_id` BIGINT UNSIGNED NOT NULL COMMENT '任务ID',
    `depends_on_id` BIGINT UNSIGNED NOT NULL COMMENT '依赖的任务ID',
    `dependency_type` VARCHAR(20) NOT NULL DEFAULT 'finish_to_start' COMMENT '依赖类型: finish_to_start/start_to_start/finish_to_finish/start_to_finish',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_task_dependency` (`task_id`, `depends_on_id`),
    KEY `idx_depends_on_id` (`depends_on_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务依赖表';

-- ============================================
-- 10. 里程碑表 (milestones)
-- ============================================
CREATE TABLE `milestones` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '里程碑ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `name` VARCHAR(200) NOT NULL COMMENT '里程碑名称',
    `description` TEXT DEFAULT NULL COMMENT '描述',
    `due_date` DATE NOT NULL COMMENT '截止日期',
    `status` VARCHAR(20) NOT NULL DEFAULT 'open' COMMENT '状态: open/completed/overdue/cancelled',
    `progress` DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT '进度百分比',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_due_date` (`due_date`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='里程碑表';

-- ============================================
-- 11. 工时记录表 (work_logs)
-- ============================================
CREATE TABLE `work_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '工时记录ID',
    `task_id` BIGINT UNSIGNED NOT NULL COMMENT '任务ID',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `date` DATE NOT NULL COMMENT '日期',
    `hours` DECIMAL(5,2) NOT NULL COMMENT '工时数',
    `description` TEXT DEFAULT NULL COMMENT '工作描述',
    `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending/approved/rejected',
    `approved_by` BIGINT UNSIGNED DEFAULT NULL COMMENT '审批人ID',
    `approved_at` DATETIME DEFAULT NULL COMMENT '审批时间',
    `reject_reason` VARCHAR(500) DEFAULT NULL COMMENT '驳回原因',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_task_id` (`task_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_date` (`date`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工时记录表';

-- ============================================
-- 12. 风险表 (risks)
-- ============================================
CREATE TABLE `risks` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '风险ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `title` VARCHAR(500) NOT NULL COMMENT '风险标题',
    `description` TEXT DEFAULT NULL COMMENT '风险描述',
    `probability` VARCHAR(20) NOT NULL DEFAULT 'medium' COMMENT '发生概率: low/medium/high/very_high',
    `impact` VARCHAR(20) NOT NULL DEFAULT 'medium' COMMENT '影响程度: low/medium/high/very_high',
    `status` VARCHAR(20) NOT NULL DEFAULT 'identified' COMMENT '状态: identified/mitigating/occurred/closed',
    `mitigation_plan` TEXT DEFAULT NULL COMMENT '缓解方案',
    `contingency_plan` TEXT DEFAULT NULL COMMENT '应急方案',
    `owner_id` BIGINT UNSIGNED NOT NULL COMMENT '负责人ID',
    `due_date` DATE DEFAULT NULL COMMENT '处理截止日期',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_status` (`status`),
    KEY `idx_owner_id` (`owner_id`),
    KEY `idx_probability` (`probability`),
    KEY `idx_impact` (`impact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='风险表';

-- ============================================
-- 13. 成本预算表 (cost_budgets)
-- ============================================
CREATE TABLE `cost_budgets` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '预算ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `category` VARCHAR(100) NOT NULL COMMENT '预算类别',
    `name` VARCHAR(200) NOT NULL COMMENT '预算名称',
    `total_amount` DECIMAL(15,2) NOT NULL COMMENT '预算总额',
    `used_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00 COMMENT '已使用金额',
    `description` TEXT DEFAULT NULL COMMENT '描述',
    `fiscal_year` VARCHAR(10) DEFAULT NULL COMMENT '财年',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_category` (`category`),
    KEY `idx_fiscal_year` (`fiscal_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成本预算表';

-- ============================================
-- 14. 成本记录表 (cost_records)
-- ============================================
CREATE TABLE `cost_records` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '成本记录ID',
    `project_id` BIGINT UNSIGNED NOT NULL COMMENT '项目ID',
    `budget_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '预算ID',
    `category` VARCHAR(100) NOT NULL COMMENT '费用类别',
    `amount` DECIMAL(15,2) NOT NULL COMMENT '金额',
    `description` TEXT DEFAULT NULL COMMENT '描述',
    `expense_date` DATE NOT NULL COMMENT '费用日期',
    `invoice_number` VARCHAR(100) DEFAULT NULL COMMENT '发票号',
    `attachment` VARCHAR(500) DEFAULT NULL COMMENT '附件URL',
    `created_by` BIGINT UNSIGNED NOT NULL COMMENT '创建人ID',
    `approved_by` BIGINT UNSIGNED DEFAULT NULL COMMENT '审批人ID',
    `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending/approved/rejected',
    `approved_at` DATETIME DEFAULT NULL COMMENT '审批时间',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_budget_id` (`budget_id`),
    KEY `idx_category` (`category`),
    KEY `idx_expense_date` (`expense_date`),
    KEY `idx_status` (`status`),
    KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成本记录表';

-- ============================================
-- 15. 文档表 (documents)
-- ============================================
CREATE TABLE `documents` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '文档ID',
    `project_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '项目ID',
    `name` VARCHAR(500) NOT NULL COMMENT '文档名称',
    `file_path` VARCHAR(1000) NOT NULL COMMENT '文件路径',
    `file_size` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '文件大小(字节)',
    `file_type` VARCHAR(50) DEFAULT NULL COMMENT '文件类型(MIME)',
    `category` VARCHAR(100) DEFAULT NULL COMMENT '文档分类',
    `description` TEXT DEFAULT NULL COMMENT '描述',
    `version` VARCHAR(20) NOT NULL DEFAULT '1.0' COMMENT '版本号',
    `uploaded_by` BIGINT UNSIGNED NOT NULL COMMENT '上传人ID',
    `is_public` TINYINT NOT NULL DEFAULT 0 COMMENT '是否公开: 1-是, 0-否',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted_at` DATETIME DEFAULT NULL COMMENT '删除时间(软删除)',
    PRIMARY KEY (`id`),
    KEY `idx_project_id` (`project_id`),
    KEY `idx_category` (`category`),
    KEY `idx_uploaded_by` (`uploaded_by`),
    KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文档表';

-- ============================================
-- 16. 通知表 (notifications)
-- ============================================
CREATE TABLE `notifications` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '通知ID',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '接收用户ID',
    `title` VARCHAR(500) NOT NULL COMMENT '通知标题',
    `content` TEXT DEFAULT NULL COMMENT '通知内容',
    `type` VARCHAR(50) NOT NULL COMMENT '通知类型: system/task/project/risk/worklog/mention',
    `priority` VARCHAR(20) NOT NULL DEFAULT 'normal' COMMENT '优先级: low/normal/high/urgent',
    `is_read` TINYINT NOT NULL DEFAULT 0 COMMENT '是否已读: 1-是, 0-否',
    `read_at` DATETIME DEFAULT NULL COMMENT '阅读时间',
    `link` VARCHAR(500) DEFAULT NULL COMMENT '关联链接',
    `sender_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '发送人ID',
    `extra_data` JSON DEFAULT NULL COMMENT '扩展数据',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_type` (`type`),
    KEY `idx_is_read` (`is_read`),
    KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知表';

-- ============================================
-- 17. 通知规则表 (notification_rules)
-- ============================================
CREATE TABLE `notification_rules` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '规则ID',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
    `event_type` VARCHAR(100) NOT NULL COMMENT '事件类型',
    `channel` VARCHAR(50) NOT NULL DEFAULT 'in_app' COMMENT '通知渠道: in_app/email/wecom/sms',
    `is_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用: 1-是, 0-否',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_event_channel` (`user_id`, `event_type`, `channel`),
    KEY `idx_event_type` (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知规则表';

-- ============================================
-- 18. 审计日志表 (audit_logs)
-- ============================================
CREATE TABLE `audit_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '日志ID',
    `user_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '操作用户ID',
    `username` VARCHAR(50) DEFAULT NULL COMMENT '操作用户名',
    `action` VARCHAR(100) NOT NULL COMMENT '操作类型',
    `resource_type` VARCHAR(50) NOT NULL COMMENT '资源类型',
    `resource_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '资源ID',
    `description` TEXT DEFAULT NULL COMMENT '操作描述',
    `request_method` VARCHAR(10) DEFAULT NULL COMMENT '请求方法',
    `request_path` VARCHAR(500) DEFAULT NULL COMMENT '请求路径',
    `request_params` JSON DEFAULT NULL COMMENT '请求参数',
    `response_status` INT DEFAULT NULL COMMENT '响应状态码',
    `ip_address` VARCHAR(50) DEFAULT NULL COMMENT 'IP地址',
    `user_agent` VARCHAR(500) DEFAULT NULL COMMENT '用户代理',
    `duration_ms` INT DEFAULT NULL COMMENT '耗时(毫秒)',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_action` (`action`),
    KEY `idx_resource` (`resource_type`, `resource_id`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志表';

-- ============================================
-- 19. 系统设置表 (system_settings)
-- ============================================
CREATE TABLE `system_settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '设置ID',
    `key` VARCHAR(100) NOT NULL COMMENT '设置键',
    `value` TEXT DEFAULT NULL COMMENT '设置值',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '描述',
    `type` VARCHAR(20) NOT NULL DEFAULT 'string' COMMENT '值类型: string/number/boolean/json',
    `is_system` TINYINT NOT NULL DEFAULT 0 COMMENT '是否系统内置: 1-是, 0-否',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统设置表';

-- ============================================
-- 插入默认角色
-- ============================================
INSERT INTO `roles` (`name`, `code`, `description`, `is_system`, `sort_order`) VALUES
('超级管理员', 'admin', '拥有系统所有权限，可管理用户、角色和系统设置', 1, 1),
('项目经理', 'manager', '可管理项目、任务、成员和工时', 1, 2),
('普通成员', 'member', '可查看项目、提交工时、管理自己的任务', 1, 3);

-- ============================================
-- 插入默认权限
-- ============================================
INSERT INTO `permissions` (`name`, `code`, `module`, `description`) VALUES
('查看项目', 'project:view', 'project', '查看项目列表和详情'),
('创建项目', 'project:create', 'project', '创建新项目'),
('编辑项目', 'project:edit', 'project', '编辑项目信息'),
('删除项目', 'project:delete', 'project', '删除项目'),
('查看任务', 'task:view', 'task', '查看任务列表和详情'),
('创建任务', 'task:create', 'task', '创建新任务'),
('编辑任务', 'task:edit', 'task', '编辑任务信息'),
('删除任务', 'task:delete', 'task', '删除任务'),
('分配任务', 'task:assign', 'task', '将任务分配给成员'),
('提交工时', 'worklog:submit', 'worklog', '提交工时记录'),
('审批工时', 'worklog:approve', 'worklog', '审批工时记录'),
('查看工时', 'worklog:view', 'worklog', '查看工时记录'),
('管理用户', 'user:manage', 'user', '管理系统用户'),
('管理角色', 'role:manage', 'role', '管理系统角色和权限'),
('系统设置', 'system:settings', 'system', '修改系统设置'),
('查看审计日志', 'audit:view', 'audit', '查看系统审计日志');

-- ============================================
-- 插入角色-权限关联
-- ============================================
-- 超级管理员：拥有所有权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions`;

-- 项目经理：项目全部权限 + 任务全部权限 + 工时全部权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions` WHERE `code` IN (
    'project:view', 'project:create', 'project:edit', 'project:delete',
    'task:view', 'task:create', 'task:edit', 'task:delete', 'task:assign',
    'worklog:submit', 'worklog:approve', 'worklog:view'
);

-- 普通成员：查看项目 + 任务查看/创建/编辑 + 工时提交/查看
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, `id` FROM `permissions` WHERE `code` IN (
    'project:view',
    'task:view', 'task:create', 'task:edit',
    'worklog:submit', 'worklog:view'
);

-- ============================================
-- 插入默认管理员账号
-- 密码: admin123 (使用bcrypt哈希)
-- ============================================
INSERT INTO `users` (`username`, `email`, `phone`, `hashed_password`, `department`, `position`, `status`) VALUES
('admin', 'admin@example.com', '13800000000', '$2b$12$F0Qwrh0vb5/d3AIJAl./puR7sKSSGP2N6N.Au0Wilxex35ljZZinO', '技术部', '系统管理员', 1);

-- 为管理员分配超级管理员角色
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES (1, 1);

-- ============================================
-- 插入默认系统设置
-- ============================================
INSERT INTO `system_settings` (`key`, `value`, `description`, `type`, `is_system`) VALUES
('site_name', '项目管理系统', '系统名称', 'string', 1),
('site_description', '企业级项目管理系统', '系统描述', 'string', 1),
('default_page_size', '20', '默认分页大小', 'number', 1),
('max_upload_size', '104857600', '最大上传文件大小(字节)', 'number', 1),
('allow_registration', 'false', '是否允许自主注册', 'boolean', 1),
('wecom_notify_enabled', 'false', '是否启用企微通知', 'boolean', 1),
('email_notify_enabled', 'false', '是否启用邮件通知', 'boolean', 1),
('sms_notify_enabled', 'false', '是否启用短信通知', 'boolean', 1);
