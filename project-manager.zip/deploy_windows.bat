@echo off
chcp 65001 >nul
echo ================================
echo 项目管理系统 - Windows 自动部署脚本
echo ================================
echo.

:: 检查 Docker Desktop 是否安装
echo 1. 检查 Docker Desktop 是否安装...
where docker >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误：未找到 Docker Desktop！
    echo 请先安装 Docker Desktop：https://www.docker.com/products/docker-desktop
    pause
    exit /b 1
)

docker --version >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误：Docker 命令无法执行！
    echo 请确保 Docker Desktop 已启动并正常运行
    pause
    exit /b 1
)
echo ✓ Docker Desktop 已安装

:: 检查 Git 是否安装
echo.
echo 2. 检查 Git 是否安装...
where git >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误：未找到 Git！
    echo 请先安装 Git：https://git-scm.com/downloads
    pause
    exit /b 1
)
git --version >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误：Git 命令无法执行！
    pause
    exit /b 1
)
echo ✓ Git 已安装

:: 检查项目目录是否存在
if not exist "%~dp0\docker-compose.yml" (
    echo 错误：当前目录不是项目根目录！
    echo 请确保在项目根目录运行此脚本
    pause
    exit /b 1
)
echo ✓ 项目目录验证通过

:: 检查并创建 .env 文件
echo.
echo 3. 检查 .env 文件...
if not exist "%~dp0\.env" (
    echo 未找到 .env 文件，正在从 .env.example 创建...
    if exist "%~dp0\.env.example" (
        copy "%~dp0\.env.example" "%~dp0\.env" >nul
        if %errorlevel% equ 0 (
            echo ✓ .env 文件创建成功
        ) else (
            echo 错误：无法创建 .env 文件
            pause
            exit /b 1
        )
    ) else (
        echo 错误：未找到 .env.example 文件
        pause
        exit /b 1
    )
) else (
    echo ✓ .env 文件已存在
)

:: 启动 Docker 服务
echo.
echo 4. 启动 Docker 服务...
echo 正在拉取镜像和启动容器，这可能需要一些时间...
docker-compose up -d
if %errorlevel% neq 0 (
    echo 错误：Docker 服务启动失败！
    echo 请检查 Docker Desktop 是否正常运行，以及网络连接是否正常
    pause
    exit /b 1
)
echo ✓ Docker 服务启动成功

:: 等待服务启动
echo.
echo 5. 等待服务初始化...
echo 正在等待所有服务启动完成（约30秒）...
timeout /t 30 /nobreak >nul

:: 检查服务状态
echo.
echo 6. 检查服务状态...
docker-compose ps
echo.

:: 显示访问地址
echo 7. 部署完成！
echo ================================
echo 服务访问地址：
echo - 前端：http://localhost
echo - 后端 API：http://localhost/api/v1
echo - API 文档：http://localhost/api/v1/docs
echo - MinIO 控制台：http://localhost:9001
echo ================================
echo.
echo 默认登录信息（请在生产环境修改）：
echo - 用户名：admin@example.com
echo - 密码：admin123
echo.
echo 注意：首次启动时，数据库需要初始化，可能需要额外等待几分钟
echo.
pause
