<template>
  <router-view />
</template>

<script setup lang="ts">
// 根组件
</script>

<style lang="scss">
#app {
  width: 100%;
  min-height: 100vh;
}
</style>
