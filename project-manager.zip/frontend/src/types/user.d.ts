/** 用户信息 */
export interface User {
  id: number
  username: string
  email: string
  nickname: string
  avatar: string
  phone: string
  department: string
  position: string
  status: 'active' | 'inactive' | 'locked'
  roles: Role[]
  createdAt: string
  updatedAt: string
}

/** 角色信息 */
export interface Role {
  id: number
  name: string
  code: string
  description: string
  permissions: string[]
  createdAt: string
  updatedAt: string
}

/** 创建用户参数 */
export interface CreateUserParams {
  username: string
  email: string
  nickname: string
  password: string
  phone?: string
  department?: string
  position?: string
  roleIds?: number[]
}

/** 更新用户参数 */
export interface UpdateUserParams extends Partial<CreateUserParams> {
  id: number
}

/** 用户查询参数 */
export interface UserQueryParams {
  page: number
  pageSize: number
  keyword?: string
  status?: string
  department?: string
  roleId?: number
}

/** 创建角色参数 */
export interface CreateRoleParams {
  name: string
  code: string
  description: string
  permissions: string[]
}

/** 更新角色参数 */
export interface UpdateRoleParams extends Partial<CreateRoleParams> {
  id: number
}

/** 权限定义 */
export interface Permission {
  code: string
  name: string
  module: string
  description: string
}
