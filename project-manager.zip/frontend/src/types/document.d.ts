/** 文档类型 */
export type DocumentType = 'requirement' | 'design' | 'meeting' | 'report' | 'plan' | 'other'

/** 文档信息 */
export interface ProjectDocument {
  id: number
  projectId: number
  projectName: string
  name: string
  type: DocumentType
  description: string
  fileUrl: string
  fileSize: number
  mimeType: string
  version: number
  uploadedBy: number
  uploadedByName: string
  createdAt: string
  updatedAt: string
}

/** 创建文档参数 */
export interface CreateDocumentParams {
  projectId: number
  name: string
  type: DocumentType
  description: string
  file: File
}

/** 更新文档参数 */
export interface UpdateDocumentParams {
  id: number
  name?: string
  type?: DocumentType
  description?: string
  file?: File
}

/** 文档查询参数 */
export interface DocumentQueryParams {
  page: number
  pageSize: number
  projectId?: number
  type?: DocumentType
  keyword?: string
  uploadedBy?: number
}
