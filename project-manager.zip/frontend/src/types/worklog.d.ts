/** 工时记录 */
export interface Worklog {
  id: number
  userId: number
  username: string
  nickname: string
  avatar: string
  taskId: number
  taskTitle: string
  projectId: number
  projectName: string
  date: string
  hours: number
  description: string
  createdAt: string
  updatedAt: string
}

/** 创建工时参数 */
export interface CreateWorklogParams {
  taskId: number
  date: string
  hours: number
  description: string
}

/** 更新工时参数 */
export interface UpdateWorklogParams extends Partial<CreateWorklogParams> {
  id: number
}

/** 工时查询参数 */
export interface WorklogQueryParams {
  page: number
  pageSize: number
  userId?: number
  projectId?: number
  taskId?: number
  dateFrom?: string
  dateTo?: string
}

/** 工时统计 */
export interface WorklogStats {
  todayHours: number
  weekHours: number
  monthHours: number
  totalHours: number
  dailyAverage: number
}

/** 每日工时汇总 */
export interface DailyWorklogSummary {
  date: string
  hours: number
  taskCount: number
}
