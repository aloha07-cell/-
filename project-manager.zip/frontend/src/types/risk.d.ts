/** 风险等级 */
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical'

/** 风险状态 */
export type RiskStatus = 'identified' | 'analyzing' | 'mitigating' | 'resolved' | 'closed'

/** 风险信息 */
export interface Risk {
  id: number
  title: string
  description: string
  projectId: number
  projectName: string
  probability: number
  impact: number
  level: RiskLevel
  status: RiskStatus
  category: string
  ownerId: number
  ownerName: string
  mitigationPlan: string
  contingencyPlan: string
  dueDate: string
  resolvedAt: string | null
  createdAt: string
  updatedAt: string
}

/** 创建风险参数 */
export interface CreateRiskParams {
  title: string
  description: string
  projectId: number
  probability: number
  impact: number
  category: string
  ownerId: number
  mitigationPlan: string
  contingencyPlan: string
  dueDate: string
}

/** 更新风险参数 */
export interface UpdateRiskParams extends Partial<CreateRiskParams> {
  id: number
  status?: RiskStatus
}

/** 风险查询参数 */
export interface RiskQueryParams {
  page: number
  pageSize: number
  keyword?: string
  projectId?: number
  level?: RiskLevel
  status?: RiskStatus
  category?: string
}

/** 风险矩阵单元格 */
export interface RiskMatrixCell {
  probability: number
  impact: number
  level: RiskLevel
  count: number
  risks: Risk[]
}
