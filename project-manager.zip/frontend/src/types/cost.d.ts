/** 成本类型 */
export type CostType = 'labor' | 'material' | 'equipment' | 'travel' | 'outsourcing' | 'other'

/** 成本记录 */
export interface CostRecord {
  id: number
  projectId: number
  projectName: string
  taskId: number | null
  taskTitle: string | null
  type: CostType
  amount: number
  description: string
  date: string
  invoiceNumber: string
  attachmentUrl: string
  createdBy: number
  createdByName: string
  createdAt: string
  updatedAt: string
}

/** 创建成本参数 */
export interface CreateCostParams {
  projectId: number
  taskId?: number | null
  type: CostType
  amount: number
  description: string
  date: string
  invoiceNumber?: string
  attachmentUrl?: string
}

/** 更新成本参数 */
export interface UpdateCostParams extends Partial<CreateCostParams> {
  id: number
}

/** 成本查询参数 */
export interface CostQueryParams {
  page: number
  pageSize: number
  projectId?: number
  type?: CostType
  dateFrom?: string
  dateTo?: string
}

/** 预算信息 */
export interface Budget {
  id: number
  projectId: number
  projectName: string
  totalBudget: number
  spentBudget: number
  remainingBudget: number
  laborCost: number
  materialCost: number
  equipmentCost: number
  travelCost: number
  outsourcingCost: number
  otherCost: number
  variance: number
  varianceRate: number
}

/** 成本分析数据 */
export interface CostAnalysis {
  byType: { type: CostType; amount: number; percentage: number }[]
  byMonth: { month: string; planned: number; actual: number }[]
  byProject: { projectId: number; projectName: string; budget: number; spent: number; variance: number }[]
  trend: { date: string; cumulative: number }[]
}
