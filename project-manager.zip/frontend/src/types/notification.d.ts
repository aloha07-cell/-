/** 通知类型 */
export type NotificationType = 'system' | 'task' | 'project' | 'mention' | 'deadline' | 'risk'

/** 通知状态 */
export type NotificationStatus = 'unread' | 'read'

/** 通知信息 */
export interface Notification {
  id: number
  userId: number
  type: NotificationType
  title: string
  content: string
  status: NotificationStatus
  link: string
  senderId: number | null
  senderName: string | null
  senderAvatar: string | null
  createdAt: string
  readAt: string | null
}

/** 通知查询参数 */
export interface NotificationQueryParams {
  page: number
  pageSize: number
  type?: NotificationType
  status?: NotificationStatus
}

/** 通知统计 */
export interface NotificationStats {
  unreadCount: number
  totalCount: number
  byType: { type: NotificationType; count: number }[]
}
