/** 任务状态 */
export type TaskStatus = 'todo' | 'in_progress' | 'in_review' | 'done' | 'cancelled'

/** 任务优先级 */
export type TaskPriority = 'lowest' | 'low' | 'medium' | 'high' | 'highest'

/** 任务信息 */
export interface Task {
  id: number
  title: string
  description: string
  status: TaskStatus
  priority: TaskPriority
  projectId: number
  projectName: string
  parentId: number | null
  assigneeId: number | null
  assigneeName: string | null
  assigneeAvatar: string | null
  reporterId: number
  reporterName: string
  startDate: string
  dueDate: string
  estimatedHours: number
  actualHours: number
  progress: number
  tags: string[]
  order: number
  wbsCode: string
  level: number
  children: Task[]
  createdAt: string
  updatedAt: string
}

/** 创建任务参数 */
export interface CreateTaskParams {
  title: string
  description: string
  status: TaskStatus
  priority: TaskPriority
  projectId: number
  parentId?: number | null
  assigneeId?: number | null
  startDate?: string
  dueDate?: string
  estimatedHours?: number
  tags?: string[]
}

/** 更新任务参数 */
export interface UpdateTaskParams extends Partial<CreateTaskParams> {
  id: number
  progress?: number
  actualHours?: number
}

/** 任务拖拽参数 */
export interface TaskDragParams {
  taskId: number
  status: TaskStatus
  order: number
  targetProjectId?: number
}

/** 看板列 */
export interface KanbanColumn {
  status: TaskStatus
  title: string
  color: string
  tasks: Task[]
}

/** 看板数据 */
export interface KanbanData {
  projectId: number
  columns: KanbanColumn[]
}

/** 任务查询参数 */
export interface TaskQueryParams {
  page: number
  pageSize: number
  keyword?: string
  status?: TaskStatus
  priority?: TaskPriority
  projectId?: number
  assigneeId?: number
  reporterId?: number
  startDateFrom?: string
  startDateTo?: string
  dueDateFrom?: string
  dueDateTo?: string
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
}

/** WBS树节点 */
export interface WbsTreeNode {
  id: number
  title: string
  wbsCode: string
  status: TaskStatus
  priority: TaskPriority
  progress: number
  assigneeName: string | null
  startDate: string
  dueDate: string
  estimatedHours: number
  children: WbsTreeNode[]
}

/** 任务统计 */
export interface TaskStats {
  todo: number
  inProgress: number
  inReview: number
  done: number
  cancelled: number
  total: number
  overdue: number
}
