/** 通用API响应结构 */
export interface ApiResponse<T = any> {
  code: number
  message: string
  data: T
}

/** 分页请求参数 */
export interface PaginationParams {
  page: number
  pageSize: number
}

/** 分页响应数据 */
export interface PaginatedData<T = any> {
  items: T[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

/** 排序参数 */
export interface SortParams {
  sortBy: string
  sortOrder: 'asc' | 'desc'
}

/** 通用查询参数 */
export interface QueryParams extends PaginationParams {
  keyword?: string
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
  [key: string]: any
}

/** ID参数 */
export interface IdParam {
  id: number | string
}

/** 批量ID参数 */
export interface BatchIdsParam {
  ids: (number | string)[]
}

/** 选项类型 */
export interface Option {
  label: string
  value: string | number
}

/** 文件上传响应 */
export interface UploadResponse {
  url: string
  filename: string
  size: number
  mimeType: string
}

/** 树形节点 */
export interface TreeNode {
  id: number | string
  label: string
  children?: TreeNode[]
  [key: string]: any
}
