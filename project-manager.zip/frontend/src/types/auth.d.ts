/** 登录请求参数 */
export interface LoginParams {
  username: string
  password: string
  remember?: boolean
}

/** 注册请求参数 */
export interface RegisterParams {
  username: string
  email: string
  password: string
  confirmPassword: string
}

/** 登录响应数据 */
export interface LoginResult {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresIn: number
}

/** Token信息 */
export interface TokenInfo {
  accessToken: string
  refreshToken: string
  expiresAt: number
}

/** 当前用户信息 */
export interface CurrentUser {
  id: number
  username: string
  email: string
  avatar: string
  nickname: string
  roles: string[]
  permissions: string[]
}

/** 刷新Token请求 */
export interface RefreshTokenParams {
  refreshToken: string
}

/** 修改密码参数 */
export interface ChangePasswordParams {
  oldPassword: string
  newPassword: string
  confirmPassword: string
}
