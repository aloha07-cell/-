/** 项目状态 */
export type ProjectStatus = 'not_started' | 'in_progress' | 'on_hold' | 'completed' | 'cancelled'

/** 项目优先级 */
export type ProjectPriority = 'low' | 'medium' | 'high' | 'critical'

/** 项目信息 */
export interface Project {
  id: number
  name: string
  code: string
  description: string
  status: ProjectStatus
  priority: ProjectPriority
  startDate: string
  endDate: string
  budget: number
  spentBudget: number
  progress: number
  ownerId: number
  ownerName: string
  memberCount: number
  taskCount: number
  completedTaskCount: number
  coverImage: string
  tags: string[]
  createdAt: string
  updatedAt: string
}

/** 创建项目参数 */
export interface CreateProjectParams {
  name: string
  code: string
  description: string
  status: ProjectStatus
  priority: ProjectPriority
  startDate: string
  endDate: string
  budget: number
  ownerId: number
  tags: string[]
  coverImage?: string
}

/** 更新项目参数 */
export interface UpdateProjectParams extends Partial<CreateProjectParams> {
  id: number
}

/** 项目成员 */
export interface ProjectMember {
  id: number
  userId: number
  username: string
  nickname: string
  avatar: string
  email: string
  role: string
  joinedAt: string
}

/** 添加项目成员参数 */
export interface AddProjectMemberParams {
  projectId: number
  userId: number
  role: string
}

/** 项目统计 */
export interface ProjectStats {
  totalProjects: number
  inProgressProjects: number
  completedProjects: number
  overdueProjects: number
  totalBudget: number
  totalSpent: number
}

/** 项目查询参数 */
export interface ProjectQueryParams {
  page: number
  pageSize: number
  keyword?: string
  status?: ProjectStatus
  priority?: ProjectPriority
  ownerId?: number
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
}
