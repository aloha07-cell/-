import { createRouter, createWebHistory } from 'vue-router'
import type { App } from 'vue'
import { routes } from './routes'
import { setupGuards } from './guards'

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(_to, _from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    }
    return { top: 0 }
  },
})

setupGuards(router)

export function setupRouter(app: App) {
  app.use(router)
}

export default router
