import type { RouteRecordRaw } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import BlankLayout from '@/layouts/BlankLayout.vue'

export const routes: RouteRecordRaw[] = [
  {
    path: '/auth',
    component: BlankLayout,
    redirect: '/auth/login',
    children: [
      {
        path: 'login',
        name: 'Login',
        component: () => import('@/views/auth/Login.vue'),
        meta: { title: '登录', requiresAuth: false },
      },
      {
        path: 'register',
        name: 'Register',
        component: () => import('@/views/auth/Register.vue'),
        meta: { title: '注册', requiresAuth: false },
      },
    ],
  },
  {
    path: '/',
    component: DefaultLayout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/Index.vue'),
        meta: { title: '工作台', icon: 'Odometer', requiresAuth: true },
      },
      {
        path: 'projects',
        name: 'ProjectList',
        component: () => import('@/views/project/ProjectList.vue'),
        meta: { title: '项目列表', icon: 'Folder', requiresAuth: true, permission: 'project:view' },
      },
      {
        path: 'projects/create',
        name: 'ProjectCreate',
        component: () => import('@/views/project/ProjectCreate.vue'),
        meta: { title: '创建项目', requiresAuth: true, permission: 'project:create', hidden: true },
      },
      {
        path: 'projects/:id',
        name: 'ProjectDetail',
        component: () => import('@/views/project/ProjectDetail.vue'),
        meta: { title: '项目详情', requiresAuth: true, permission: 'project:view', hidden: true },
      },
      {
        path: 'tasks',
        name: 'TaskList',
        component: () => import('@/views/task/TaskListView.vue'),
        meta: { title: '任务列表', icon: 'List', requiresAuth: true, permission: 'task:view' },
      },
      {
        path: 'tasks/kanban',
        name: 'TaskKanban',
        component: () => import('@/views/task/TaskKanbanView.vue'),
        meta: { title: '看板视图', icon: 'Grid', requiresAuth: true, permission: 'task:view' },
      },
      {
        path: 'tasks/gantt',
        name: 'TaskGantt',
        component: () => import('@/views/task/TaskGanttView.vue'),
        meta: { title: '甘特图', icon: 'Calendar', requiresAuth: true, permission: 'task:view' },
      },
      {
        path: 'worklogs',
        name: 'WorklogList',
        component: () => import('@/views/worklog/WorklogList.vue'),
        meta: { title: '工时记录', icon: 'Timer', requiresAuth: true, permission: 'worklog:view' },
      },
      {
        path: 'worklogs/submit',
        name: 'WorklogSubmit',
        component: () => import('@/views/worklog/WorklogSubmit.vue'),
        meta: { title: '工时填报', requiresAuth: true, permission: 'worklog:create', hidden: true },
      },
      {
        path: 'risks',
        name: 'RiskList',
        component: () => import('@/views/risk/RiskList.vue'),
        meta: { title: '风险管理', icon: 'Warning', requiresAuth: true, permission: 'risk:view' },
      },
      {
        path: 'risks/matrix',
        name: 'RiskMatrix',
        component: () => import('@/views/risk/RiskMatrix.vue'),
        meta: { title: '风险矩阵', requiresAuth: true, permission: 'risk:view', hidden: true },
      },
      {
        path: 'costs',
        name: 'BudgetList',
        component: () => import('@/views/cost/BudgetList.vue'),
        meta: { title: '预算管理', icon: 'Money', requiresAuth: true, permission: 'cost:view' },
      },
      {
        path: 'costs/records',
        name: 'CostRecord',
        component: () => import('@/views/cost/CostRecord.vue'),
        meta: { title: '成本记录', requiresAuth: true, permission: 'cost:view', hidden: true },
      },
      {
        path: 'costs/analysis',
        name: 'CostAnalysis',
        component: () => import('@/views/cost/CostAnalysis.vue'),
        meta: { title: '成本分析', requiresAuth: true, permission: 'cost:view', hidden: true },
      },
      {
        path: 'documents',
        name: 'DocumentList',
        component: () => import('@/views/document/DocumentList.vue'),
        meta: { title: '文档管理', icon: 'Document', requiresAuth: true, permission: 'document:view' },
      },
      {
        path: 'reports/progress',
        name: 'ProgressReport',
        component: () => import('@/views/report/ProgressReport.vue'),
        meta: { title: '进度报表', icon: 'DataLine', requiresAuth: true, permission: 'report:view' },
      },
      {
        path: 'reports/worklog',
        name: 'WorklogReport',
        component: () => import('@/views/report/WorklogReport.vue'),
        meta: { title: '工时报表', requiresAuth: true, permission: 'report:view', hidden: true },
      },
      {
        path: 'reports/cost',
        name: 'CostReport',
        component: () => import('@/views/report/CostReport.vue'),
        meta: { title: '成本报表', requiresAuth: true, permission: 'report:view', hidden: true },
      },
      {
        path: 'notifications',
        name: 'NotificationCenter',
        component: () => import('@/views/notification/NotificationCenter.vue'),
        meta: { title: '消息中心', icon: 'Bell', requiresAuth: true },
      },
      {
        path: 'system',
        redirect: '/system/users',
        meta: { title: '系统管理', icon: 'Setting', requiresAuth: true, permission: 'system:view' },
        children: [
          {
            path: 'users',
            name: 'UserManage',
            component: () => import('@/views/system/UserManage.vue'),
            meta: { title: '用户管理', requiresAuth: true, permission: 'system:user:view' },
          },
          {
            path: 'roles',
            name: 'RoleManage',
            component: () => import('@/views/system/RoleManage.vue'),
            meta: { title: '角色管理', requiresAuth: true, permission: 'system:role:view' },
          },
          {
            path: 'audit-log',
            name: 'AuditLog',
            component: () => import('@/views/system/AuditLog.vue'),
            meta: { title: '审计日志', requiresAuth: true, permission: 'system:audit:view' },
          },
          {
            path: 'settings',
            name: 'SystemSettings',
            component: () => import('@/views/system/SystemSettings.vue'),
            meta: { title: '系统设置', requiresAuth: true, permission: 'system:settings:view' },
          },
        ],
      },
    ],
  },
  {
    path: '/403',
    name: 'Forbidden',
    component: () => import('@/views/error/403.vue'),
    meta: { title: '无权限', requiresAuth: false },
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/error/404.vue'),
    meta: { title: '页面不存在', requiresAuth: false },
  },
]
