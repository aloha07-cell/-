import type { Router } from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getAccessToken } from '@/utils/auth'
import { useUserStore } from '@/stores/useUserStore'
import { hasPermission } from '@/utils/permission'

NProgress.configure({ showSpinner: false })

const WHITE_LIST = ['/auth/login', '/auth/register', '/403', '/404']

export function setupGuards(router: Router) {
  router.beforeEach(async (to, _from, next) => {
    NProgress.start()

    const token = getAccessToken()

    if (token) {
      if (to.path === '/auth/login') {
        next({ path: '/' })
        NProgress.done()
        return
      }

      const userStore = useUserStore()
      if (!userStore.userInfo) {
        try {
          await userStore.fetchUserInfo()
        } catch {
          userStore.logout()
          next({ path: '/auth/login', query: { redirect: to.fullPath } })
          NProgress.done()
          return
        }
      }

      const requiredPermission = to.meta.permission as string | undefined
      if (requiredPermission && !hasPermission(requiredPermission)) {
        next({ path: '/403' })
        NProgress.done()
        return
      }

      next()
    } else {
      if (WHITE_LIST.includes(to.path)) {
        next()
      } else {
        next({ path: '/auth/login', query: { redirect: to.fullPath } })
      }
      NProgress.done()
    }
  })

  router.afterEach((to) => {
    NProgress.done()
    const title = to.meta.title as string
    if (title) {
      document.title = `${title} - 项目管理系统`
    }
  })
}
