<template>
  <div class="task-card" @click="$emit('click')">
    <div class="card-header">
      <span class="card-id">#{{ task.id }}</span>
      <StatusTag :status="task.priority" type="taskPriority" size="small" />
    </div>
    <div class="card-title text-ellipsis">{{ task.title }}</div>
    <div v-if="task.description" class="card-desc text-ellipsis">{{ task.description }}</div>
    <div class="card-footer">
      <div class="card-tags">
        <el-tag v-for="tag in task.tags?.slice(0, 2)" :key="tag" size="small" type="info" effect="plain">
          {{ tag }}
        </el-tag>
      </div>
      <UserAvatar v-if="task.assigneeName" :name="task.assigneeName" :src="task.assigneeAvatar || ''" :size="24" />
    </div>
    <div v-if="task.dueDate" class="card-due" :class="{ overdue: isOverdue }">
      <el-icon :size="12"><Clock /></el-icon>
      <span>{{ formatDate(task.dueDate) }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Task } from '@/types/task'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import { Clock } from '@element-plus/icons-vue'
import { formatDate, isOverdue as checkOverdue } from '@/utils/date'

const props = defineProps<{
  task: Task
}>()

defineEmits<{
  click: []
}>()

const isOverdue = computed(() => {
  if (props.task.status === 'done' || props.task.status === 'cancelled') return false
  return checkOverdue(props.task.dueDate)
})
</script>

<style lang="scss" scoped>
.task-card {
  background: $bg-white;
  border-radius: $border-radius-md;
  padding: $spacing-base;
  cursor: pointer;
  box-shadow: $shadow-sm;
  transition: box-shadow $transition-duration, transform $transition-duration;
  border: 1px solid $border-lighter;

  &:hover {
    box-shadow: $shadow-md;
    transform: translateY(-1px);
  }
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: $spacing-sm;
}

.card-id {
  font-size: $font-size-xs;
  color: $text-secondary;
}

.card-title {
  font-size: $font-size-base;
  font-weight: $font-weight-medium;
  color: $text-primary;
  margin-bottom: $spacing-sm;
  line-height: $line-height-tight;
}

.card-desc {
  font-size: $font-size-xs;
  color: $text-secondary;
  margin-bottom: $spacing-sm;
}

.card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: $spacing-sm;
}

.card-tags {
  display: flex;
  gap: $spacing-xs;
}

.card-due {
  display: flex;
  align-items: center;
  gap: $spacing-xs;
  font-size: $font-size-xs;
  color: $text-secondary;
  margin-top: $spacing-sm;

  &.overdue {
    color: $danger-color;
  }
}
</style>
