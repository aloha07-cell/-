<template>
  <div class="gantt-view">
    <div class="gantt-toolbar">
      <el-button-group>
        <el-button size="small" :type="viewMode === 'day' ? 'primary' : ''" @click="viewMode = 'day'">日</el-button>
        <el-button size="small" :type="viewMode === 'week' ? 'primary' : ''" @click="viewMode = 'week'">周</el-button>
        <el-button size="small" :type="viewMode === 'month' ? 'primary' : ''" @click="viewMode = 'month'">月</el-button>
      </el-button-group>
      <el-button size="small" @click="expandAll">展开全部</el-button>
      <el-button size="small" @click="collapseAll">折叠全部</el-button>
    </div>

    <div class="gantt-container">
      <GanttChart
        :bars="ganttBars"
        :options="ganttOptions"
        :dynamic-style="dynamicStyle"
        @click-bar="handleBarClick"
      >
        <template #bar-label="{ bar }">
          <span class="bar-label">{{ bar.label }}</span>
        </template>
      </GanttChart>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { GanttChart } from '@infectoone/vue-ganttastic'
import type { Task } from '@/types/task'
import { getTaskStatusColor } from '@/utils/constants'

const props = defineProps<{
  tasks: Task[]
}>()

const emit = defineEmits<{
  taskClick: [task: Task]
}>()

const viewMode = ref<'day' | 'week' | 'month'>('day')
const expandedTasks = ref<Set<number>>(new Set())

const ganttOptions = computed(() => ({
  viewMode: viewMode.value,
  maxRows: 100,
  maxHeight: 600,
  rowHeight: 40,
  headerHeight: 50,
  barHeight: 24,
  ganttStyle: {
    grid: '#EBEEF5',
  },
}))

const ganttBars = computed(() => {
  function buildBars(tasks: Task[], level: number = 0): any[] {
    return tasks.map((task) => {
      const isExpanded = expandedTasks.value.has(task.id)
      const children = isExpanded && task.children ? buildBars(task.children, level + 1) : []
      return {
        id: task.id,
        label: task.title,
        ganttBarConfig: {
          id: `bar-${task.id}`,
          label: task.title,
          hasLinks: false,
          style: {
            background: getTaskStatusColor(task.status),
            borderRadius: '4px',
          },
          start: task.startDate || new Date().toISOString(),
          end: task.dueDate || new Date().toISOString(),
        },
        children,
      }
    })
  }
  return buildBars(props.tasks.filter((t) => !t.parentId))
})

const dynamicStyle = computed(() => ({
  bar: {
    borderRadius: '4px',
  },
}))

function handleBarClick(bar: any) {
  const taskId = bar.id || bar.ganttBarConfig?.id?.replace('bar-', '')
  const task = props.tasks.find((t) => t.id === Number(taskId))
  if (task) {
    emit('taskClick', task)
  }
}

function expandAll() {
  props.tasks.forEach((t) => expandedTasks.value.add(t.id))
}

function collapseAll() {
  expandedTasks.value.clear()
}
</script>

<style lang="scss" scoped>
.gantt-view {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.gantt-toolbar {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  margin-bottom: $spacing-base;
  padding: $spacing-sm $spacing-base;
  background: $bg-white;
  border-radius: $border-radius-md;
  box-shadow: $shadow-sm;
}

.gantt-container {
  flex: 1;
  overflow: auto;
  background: $bg-white;
  border-radius: $border-radius-md;
  box-shadow: $shadow-sm;
}

.bar-label {
  font-size: $font-size-xs;
  color: white;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 0 $spacing-xs;
}
</style>
