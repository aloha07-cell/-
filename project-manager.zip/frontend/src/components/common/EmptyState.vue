<template>
  <div class="empty-state">
    <el-empty :description="description" :image-size="imageSize">
      <template v-if="showAction" #default>
        <el-button type="primary" @click="$emit('action')">{{ actionText }}</el-button>
      </template>
    </el-empty>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  description?: string
  imageSize?: number
  showAction?: boolean
  actionText?: string
}>(), {
  description: '暂无数据',
  imageSize: 120,
  showAction: false,
  actionText: '立即创建',
})

defineEmits<{
  action: []
}>()
</script>

<style lang="scss" scoped>
.empty-state {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: $spacing-xxl;
  min-height: 200px;
}
</style>
