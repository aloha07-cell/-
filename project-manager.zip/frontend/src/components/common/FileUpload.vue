<template>
  <div class="file-upload">
    <el-upload
      :action="uploadUrl"
      :headers="headers"
      :before-upload="beforeUpload"
      :on-success="handleSuccess"
      :on-error="handleError"
      :on-remove="handleRemove"
      :on-progress="handleProgress"
      :accept="accept"
      :disabled="disabled"
      :multiple="multiple"
      :file-list="fileList"
      :limit="limit"
      :on-exceed="handleExceed"
      drag
      class="file-uploader"
    >
      <el-icon class="upload-icon"><UploadFilled /></el-icon>
      <div class="upload-text">
        将文件拖到此处，或<em>点击上传</em>
      </div>
      <template #tip>
        <div v-if="tip" class="upload-tip">{{ tip }}</div>
      </template>
    </el-upload>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'
import { getAccessToken } from '@/utils/auth'

const props = withDefaults(defineProps<{
  modelValue: string[]
  accept?: string
  maxSize?: number
  tip?: string
  disabled?: boolean
  multiple?: boolean
  limit?: number
}>(), {
  modelValue: () => [],
  accept: '',
  maxSize: 50,
  tip: '',
  disabled: false,
  multiple: true,
  limit: 5,
})

const emit = defineEmits<{
  'update:modelValue': [value: string[]]
}>()

const uploadUrl = '/api/upload/file'
const headers = computed(() => ({
  Authorization: `Bearer ${getAccessToken()}`,
}))

const fileList = ref<any[]>([])

watch(
  () => props.modelValue,
  (val) => {
    fileList.value = val.map((url, index) => ({
      name: `文件${index + 1}`,
      url,
    }))
  },
  { immediate: true }
)

function beforeUpload(file: File) {
  const isValidSize = file.size / 1024 / 1024 < props.maxSize
  if (!isValidSize) {
    ElMessage.error(`文件大小不能超过 ${props.maxSize}MB`)
    return false
  }
  return true
}

function handleSuccess(response: any) {
  const url = response.data?.url || response.url
  const newUrls = [...props.modelValue, url]
  emit('update:modelValue', newUrls)
}

function handleError() {
  ElMessage.error('文件上传失败')
}

function handleRemove(file: any) {
  const url = file.url || file.response?.data?.url
  const newUrls = props.modelValue.filter((u) => u !== url)
  emit('update:modelValue', newUrls)
}

function handleProgress(event: any) {
  // progress handling
}

function handleExceed() {
  ElMessage.warning(`最多只能上传 ${props.limit} 个文件`)
}
</script>

<style lang="scss" scoped>
.file-upload {
  width: 100%;
}

.upload-icon {
  font-size: 48px;
  color: $text-placeholder;
  margin-bottom: $spacing-sm;
}

.upload-text {
  color: $text-regular;
  font-size: $font-size-sm;

  em {
    color: $primary-color;
    font-style: normal;
  }
}

.upload-tip {
  font-size: $font-size-xs;
  color: $text-secondary;
  margin-top: $spacing-xs;
}
</style>
