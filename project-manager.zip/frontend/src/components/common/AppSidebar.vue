<template>
  <div class="app-sidebar">
    <div class="sidebar-logo">
      <el-icon :size="28" color="#409EFF"><DataLine /></el-icon>
      <span v-show="!appStore.sidebarCollapsed" class="logo-text">项目管理</span>
    </div>

    <el-scrollbar>
      <el-menu
        :default-active="activeMenu"
        :collapse="appStore.sidebarCollapsed"
        :collapse-transition="false"
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
        router
      >
        <el-menu-item index="/dashboard">
          <el-icon><Odometer /></el-icon>
          <template #title>工作台</template>
        </el-menu-item>

        <el-sub-menu index="projects">
          <template #title>
            <el-icon><Folder /></el-icon>
            <span>项目管理</span>
          </template>
          <el-menu-item index="/projects">项目列表</el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="tasks">
          <template #title>
            <el-icon><List /></el-icon>
            <span>任务管理</span>
          </template>
          <el-menu-item index="/tasks">任务列表</el-menu-item>
          <el-menu-item index="/tasks/kanban">看板视图</el-menu-item>
          <el-menu-item index="/tasks/gantt">甘特图</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/worklogs">
          <el-icon><Timer /></el-icon>
          <template #title>工时管理</template>
        </el-menu-item>

        <el-menu-item index="/risks">
          <el-icon><Warning /></el-icon>
          <template #title>风险管理</template>
        </el-menu-item>

        <el-sub-menu index="costs">
          <template #title>
            <el-icon><Money /></el-icon>
            <span>成本管理</span>
          </template>
          <el-menu-item index="/costs">预算管理</el-menu-item>
          <el-menu-item index="/costs/records">成本记录</el-menu-item>
          <el-menu-item index="/costs/analysis">成本分析</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/documents">
          <el-icon><Document /></el-icon>
          <template #title>文档管理</template>
        </el-menu-item>

        <el-sub-menu index="reports">
          <template #title>
            <el-icon><DataLine /></el-icon>
            <span>报表中心</span>
          </template>
          <el-menu-item index="/reports/progress">进度报表</el-menu-item>
          <el-menu-item index="/reports/worklog">工时报表</el-menu-item>
          <el-menu-item index="/reports/cost">成本报表</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/notifications">
          <el-icon><Bell /></el-icon>
          <template #title>消息中心</template>
        </el-menu-item>

        <el-sub-menu v-if="userStore.hasRole(['admin', 'super_admin'])" index="system">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>系统管理</span>
          </template>
          <el-menu-item index="/system/users">用户管理</el-menu-item>
          <el-menu-item index="/system/roles">角色管理</el-menu-item>
          <el-menu-item index="/system/audit-log">审计日志</el-menu-item>
          <el-menu-item index="/system/settings">系统设置</el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useAppStore } from '@/stores/useAppStore'
import { useUserStore } from '@/stores/useUserStore'
import { Odometer, Folder, List, Timer, Warning, Money, Document, DataLine, Bell, Setting } from '@element-plus/icons-vue'

const route = useRoute()
const appStore = useAppStore()
const userStore = useUserStore()

const activeMenu = computed(() => route.path)
</script>

<style lang="scss" scoped>
.app-sidebar {
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: #304156;
}

.sidebar-logo {
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: $spacing-sm;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  flex-shrink: 0;
}

.logo-text {
  font-size: $font-size-lg;
  font-weight: $font-weight-bold;
  color: #fff;
  white-space: nowrap;
}

:deep(.el-menu) {
  border-right: none;
}

:deep(.el-menu-item.is-active) {
  background-color: #263445 !important;
}

:deep(.el-sub-menu__title:hover),
:deep(.el-menu-item:hover) {
  background-color: #263445 !important;
}
</style>
