<template>
  <el-avatar :size="size" :src="src" :style="avatarStyle">
    {{ initial }}
  </el-avatar>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  src?: string
  name?: string
  size?: number
}>(), {
  size: 32,
  name: '',
  src: '',
})

const initial = computed(() => {
  if (!props.name) return '?'
  return props.name.charAt(0).toUpperCase()
})

const avatarStyle = computed(() => {
  const colors = ['#409EFF', '#67C23A', '#E6A23C', '#F56C6C', '#909399', '#764ba2', '#667eea']
  const index = props.name ? props.name.charCodeAt(0) % colors.length : 0
  return {
    backgroundColor: colors[index],
    fontSize: `${Math.max(props.size * 0.4, 12)}px`,
  }
})
</script>
