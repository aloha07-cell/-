<template>
  <div class="image-upload">
    <el-upload
      :action="uploadUrl"
      :headers="headers"
      :show-file-list="false"
      :before-upload="beforeUpload"
      :on-success="handleSuccess"
      :on-error="handleError"
      :accept="accept"
      :disabled="disabled"
      :multiple="multiple"
      list-type="picture-card"
      class="image-uploader"
    >
      <img v-if="modelValue" :src="modelValue" class="upload-image" />
      <el-icon v-else class="upload-icon"><Plus /></el-icon>
    </el-upload>
    <div v-if="tip" class="upload-tip">{{ tip }}</div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import { getAccessToken } from '@/utils/auth'

const props = withDefaults(defineProps<{
  modelValue: string
  accept?: string
  maxSize?: number
  tip?: string
  disabled?: boolean
  multiple?: boolean
}>(), {
  accept: '.jpg,.jpeg,.png,.gif,.webp',
  maxSize: 5,
  tip: '',
  disabled: false,
  multiple: false,
})

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const uploadUrl = '/api/upload/image'
const headers = computed(() => ({
  Authorization: `Bearer ${getAccessToken()}`,
}))

function beforeUpload(file: File) {
  const isValidType = props.accept.split(',').some((type) => file.name.toLowerCase().endsWith(type.trim()))
  if (!isValidType) {
    ElMessage.error(`只能上传 ${props.accept} 格式的图片`)
    return false
  }
  const isValidSize = file.size / 1024 / 1024 < props.maxSize
  if (!isValidSize) {
    ElMessage.error(`图片大小不能超过 ${props.maxSize}MB`)
    return false
  }
  return true
}

function handleSuccess(response: any) {
  const url = response.data?.url || response.url
  emit('update:modelValue', url)
}

function handleError() {
  ElMessage.error('图片上传失败')
}
</script>

<style lang="scss" scoped>
.image-upload {
  display: inline-block;
}

.upload-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.upload-icon {
  font-size: 28px;
  color: $text-placeholder;
}

.upload-tip {
  font-size: $font-size-xs;
  color: $text-secondary;
  margin-top: $spacing-xs;
}
</style>
