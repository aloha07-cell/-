<template>
  <div class="app-header">
    <div class="header-left">
      <el-icon class="collapse-btn" @click="appStore.toggleSidebar">
        <Fold v-if="!appStore.sidebarCollapsed" />
        <Expand v-else />
      </el-icon>
    </div>

    <div class="header-right">
      <!-- 通知铃铛 -->
      <el-badge :value="notificationStore.unreadCount" :hidden="notificationStore.unreadCount === 0" class="notification-badge">
        <el-icon class="header-icon" @click="goToNotifications">
          <Bell />
        </el-icon>
      </el-badge>

      <!-- 用户信息 -->
      <el-dropdown trigger="click" @command="handleCommand">
        <div class="user-info">
          <UserAvatar :src="userStore.avatar" :name="userStore.nickname" :size="32" />
          <span class="user-name hide-on-mobile">{{ userStore.nickname }}</span>
          <el-icon><ArrowDown /></el-icon>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="profile">
              <el-icon><User /></el-icon>个人中心
            </el-dropdown-item>
            <el-dropdown-item command="settings">
              <el-icon><Setting /></el-icon>系统设置
            </el-dropdown-item>
            <el-dropdown-item divided command="logout">
              <el-icon><SwitchButton /></el-icon>退出登录
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores/useAppStore'
import { useUserStore } from '@/stores/useUserStore'
import { useNotificationStore } from '@/stores/useNotificationStore'
import UserAvatar from './UserAvatar.vue'
import { Fold, Expand, Bell, ArrowDown, User, Setting, SwitchButton } from '@element-plus/icons-vue'

const router = useRouter()
const appStore = useAppStore()
const userStore = useUserStore()
const notificationStore = useNotificationStore()

function goToNotifications() {
  router.push('/notifications')
}

async function handleCommand(command: string) {
  switch (command) {
    case 'profile':
      break
    case 'settings':
      router.push('/system/settings')
      break
    case 'logout':
      await userStore.logout()
      router.push('/auth/login')
      break
  }
}
</script>

<style lang="scss" scoped>
.app-header {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 $spacing-base;
}

.header-left {
  display: flex;
  align-items: center;
}

.collapse-btn {
  font-size: 20px;
  cursor: pointer;
  color: $text-regular;
  padding: $spacing-sm;
  border-radius: $border-radius-base;
  transition: background-color $transition-duration;

  &:hover {
    background-color: $bg-color;
    color: $primary-color;
  }
}

.header-right {
  display: flex;
  align-items: center;
  gap: $spacing-base;
}

.header-icon {
  font-size: 20px;
  cursor: pointer;
  color: $text-regular;
  padding: $spacing-sm;
  border-radius: $border-radius-base;
  transition: background-color $transition-duration;

  &:hover {
    background-color: $bg-color;
    color: $primary-color;
  }
}

.notification-badge {
  line-height: 1;
}

.user-info {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  cursor: pointer;
  padding: $spacing-xs $spacing-sm;
  border-radius: $border-radius-base;
  transition: background-color $transition-duration;

  &:hover {
    background-color: $bg-color;
  }
}

.user-name {
  font-size: $font-size-base;
  color: $text-primary;
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
