<template>
  <el-dialog
    v-model="visible"
    :title="title"
    :width="width"
    :type="type"
    :close-on-click-modal="false"
    @close="handleCancel"
  >
    <div class="confirm-content">
      <el-icon v-if="type === 'warning'" class="confirm-icon warning"><WarningFilled /></el-icon>
      <el-icon v-else-if="type === 'danger'" class="confirm-icon danger"><CircleCloseFilled /></el-icon>
      <el-icon v-else class="confirm-icon info"><InfoFilled /></el-icon>
      <p class="confirm-message">{{ message }}</p>
    </div>

    <template #footer>
      <el-button @click="handleCancel">{{ cancelText }}</el-button>
      <el-button :type="confirmButtonType" :loading="loading" @click="handleConfirm">
        {{ confirmText }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { WarningFilled, CircleCloseFilled, InfoFilled } from '@element-plus/icons-vue'

const props = withDefaults(defineProps<{
  modelValue: boolean
  title?: string
  message: string
  type?: 'warning' | 'danger' | 'info'
  confirmText?: string
  cancelText?: string
  width?: string
  loading?: boolean
}>(), {
  title: '确认操作',
  type: 'warning',
  confirmText: '确定',
  cancelText: '取消',
  width: '420px',
  loading: false,
})

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  confirm: []
  cancel: []
}>()

const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
})

const confirmButtonType = computed(() => {
  if (props.type === 'danger') return 'danger'
  return 'primary'
})

function handleConfirm() {
  emit('confirm')
}

function handleCancel() {
  visible.value = false
  emit('cancel')
}
</script>

<style lang="scss" scoped>
.confirm-content {
  display: flex;
  align-items: flex-start;
  gap: $spacing-base;
}

.confirm-icon {
  font-size: 24px;
  flex-shrink: 0;
  margin-top: 2px;

  &.warning {
    color: $warning-color;
  }

  &.danger {
    color: $danger-color;
  }

  &.info {
    color: $primary-color;
  }
}

.confirm-message {
  font-size: $font-size-base;
  color: $text-primary;
  line-height: $line-height-base;
}
</style>
