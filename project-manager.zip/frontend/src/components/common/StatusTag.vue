<template>
  <el-tag :type="tagType" :size="size" :effect="effect" class="status-tag">
    {{ label }}
  </el-tag>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { TASK_STATUS_OPTIONS, TASK_PRIORITY_OPTIONS, PROJECT_STATUS_OPTIONS, RISK_LEVEL_OPTIONS, RISK_STATUS_OPTIONS, USER_STATUS_OPTIONS } from '@/utils/constants'

const props = defineProps<{
  status: string
  type?: 'task' | 'taskPriority' | 'project' | 'riskLevel' | 'riskStatus' | 'userStatus'
  size?: 'small' | 'default' | 'large'
  effect?: 'dark' | 'light' | 'plain'
}>()

const optionsMap: Record<string, readonly { label: string; value: string; color?: string; bgColor?: string }[]> = {
  task: TASK_STATUS_OPTIONS,
  taskPriority: TASK_PRIORITY_OPTIONS,
  project: PROJECT_STATUS_OPTIONS,
  riskLevel: RISK_LEVEL_OPTIONS,
  riskStatus: RISK_STATUS_OPTIONS,
  userStatus: USER_STATUS_OPTIONS,
}

const label = computed(() => {
  const options = optionsMap[props.type || 'task'] || TASK_STATUS_OPTIONS
  const found = options.find((item) => item.value === props.status)
  return found ? found.label : props.status
})

const tagType = computed(() => {
  const colorMap: Record<string, string> = {
    '#67C23A': 'success',
    '#E6A23C': 'warning',
    '#F56C6C': 'danger',
    '#409EFF': 'primary',
    '#909399': 'info',
    '#d32f2f': 'danger',
  }

  const options = optionsMap[props.type || 'task'] || TASK_STATUS_OPTIONS
  const found = options.find((item) => item.value === props.status)
  const color = found?.color || ''
  return (colorMap[color] as any) || 'info'
})
</script>

<style lang="scss" scoped>
.status-tag {
  border-radius: $border-radius-sm;
}
</style>
