<template>
  <el-breadcrumb separator="/" class="app-breadcrumb">
    <transition-group name="breadcrumb">
      <el-breadcrumb-item
        v-for="(item, index) in breadcrumbs"
        :key="item.path"
      >
        <span
          v-if="index === breadcrumbs.length - 1"
          class="breadcrumb-current"
        >
          {{ item.meta?.title }}
        </span>
        <router-link v-else :to="item.path">
          {{ item.meta?.title }}
        </router-link>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import type { RouteLocationMatched } from 'vue-router'

const route = useRoute()

const breadcrumbs = computed(() => {
  const matched = route.matched.filter(
    (item: RouteLocationMatched) => item.meta && item.meta.title
  )
  return matched
})
</script>

<style lang="scss" scoped>
.app-breadcrumb {
  font-size: $font-size-sm;
  line-height: 1;

  .breadcrumb-current {
    color: $text-primary;
    font-weight: $font-weight-medium;
  }

  a {
    color: $text-secondary;

    &:hover {
      color: $primary-color;
    }
  }
}

.breadcrumb-enter-active,
.breadcrumb-leave-active {
  transition: all $transition-duration;
}

.breadcrumb-enter-from,
.breadcrumb-leave-to {
  opacity: 0;
  transform: translateX(10px);
}
</style>
