<template>
  <div class="stat-card" :style="{ borderTopColor: color }">
    <div class="stat-icon" :style="{ backgroundColor: color + '15', color }">
      <el-icon :size="28"><component :is="icon" /></el-icon>
    </div>
    <div class="stat-info">
      <div class="stat-value">
        <span class="number">{{ animatedValue }}</span>
        <span v-if="suffix" class="suffix">{{ suffix }}</span>
      </div>
      <div class="stat-label">{{ title }}</div>
    </div>
    <div v-if="trend !== undefined" class="stat-trend" :class="trend >= 0 ? 'up' : 'down'">
      <el-icon :size="14">
        <Top v-if="trend >= 0" />
        <Bottom v-else />
      </el-icon>
      <span>{{ Math.abs(trend) }}%</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import { Top, Bottom } from '@element-plus/icons-vue'

const props = withDefaults(defineProps<{
  title: string
  value: number
  icon: any
  color?: string
  suffix?: string
  trend?: number
}>(), {
  color: '#409EFF',
  suffix: '',
})

const animatedValue = ref(0)

function animateValue(target: number) {
  const duration = 800
  const startTime = performance.now()
  const startValue = animatedValue.value

  function update(currentTime: number) {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)
    const eased = 1 - Math.pow(1 - progress, 3)
    animatedValue.value = Math.round(startValue + (target - startValue) * eased)

    if (progress < 1) {
      requestAnimationFrame(update)
    }
  }

  requestAnimationFrame(update)
}

onMounted(() => {
  animateValue(props.value)
})

watch(() => props.value, (newVal) => {
  animateValue(newVal)
})
</script>

<style lang="scss" scoped>
.stat-card {
  background: $bg-white;
  border-radius: $border-radius-md;
  padding: $spacing-lg;
  display: flex;
  align-items: center;
  gap: $spacing-base;
  box-shadow: $shadow-sm;
  border-top: 3px solid;
  transition: box-shadow $transition-duration, transform $transition-duration;

  &:hover {
    box-shadow: $shadow-md;
    transform: translateY(-2px);
  }
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: $border-radius-md;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-info {
  flex: 1;
  min-width: 0;
}

.stat-value {
  display: flex;
  align-items: baseline;
  gap: $spacing-xs;

  .number {
    font-size: $font-size-xxl;
    font-weight: $font-weight-bold;
    color: $text-primary;
    line-height: 1.2;
  }

  .suffix {
    font-size: $font-size-sm;
    color: $text-secondary;
  }
}

.stat-label {
  font-size: $font-size-sm;
  color: $text-secondary;
  margin-top: $spacing-xs;
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: $spacing-xs;
  font-size: $font-size-xs;
  font-weight: $font-weight-medium;
  padding: $spacing-xs $spacing-sm;
  border-radius: $border-radius-base;

  &.up {
    color: $success-color;
    background-color: rgba($success-color, 0.1);
  }

  &.down {
    color: $danger-color;
    background-color: rgba($danger-color, 0.1);
  }
}
</style>
