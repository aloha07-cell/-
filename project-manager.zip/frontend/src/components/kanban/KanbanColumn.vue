<template>
  <div class="kanban-column" :style="{ borderColor: column.color }">
    <div class="column-header">
      <div class="column-title">
        <span class="column-dot" :style="{ backgroundColor: column.color }" />
        <span>{{ column.title }}</span>
        <el-badge :value="column.tasks.length" :max="99" type="info" />
      </div>
    </div>

    <draggable
      :list="column.tasks"
      :group="{ name: 'kanban', pull: true, put: true }"
      item-key="id"
      class="column-body"
      ghost-class="ghost-card"
      @end="handleDragEnd"
    >
      <template #item="{ element }">
        <TaskCard :task="element" @click="$emit('taskClick', element)" />
      </template>
    </draggable>
  </div>
</template>

<script setup lang="ts">
import draggable from 'vuedraggable'
import type { KanbanColumn as KanbanColumnType, Task, TaskDragParams } from '@/types/task'
import TaskCard from '@/components/task/TaskCard.vue'

defineProps<{
  column: KanbanColumnType
}>()

const emit = defineEmits<{
  taskClick: [task: Task]
  taskDrag: [data: TaskDragParams]
}>()

function handleDragEnd(event: any) {
  const task = event.item.__draggable_context?.element
  if (task) {
    emit('taskDrag', {
      taskId: task.id,
      status: task.status,
      order: event.newIndex,
    })
  }
}
</script>

<style lang="scss" scoped>
.kanban-column {
  width: 300px;
  min-width: 300px;
  background: $bg-color;
  border-radius: $border-radius-md;
  border-top: 3px solid;
  display: flex;
  flex-direction: column;
  max-height: calc(100vh - 200px);
}

.column-header {
  padding: $spacing-base;
  flex-shrink: 0;
}

.column-title {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  font-size: $font-size-base;
  font-weight: $font-weight-medium;
  color: $text-primary;
}

.column-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}

.column-body {
  flex: 1;
  overflow-y: auto;
  padding: 0 $spacing-sm $spacing-sm;
  display: flex;
  flex-direction: column;
  gap: $spacing-sm;
  min-height: 60px;
}

.ghost-card {
  opacity: 0.5;
  background: $primary-color;
  border-radius: $border-radius-md;
}
</style>
