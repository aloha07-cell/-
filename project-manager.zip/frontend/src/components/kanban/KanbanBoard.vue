<template>
  <div class="kanban-board">
    <div class="kanban-columns">
      <KanbanColumn
        v-for="column in columns"
        :key="column.status"
        :column="column"
        @task-click="handleTaskClick"
        @task-drag="handleTaskDrag"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useTaskStore } from '@/stores/useTaskStore'
import { TASK_STATUS_OPTIONS } from '@/utils/constants'
import type { Task, TaskDragParams, TaskStatus } from '@/types/task'
import KanbanColumn from './KanbanColumn.vue'

const taskStore = useTaskStore()

const columns = computed(() => {
  return TASK_STATUS_OPTIONS.filter((opt) => opt.value !== 'cancelled').map((opt) => ({
    status: opt.value as TaskStatus,
    title: opt.label,
    color: opt.color,
    tasks: taskStore.tasksByStatus[opt.value] || [],
  }))
})

function handleTaskClick(task: Task) {
  taskStore.fetchTask(task.id)
}

async function handleTaskDrag(data: TaskDragParams) {
  await taskStore.drag(data)
}
</script>

<style lang="scss" scoped>
.kanban-board {
  height: 100%;
  overflow-x: auto;
  overflow-y: hidden;
}

.kanban-columns {
  display: flex;
  gap: $spacing-base;
  height: 100%;
  min-width: max-content;
  padding: $spacing-sm;
}
</style>
