import { get } from './index'

/** 获取进度报表数据 */
export function getProgressReport(params?: { projectId?: number; dateFrom?: string; dateTo?: string }) {
  return get('/reports/progress', params)
}

/** 获取工时报表数据 */
export function getWorklogReport(params?: { projectId?: number; userId?: number; dateFrom?: string; dateTo?: string }) {
  return get('/reports/worklog', params)
}

/** 获取成本报表数据 */
export function getCostReport(params?: { projectId?: number; dateFrom?: string; dateTo?: string }) {
  return get('/reports/cost', params)
}

/** 获取项目概览报表 */
export function getProjectOverviewReport(projectId: number) {
  return get(`/reports/project-overview/${projectId}`)
}

/** 导出报表 */
export function exportReport(reportType: string, params?: any) {
  return get(`/reports/export/${reportType}`, params, { responseType: 'blob' }).then((res: any) => {
    const blob = new Blob([res])
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `${reportType}_report.xlsx`
    link.click()
    URL.revokeObjectURL(link.href)
  })
}
