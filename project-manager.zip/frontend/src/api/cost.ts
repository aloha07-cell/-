import { get, post, put, del } from './index'
import type { CostRecord, CreateCostParams, UpdateCostParams, CostQueryParams, Budget, CostAnalysis, PaginatedData } from '@/types/cost'

/** 获取成本记录列表 */
export function getCostRecords(params: CostQueryParams) {
  return get<PaginatedData<CostRecord>>('/costs', params)
}

/** 获取成本记录详情 */
export function getCostRecord(id: number) {
  return get<CostRecord>(`/costs/${id}`)
}

/** 创建成本记录 */
export function createCostRecord(data: CreateCostParams) {
  return post<CostRecord>('/costs', data)
}

/** 更新成本记录 */
export function updateCostRecord(id: number, data: Partial<CreateCostParams>) {
  return put<CostRecord>(`/costs/${id}`, data)
}

/** 删除成本记录 */
export function deleteCostRecord(id: number) {
  return del<null>(`/costs/${id}`)
}

/** 获取预算列表 */
export function getBudgets(projectId?: number) {
  return get<Budget[]>('/costs/budgets', { projectId })
}

/** 获取项目预算 */
export function getProjectBudget(projectId: number) {
  return get<Budget>(`/costs/budgets/${projectId}`)
}

/** 更新项目预算 */
export function updateProjectBudget(projectId: number, totalBudget: number) {
  return put<Budget>(`/costs/budgets/${projectId}`, { totalBudget })
}

/** 获取成本分析数据 */
export function getCostAnalysis(params?: { projectId?: number; dateFrom?: string; dateTo?: string }) {
  return get<CostAnalysis>('/costs/analysis', params)
}
