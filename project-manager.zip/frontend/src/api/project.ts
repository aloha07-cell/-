import { get, post, put, del } from './index'
import type { Project, CreateProjectParams, UpdateProjectParams, ProjectMember, AddProjectMemberParams, ProjectStats, ProjectQueryParams, PaginatedData } from '@/types/project'

/** 获取项目列表 */
export function getProjects(params: ProjectQueryParams) {
  return get<PaginatedData<Project>>('/projects', params)
}

/** 获取所有项目（不分页） */
export function getAllProjects() {
  return get<Project[]>('/projects/all')
}

/** 获取项目详情 */
export function getProject(id: number) {
  return get<Project>(`/projects/${id}`)
}

/** 创建项目 */
export function createProject(data: CreateProjectParams) {
  return post<Project>('/projects', data)
}

/** 更新项目 */
export function updateProject(id: number, data: Partial<CreateProjectParams>) {
  return put<Project>(`/projects/${id}`, data)
}

/** 删除项目 */
export function deleteProject(id: number) {
  return del<null>(`/projects/${id}`)
}

/** 获取项目成员列表 */
export function getProjectMembers(projectId: number) {
  return get<ProjectMember[]>(`/projects/${projectId}/members`)
}

/** 添加项目成员 */
export function addProjectMember(data: AddProjectMemberParams) {
  return post<ProjectMember>(`/projects/${data.projectId}/members`, data)
}

/** 移除项目成员 */
export function removeProjectMember(projectId: number, userId: number) {
  return del<null>(`/projects/${projectId}/members/${userId}`)
}

/** 更新项目成员角色 */
export function updateProjectMemberRole(projectId: number, userId: number, role: string) {
  return put<ProjectMember>(`/projects/${projectId}/members/${userId}`, { role })
}

/** 获取项目统计 */
export function getProjectStats() {
  return get<ProjectStats>('/projects/stats')
}
