import { get, post, put, del } from './index'
import type { Role, CreateRoleParams, UpdateRoleParams, Permission } from '@/types/user'

/** 获取角色列表 */
export function getRoles() {
  return get<Role[]>('/roles')
}

/** 获取角色详情 */
export function getRole(id: number) {
  return get<Role>(`/roles/${id}`)
}

/** 创建角色 */
export function createRole(data: CreateRoleParams) {
  return post<Role>('/roles', data)
}

/** 更新角色 */
export function updateRole(id: number, data: Partial<CreateRoleParams>) {
  return put<Role>(`/roles/${id}`, data)
}

/** 删除角色 */
export function deleteRole(id: number) {
  return del<null>(`/roles/${id}`)
}

/** 获取所有权限 */
export function getPermissions() {
  return get<Permission[]>('/permissions')
}
