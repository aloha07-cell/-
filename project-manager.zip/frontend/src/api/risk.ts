import { get, post, put, del } from './index'
import type { Risk, CreateRiskParams, UpdateRiskParams, RiskQueryParams, RiskMatrixCell, PaginatedData } from '@/types/risk'

/** 获取风险列表 */
export function getRisks(params: RiskQueryParams) {
  return get<PaginatedData<Risk>>('/risks', params)
}

/** 获取风险详情 */
export function getRisk(id: number) {
  return get<Risk>(`/risks/${id}`)
}

/** 创建风险 */
export function createRisk(data: CreateRiskParams) {
  return post<Risk>('/risks', data)
}

/** 更新风险 */
export function updateRisk(id: number, data: Partial<UpdateRiskParams>) {
  return put<Risk>(`/risks/${id}`, data)
}

/** 删除风险 */
export function deleteRisk(id: number) {
  return del<null>(`/risks/${id}`)
}

/** 获取风险矩阵 */
export function getRiskMatrix(projectId?: number) {
  return get<RiskMatrixCell[]>('/risks/matrix', { projectId })
}

/** 更新风险状态 */
export function updateRiskStatus(id: number, status: string) {
  return put<Risk>(`/risks/${id}/status`, { status })
}
