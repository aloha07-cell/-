import { get, post, put, del } from './index'
import type { User, CreateUserParams, UpdateUserParams, UserQueryParams, PaginatedData, Role, CreateRoleParams, UpdateRoleParams, Permission } from '@/types/user'

/** 获取用户列表 */
export function getUsers(params: UserQueryParams) {
  return get<PaginatedData<User>>('/users', params)
}

/** 获取用户详情 */
export function getUser(id: number) {
  return get<User>(`/users/${id}`)
}

/** 创建用户 */
export function createUser(data: CreateUserParams) {
  return post<User>('/users', data)
}

/** 更新用户 */
export function updateUser(id: number, data: Partial<UpdateUserParams>) {
  return put<User>(`/users/${id}`, data)
}

/** 删除用户 */
export function deleteUser(id: number) {
  return del<null>(`/users/${id}`)
}

/** 重置用户密码 */
export function resetUserPassword(id: number) {
  return post<null>(`/users/${id}/reset-password`)
}

/** 启用/禁用用户 */
export function toggleUserStatus(id: number, status: string) {
  return patch(`/users/${id}/status`, { status })
}

/** 获取角色列表 */
export function getRoles() {
  return get<Role[]>('/roles')
}

/** 获取角色详情 */
export function getRole(id: number) {
  return get<Role>(`/roles/${id}`)
}

/** 创建角色 */
export function createRole(data: CreateRoleParams) {
  return post<Role>('/roles', data)
}

/** 更新角色 */
export function updateRole(id: number, data: Partial<CreateRoleParams>) {
  return put<Role>(`/roles/${id}`, data)
}

/** 删除角色 */
export function deleteRole(id: number) {
  return del<null>(`/roles/${id}`)
}

/** 获取所有权限列表 */
export function getPermissions() {
  return get<Permission[]>('/permissions')
}

/** 获取所有用户（不分页，用于选择器） */
export function getAllUsers() {
  return get<User[]>('/users/all')
}

function patch(url: string, data?: any) {
  return put(url, data)
}
