import { get, put } from './index'

/** 获取系统设置 */
export function getSystemSettings() {
  return get('/system/settings')
}

/** 更新系统设置 */
export function updateSystemSettings(data: any) {
  return put('/system/settings', data)
}

/** 获取审计日志列表 */
export function getAuditLogs(params: { page: number; pageSize: number; keyword?: string; userId?: number; action?: string; dateFrom?: string; dateTo?: string }) {
  return get('/system/audit-logs', params)
}

/** 获取系统信息 */
export function getSystemInfo() {
  return get('/system/info')
}

/** 获取系统菜单列表 */
export function getMenus() {
  return get('/system/menus')
}

/** 更新系统菜单 */
export function updateMenus(data: any) {
  return put('/system/menus', data)
}
