import { get, post, put, del, patch } from './index'
import type { Task, CreateTaskParams, UpdateTaskParams, TaskDragParams, KanbanData, WbsTreeNode, TaskStats, TaskQueryParams, PaginatedData } from '@/types/task'

/** 获取任务列表 */
export function getTasks(params: TaskQueryParams) {
  return get<PaginatedData<Task>>('/tasks', params)
}

/** 获取任务详情 */
export function getTask(id: number) {
  return get<Task>(`/tasks/${id}`)
}

/** 创建任务 */
export function createTask(data: CreateTaskParams) {
  return post<Task>('/tasks', data)
}

/** 更新任务 */
export function updateTask(id: number, data: Partial<UpdateTaskParams>) {
  return put<Task>(`/tasks/${id}`, data)
}

/** 删除任务 */
export function deleteTask(id: number) {
  return del<null>(`/tasks/${id}`)
}

/** 任务拖拽（更新状态和排序） */
export function dragTask(data: TaskDragParams) {
  return patch<Task>(`/tasks/${data.taskId}/drag`, data)
}

/** 获取看板数据 */
export function getKanbanData(projectId: number) {
  return get<KanbanData>(`/tasks/kanban/${projectId}`)
}

/** 获取WBS树 */
export function getWbsTree(projectId: number) {
  return get<WbsTreeNode[]>(`/tasks/wbs/${projectId}`)
}

/** 获取任务统计 */
export function getTaskStats(projectId?: number) {
  return get<TaskStats>('/tasks/stats', { projectId })
}

/** 批量更新任务状态 */
export function batchUpdateTaskStatus(taskIds: number[], status: string) {
  return patch<Task>('/tasks/batch-status', { taskIds, status })
}

/** 分配任务 */
export function assignTask(taskId: number, assigneeId: number | null) {
  return patch<Task>(`/tasks/${taskId}/assign`, { assigneeId })
}
