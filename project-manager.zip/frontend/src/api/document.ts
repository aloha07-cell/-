import { get, post, put, del, upload } from './index'
import type { ProjectDocument, CreateDocumentParams, UpdateDocumentParams, DocumentQueryParams, PaginatedData } from '@/types/document'

/** 获取文档列表 */
export function getDocuments(params: DocumentQueryParams) {
  return get<PaginatedData<ProjectDocument>>('/documents', params)
}

/** 获取文档详情 */
export function getDocument(id: number) {
  return get<ProjectDocument>(`/documents/${id}`)
}

/** 上传文档 */
export function uploadDocument(data: CreateDocumentParams, onProgress?: (percent: number) => void) {
  const formData = new FormData()
  formData.append('file', data.file)
  formData.append('projectId', String(data.projectId))
  formData.append('name', data.name)
  formData.append('type', data.type)
  formData.append('description', data.description)

  return upload<ProjectDocument>('/documents', data.file, onProgress)
}

/** 更新文档 */
export function updateDocument(id: number, data: Partial<UpdateDocumentParams>) {
  return put<ProjectDocument>(`/documents/${id}`, data)
}

/** 删除文档 */
export function deleteDocument(id: number) {
  return del<null>(`/documents/${id}`)
}

/** 下载文档 */
export function downloadDocument(id: number) {
  return get<Blob>(`/documents/${id}/download`, {}, { responseType: 'blob' }).then((res) => {
    const blob = new Blob([res as any])
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'document'
    link.click()
    URL.revokeObjectURL(link.href)
  })
}

/** 获取项目文档树 */
export function getProjectDocuments(projectId: number) {
  return get<ProjectDocument[]>(`/documents/project/${projectId}`)
}
