import { post, get } from './index'
import type { LoginParams, RegisterParams, LoginResult, CurrentUser, RefreshTokenParams, ChangePasswordParams } from '@/types/auth'

/** 用户登录 */
export function login(data: LoginParams) {
  return post<LoginResult>('/auth/login', data)
}

/** 用户注册 */
export function register(data: RegisterParams) {
  return post<null>('/auth/register', data)
}

/** 刷新Token */
export function refreshToken(data: RefreshTokenParams) {
  return post<LoginResult>('/auth/refresh', data)
}

/** 获取当前用户信息 */
export function getCurrentUser() {
  return get<CurrentUser>('/auth/me')
}

/** 退出登录 */
export function logout() {
  return post<null>('/auth/logout')
}

/** 修改密码 */
export function changePassword(data: ChangePasswordParams) {
  return post<null>('/auth/change-password', data)
}
