import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse, type InternalAxiosRequestConfig } from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getAccessToken, setAccessToken, setRefreshToken, removeToken, getRefreshToken } from '@/utils/auth'
import type { ApiResponse } from '@/types/api'
import router from '@/router'

const service: AxiosInstance = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
})

let isRefreshing = false
let failedQueue: Array<{
  resolve: (token: string) => void
  reject: (error: any) => void
}> = []

function processQueue(error: any, token: string | null = null) {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error)
    } else {
      promise.resolve(token!)
    }
  })
  failedQueue = []
}

/** 请求拦截器 */
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = getAccessToken()
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

/** 响应拦截器 */
service.interceptors.response.use(
  (response: AxiosResponse<ApiResponse>) => {
    const res = response.data

    if (res.code !== 0 && res.code !== 200) {
      ElMessage.error(res.message || '请求失败')

      if (res.code === 401) {
        handleUnauthorized()
      } else if (res.code === 403) {
        handleForbidden()
      }

      return Promise.reject(new Error(res.message || '请求失败'))
    }

    return response
  },
  async (error) => {
    const originalRequest = error.config

    if (error.response) {
      const status = error.response.status

      if (status === 401 && !originalRequest._retry) {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject })
          }).then((token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`
            return service(originalRequest)
          })
        }

        originalRequest._retry = true
        isRefreshing = true

        try {
          const refreshToken = getRefreshToken()
          if (!refreshToken) {
            throw new Error('No refresh token')
          }

          const { data } = await axios.post('/api/auth/refresh', {
            refreshToken,
          })

          const newToken = data.data?.accessToken || data.accessToken
          const newRefreshToken = data.data?.refreshToken || data.refreshToken
          const expiresIn = data.data?.expiresIn || data.expiresIn || 1800

          setAccessToken(newToken, expiresIn)
          setRefreshToken(newRefreshToken)

          processQueue(null, newToken)
          originalRequest.headers.Authorization = `Bearer ${newToken}`
          return service(originalRequest)
        } catch (refreshError) {
          processQueue(refreshError, null)
          handleUnauthorized()
          return Promise.reject(refreshError)
        } finally {
          isRefreshing = false
        }
      }

      if (status === 403) {
        handleForbidden()
      }

      const message = error.response.data?.message || `请求失败 (${status})`
      ElMessage.error(message)
      return Promise.reject(error)
    }

    if (error.code === 'ECONNABORTED') {
      ElMessage.error('请求超时，请稍后重试')
    } else {
      ElMessage.error('网络错误，请检查网络连接')
    }

    return Promise.reject(error)
  }
)

function handleUnauthorized() {
  removeToken()
  router.push({
    path: '/auth/login',
    query: { redirect: router.currentRoute.value.fullPath },
  })
}

function handleForbidden() {
  ElMessageBox.alert('您没有权限执行此操作', '权限不足', {
    confirmButtonText: '确定',
    type: 'warning',
  })
}

/** 封装请求方法 */
export function get<T = any>(url: string, params?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.get(url, { params, ...config }).then((res) => res.data)
}

export function post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.post(url, data, config).then((res) => res.data)
}

export function put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.put(url, data, config).then((res) => res.data)
}

export function patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.patch(url, data, config).then((res) => res.data)
}

export function del<T = any>(url: string, params?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.delete(url, { params, ...config }).then((res) => res.data)
}

/** 文件上传 */
export function upload<T = any>(url: string, file: File, onProgress?: (percent: number) => void): Promise<ApiResponse<T>> {
  const formData = new FormData()
  formData.append('file', file)

  return service.post(url, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress(event) {
      if (event.total && onProgress) {
        onProgress(Math.round((event.loaded / event.total) * 100))
      }
    },
  }).then((res) => res.data)
}

/** 文件下载 */
export function download(url: string, params?: any, filename?: string): Promise<void> {
  return service
    .get(url, { params, responseType: 'blob' })
    .then((res) => {
      const blob = new Blob([res.data])
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename || 'download'
      link.click()
      URL.revokeObjectURL(link.href)
    })
}

export default service
