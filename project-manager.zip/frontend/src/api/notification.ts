import { get, post, put, patch } from './index'
import type { Notification, NotificationQueryParams, NotificationStats, PaginatedData } from '@/types/notification'

/** 获取通知列表 */
export function getNotifications(params: NotificationQueryParams) {
  return get<PaginatedData<Notification>>('/notifications', params)
}

/** 获取通知详情 */
export function getNotification(id: number) {
  return get<Notification>(`/notifications/${id}`)
}

/** 标记通知为已读 */
export function markNotificationRead(id: number) {
  return put<Notification>(`/notifications/${id}/read`)
}

/** 批量标记通知为已读 */
export function markAllNotificationsRead() {
  return put<null>('/notifications/read-all')
}

/** 获取未读通知数量 */
export function getUnreadCount() {
  return get<number>('/notifications/unread-count')
}

/** 获取通知统计 */
export function getNotificationStats() {
  return get<NotificationStats>('/notifications/stats')
}

/** 删除通知 */
export function deleteNotification(id: number) {
  return patch(`/notifications/${id}`, {})
}

function patch(url: string, data?: any) {
  return put(url, data)
}
