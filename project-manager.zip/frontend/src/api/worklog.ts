import { get, post, put, del } from './index'
import type { Worklog, CreateWorklogParams, UpdateWorklogParams, WorklogQueryParams, WorklogStats, DailyWorklogSummary, PaginatedData } from '@/types/worklog'

/** 获取工时列表 */
export function getWorklogs(params: WorklogQueryParams) {
  return get<PaginatedData<Worklog>>('/worklogs', params)
}

/** 获取工时详情 */
export function getWorklog(id: number) {
  return get<Worklog>(`/worklogs/${id}`)
}

/** 创建工时 */
export function createWorklog(data: CreateWorklogParams) {
  return post<Worklog>('/worklogs', data)
}

/** 更新工时 */
export function updateWorklog(id: number, data: Partial<CreateWorklogParams>) {
  return put<Worklog>(`/worklogs/${id}`, data)
}

/** 删除工时 */
export function deleteWorklog(id: number) {
  return del<null>(`/worklogs/${id}`)
}

/** 获取工时统计 */
export function getWorklogStats(params?: { userId?: number; projectId?: number; dateFrom?: string; dateTo?: string }) {
  return get<WorklogStats>('/worklogs/stats', params)
}

/** 获取每日工时汇总 */
export function getDailyWorklogSummary(params?: { userId?: number; projectId?: number; dateFrom?: string; dateTo?: string }) {
  return get<DailyWorklogSummary[]>('/worklogs/daily-summary', params)
}
