<template>
  <div class="dashboard-page page-container">
    <!-- 统计卡片 -->
    <div class="stat-cards">
      <StatCard title="项目总数" :value="projectStats?.totalProjects || 0" :icon="Folder" color="#409EFF" />
      <StatCard title="进行中" :value="projectStats?.inProgressProjects || 0" :icon="Loading" color="#E6A23C" />
      <StatCard title="已完成" :value="projectStats?.completedProjects || 0" :icon="CircleCheck" color="#67C23A" />
      <StatCard title="逾期项目" :value="projectStats?.overdueProjects || 0" :icon="Warning" color="#F56C6C" />
    </div>

    <el-row :gutter="20">
      <!-- 待办任务 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">我的待办任务</span>
              <el-button text type="primary" @click="$router.push('/tasks')">查看全部</el-button>
            </div>
          </template>
          <div class="todo-list">
            <div v-for="task in todoTasks" :key="task.id" class="todo-item" @click="goToTask(task)">
              <el-checkbox
                :model-value="task.status === 'done'"
                @change="(val: any) => toggleTaskStatus(task, val)"
              />
              <div class="todo-info">
                <div class="todo-title text-ellipsis">{{ task.title }}</div>
                <div class="todo-meta">
                  <StatusTag :status="task.priority" type="taskPriority" size="small" />
                  <span class="todo-project">{{ task.projectName }}</span>
                </div>
              </div>
              <span v-if="task.dueDate" class="todo-due" :class="{ overdue: isOverdue(task.dueDate) }">
                {{ formatDate(task.dueDate) }}
              </span>
            </div>
            <EmptyState v-if="todoTasks.length === 0" description="暂无待办任务" :image-size="80" />
          </div>
        </el-card>
      </el-col>

      <!-- 项目进度 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">项目进度</span>
              <el-button text type="primary" @click="$router.push('/projects')">查看全部</el-button>
            </div>
          </template>
          <div class="project-progress-list">
            <div v-for="project in recentProjects" :key="project.id" class="project-item" @click="$router.push(`/projects/${project.id}`)">
              <div class="project-info">
                <div class="project-name text-ellipsis">{{ project.name }}</div>
                <div class="project-meta">
                  <StatusTag :status="project.status" type="project" size="small" />
                  <span class="project-date">{{ formatDate(project.endDate) }}</span>
                </div>
              </div>
              <el-progress
                :percentage="project.progress"
                :stroke-width="8"
                :color="getProgressColor(project.progress)"
                style="width: 120px;"
              />
            </div>
            <EmptyState v-if="recentProjects.length === 0" description="暂无项目" :image-size="80" />
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 工时统计 -->
    <el-row :gutter="20" class="mt-base">
      <el-col :span="24">
        <el-card class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">本周工时统计</span>
              <el-button text type="primary" @click="$router.push('/worklogs')">查看详情</el-button>
            </div>
          </template>
          <div class="worklog-stats">
            <div class="worklog-stat-item">
              <span class="stat-label">今日工时</span>
              <span class="stat-value">{{ worklogStats?.todayHours || 0 }}h</span>
            </div>
            <div class="worklog-stat-item">
              <span class="stat-label">本周工时</span>
              <span class="stat-value">{{ worklogStats?.weekHours || 0 }}h</span>
            </div>
            <div class="worklog-stat-item">
              <span class="stat-label">本月工时</span>
              <span class="stat-value">{{ worklogStats?.monthHours || 0 }}h</span>
            </div>
            <div class="worklog-stat-item">
              <span class="stat-label">日均工时</span>
              <span class="stat-value">{{ worklogStats?.dailyAverage || 0 }}h</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Folder, Loading, CircleCheck, Warning } from '@element-plus/icons-vue'
import StatCard from '@/components/dashboard/StatCard.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import { getProjectStats } from '@/api/project'
import { getTasks, updateTask } from '@/api/task'
import { getWorklogStats } from '@/api/worklog'
import { formatDate, isOverdue } from '@/utils/date'
import type { ProjectStats, Task, WorklogStats } from '@/types/worklog'

const router = useRouter()
const projectStats = ref<ProjectStats | null>(null)
const todoTasks = ref<Task[]>([])
const recentProjects = ref<any[]>([])
const worklogStats = ref<WorklogStats | null>(null)

function getProgressColor(progress: number): string {
  if (progress >= 80) return '#67C23A'
  if (progress >= 50) return '#409EFF'
  if (progress >= 30) return '#E6A23C'
  return '#F56C6C'
}

function goToTask(task: Task) {
  router.push(`/tasks?taskId=${task.id}`)
}

async function toggleTaskStatus(task: Task, done: boolean | string) {
  const newStatus = done ? 'done' : 'todo'
  try {
    await updateTask(task.id, { status: newStatus } as any)
    task.status = newStatus
  } catch {
    // revert handled by refresh
  }
}

onMounted(async () => {
  try {
    const [statsRes, tasksRes, worklogRes] = await Promise.allSettled([
      getProjectStats(),
      getTasks({ page: 1, pageSize: 10, status: 'todo' }),
      getWorklogStats(),
    ])

    if (statsRes.status === 'fulfilled') {
      projectStats.value = statsRes.value.data
      recentProjects.value = (statsRes.value.data as any).recentProjects || []
    }
    if (tasksRes.status === 'fulfilled') {
      todoTasks.value = tasksRes.value.data.items
    }
    if (worklogRes.status === 'fulfilled') {
      worklogStats.value = worklogRes.value.data
    }
  } catch {
    // silent fail
  }
})
</script>

<style lang="scss" scoped>
.dashboard-page {
  max-width: 1400px;
}

.stat-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: $spacing-base;
  margin-bottom: $spacing-lg;

  @media (max-width: $breakpoint-md) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: $breakpoint-sm) {
    grid-template-columns: 1fr;
  }
}

.dashboard-card {
  margin-bottom: $spacing-base;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.card-title {
  font-size: $font-size-md;
  font-weight: $font-weight-medium;
}

.todo-list {
  display: flex;
  flex-direction: column;
  gap: $spacing-sm;
}

.todo-item {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  padding: $spacing-sm;
  border-radius: $border-radius-base;
  cursor: pointer;
  transition: background-color $transition-duration;

  &:hover {
    background-color: $bg-color;
  }
}

.todo-info {
  flex: 1;
  min-width: 0;
}

.todo-title {
  font-size: $font-size-base;
  color: $text-primary;
  margin-bottom: $spacing-xs;
}

.todo-meta {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.todo-project {
  font-size: $font-size-xs;
  color: $text-secondary;
}

.todo-due {
  font-size: $font-size-xs;
  color: $text-secondary;
  flex-shrink: 0;

  &.overdue {
    color: $danger-color;
  }
}

.project-progress-list {
  display: flex;
  flex-direction: column;
  gap: $spacing-base;
}

.project-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: $spacing-sm;
  border-radius: $border-radius-base;
  cursor: pointer;
  transition: background-color $transition-duration;

  &:hover {
    background-color: $bg-color;
  }
}

.project-info {
  flex: 1;
  min-width: 0;
}

.project-name {
  font-size: $font-size-base;
  color: $text-primary;
  margin-bottom: $spacing-xs;
}

.project-meta {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.project-date {
  font-size: $font-size-xs;
  color: $text-secondary;
}

.worklog-stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: $spacing-lg;

  @media (max-width: $breakpoint-sm) {
    grid-template-columns: repeat(2, 1fr);
  }
}

.worklog-stat-item {
  text-align: center;
  padding: $spacing-base;
  background: $bg-color;
  border-radius: $border-radius-md;
}

.worklog-stat-item .stat-label {
  display: block;
  font-size: $font-size-sm;
  color: $text-secondary;
  margin-bottom: $spacing-sm;
}

.worklog-stat-item .stat-value {
  display: block;
  font-size: $font-size-xxl;
  font-weight: $font-weight-bold;
  color: $primary-color;
}
</style>
