<template>
  <div class="audit-log-page page-container">
    <PageHeader title="审计日志" />

    <el-card class="search-card">
      <div class="search-bar">
        <el-input v-model="queryParams.keyword" placeholder="搜索操作内容" clearable style="width: 220px;" @clear="fetchData" @keyup.enter="fetchData" />
        <el-input v-model="queryParams.userId" placeholder="用户ID" clearable style="width: 120px;" @clear="fetchData" />
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始" end-placeholder="结束" value-format="YYYY-MM-DD" style="width: 280px;" @change="fetchData" />
        <el-button type="primary" @click="fetchData">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="logs" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="userId" label="用户ID" width="80" />
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="action" label="操作" width="120" />
        <el-table-column prop="resource" label="资源" width="120" />
        <el-table-column prop="description" label="描述" min-width="300" show-overflow-tooltip />
        <el-table-column prop="ip" label="IP地址" width="140" />
        <el-table-column prop="createdAt" label="时间" width="180">
          <template #default="{ row }">{{ formatDateTime(row.createdAt) }}</template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50, 100]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'
import { getAuditLogs } from '@/api/system'
import { formatDateTime } from '@/utils/date'

const logs = ref<any[]>([])
const total = ref(0)
const loading = ref(false)
const dateRange = ref<string[]>([])

const queryParams = reactive({
  page: 1, pageSize: 20, keyword: '', userId: '',
  dateFrom: '', dateTo: '',
})

async function fetchData() {
  loading.value = true
  try {
    if (dateRange.value?.length === 2) {
      queryParams.dateFrom = dateRange.value[0]
      queryParams.dateTo = dateRange.value[1]
    } else {
      queryParams.dateFrom = ''
      queryParams.dateTo = ''
    }
    const res = await getAuditLogs(queryParams)
    logs.value = (res.data as any).items || []
    total.value = (res.data as any).total || 0
  } finally {
    loading.value = false
  }
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.userId = ''
  dateRange.value = []
  queryParams.page = 1
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
