<template>
  <div class="role-manage-page page-container">
    <PageHeader title="角色管理">
      <template #actions>
        <el-button v-permission="'system:role:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新建角色
        </el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="roles" v-loading="loading" stripe>
        <el-table-column prop="name" label="角色名称" width="160" />
        <el-table-column prop="code" label="角色编码" width="160" />
        <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
        <el-table-column label="权限" min-width="300">
          <template #default="{ row }">
            <div class="permission-tags">
              <el-tag v-for="perm in row.permissions?.slice(0, 5)" :key="perm" size="small" type="info">{{ perm }}</el-tag>
              <el-tag v-if="(row.permissions?.length || 0) > 5" size="small" type="info">+{{ row.permissions.length - 5 }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button v-permission="'system:role:edit'" text type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button v-permission="'system:role:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="showForm" :title="editTarget ? '编辑角色' : '新建角色'" width="600px">
      <el-form ref="formRef" :model="formData" :rules="rules" label-width="100px">
        <el-form-item label="角色名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入角色名称" />
        </el-form-item>
        <el-form-item label="角色编码" prop="code">
          <el-input v-model="formData.code" placeholder="请输入角色编码" :disabled="!!editTarget" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="formData.description" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="权限">
          <el-tree
            ref="permTreeRef"
            :data="permissionTree"
            show-checkbox
            node-key="code"
            :default-checked-keys="formData.permissions"
            :props="{ label: 'name', children: 'children' }"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import { getRoles, createRole, updateRole, deleteRole, getPermissions } from '@/api/role'
import type { Role, Permission } from '@/types/user'

const roles = ref<Role[]>([])
const permissions = ref<Permission[]>([])
const loading = ref(false)
const showForm = ref(false)
const submitting = ref(false)
const editTarget = ref<Role | null>(null)
const formRef = ref<FormInstance>()
const permTreeRef = ref<any>()

const permissionTree = computed(() => {
  const map: Record<string, any> = {}
  permissions.value.forEach((p) => {
    if (!map[p.module]) {
      map[p.module] = { code: p.module, name: p.module, children: [] }
    }
    map[p.module].children.push({ code: p.code, name: p.name })
  })
  return Object.values(map)
})

const formData = reactive({
  name: '', code: '', description: '', permissions: [] as string[],
})

const rules: FormRules = {
  name: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
  code: [{ required: true, message: '请输入角色编码', trigger: 'blur' }],
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getRoles()
    roles.value = res.data
  } finally {
    loading.value = false
  }
}

function handleEdit(role: Role) {
  editTarget.value = role
  Object.assign(formData, {
    name: role.name, code: role.code, description: role.description,
    permissions: role.permissions || [],
  })
  showForm.value = true
}

async function handleDelete(role: Role) {
  try {
    await ElMessageBox.confirm(`确定要删除角色「${role.name}」吗？`, '确认', { type: 'warning' })
    await deleteRole(role.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    const checkedKeys = permTreeRef.value?.getCheckedKeys() || []
    const data = { ...formData, permissions: checkedKeys }
    if (editTarget.value) {
      await updateRole(editTarget.value.id, data)
      ElMessage.success('更新成功')
    } else {
      await createRole(data)
      ElMessage.success('创建成功')
    }
    showForm.value = false
    editTarget.value = null
    fetchData()
  } catch {
    ElMessage.error('操作失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  try {
    const [rolesRes, permRes] = await Promise.allSettled([getRoles(), getPermissions()])
    if (rolesRes.status === 'fulfilled') roles.value = rolesRes.value.data
    if (permRes.status === 'fulfilled') permissions.value = permRes.value.data
  } catch {
    // silent
  }
})
</script>

<style lang="scss" scoped>
.permission-tags {
  display: flex;
  flex-wrap: wrap;
  gap: $spacing-xs;
}
</style>
