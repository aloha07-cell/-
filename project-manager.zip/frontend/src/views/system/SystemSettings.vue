<template>
  <div class="system-settings-page page-container">
    <PageHeader title="系统设置" />

    <el-tabs v-model="activeTab">
      <el-tab-pane label="基本设置" name="basic">
        <el-card>
          <el-form :model="basicSettings" label-width="160px" style="max-width: 600px;">
            <el-form-item label="系统名称">
              <el-input v-model="basicSettings.siteName" placeholder="请输入系统名称" />
            </el-form-item>
            <el-form-item label="系统描述">
              <el-input v-model="basicSettings.siteDescription" type="textarea" :rows="2" />
            </el-form-item>
            <el-form-item label="Logo">
              <ImageUpload v-model="basicSettings.logo" />
            </el-form-item>
            <el-form-item label="默认语言">
              <el-select v-model="basicSettings.defaultLanguage" style="width: 100%;">
                <el-option label="简体中文" value="zh-CN" />
                <el-option label="English" value="en-US" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="saveBasicSettings">保存</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="安全设置" name="security">
        <el-card>
          <el-form :model="securitySettings" label-width="160px" style="max-width: 600px;">
            <el-form-item label="密码最小长度">
              <el-input-number v-model="securitySettings.minPasswordLength" :min="6" :max="32" />
            </el-form-item>
            <el-form-item label="Token过期时间(小时)">
              <el-input-number v-model="securitySettings.tokenExpireHours" :min="1" :max="720" />
            </el-form-item>
            <el-form-item label="登录失败锁定次数">
              <el-input-number v-model="securitySettings.maxLoginAttempts" :min="3" :max="10" />
            </el-form-item>
            <el-form-item label="允许注册">
              <el-switch v-model="securitySettings.allowRegister" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="saveSecuritySettings">保存</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="通知设置" name="notification">
        <el-card>
          <el-form :model="notificationSettings" label-width="160px" style="max-width: 600px;">
            <el-form-item label="邮件通知">
              <el-switch v-model="notificationSettings.emailEnabled" />
            </el-form-item>
            <el-form-item label="站内通知">
              <el-switch v-model="notificationSettings.siteEnabled" />
            </el-form-item>
            <el-form-item label="任务分配通知">
              <el-switch v-model="notificationSettings.taskAssignNotify" />
            </el-form-item>
            <el-form-item label="截止日期提醒">
              <el-switch v-model="notificationSettings.deadlineRemind" />
            </el-form-item>
            <el-form-item label="提醒时间(天)">
              <el-input-number v-model="notificationSettings.remindDays" :min="1" :max="7" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="saveNotificationSettings">保存</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import ImageUpload from '@/components/common/ImageUpload.vue'
import { getSystemSettings, updateSystemSettings } from '@/api/system'

const activeTab = ref('basic')
const saving = ref(false)

const basicSettings = reactive({
  siteName: '项目管理系统',
  siteDescription: '',
  logo: '',
  defaultLanguage: 'zh-CN',
})

const securitySettings = reactive({
  minPasswordLength: 8,
  tokenExpireHours: 24,
  maxLoginAttempts: 5,
  allowRegister: true,
})

const notificationSettings = reactive({
  emailEnabled: true,
  siteEnabled: true,
  taskAssignNotify: true,
  deadlineRemind: true,
  remindDays: 1,
})

async function loadSettings() {
  try {
    const res = await getSystemSettings()
    const data = res.data as any
    if (data.basic) Object.assign(basicSettings, data.basic)
    if (data.security) Object.assign(securitySettings, data.security)
    if (data.notification) Object.assign(notificationSettings, data.notification)
  } catch {
    // use defaults
  }
}

async function saveBasicSettings() {
  saving.value = true
  try {
    await updateSystemSettings({ basic: { ...basicSettings } })
    ElMessage.success('保存成功')
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

async function saveSecuritySettings() {
  saving.value = true
  try {
    await updateSystemSettings({ security: { ...securitySettings } })
    ElMessage.success('保存成功')
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

async function saveNotificationSettings() {
  saving.value = true
  try {
    await updateSystemSettings({ notification: { ...notificationSettings } })
    ElMessage.success('保存成功')
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadSettings()
})
</script>
