<template>
  <div class="user-manage-page page-container">
    <PageHeader title="用户管理">
      <template #actions>
        <el-button v-permission="'system:user:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新建用户
        </el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-input v-model="queryParams.keyword" placeholder="搜索用户名/邮箱" clearable style="width: 240px;" @clear="fetchData" @keyup.enter="fetchData" />
        <el-select v-model="queryParams.status" placeholder="状态" clearable style="width: 120px;" @change="fetchData">
          <el-option v-for="item in USER_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-button type="primary" @click="fetchData">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="users" v-loading="loading" stripe>
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column label="用户" min-width="200">
          <template #default="{ row }">
            <div class="user-cell">
              <UserAvatar :name="row.nickname || row.username" :src="row.avatar" :size="32" />
              <div class="user-info">
                <span class="user-nickname">{{ row.nickname || row.username }}</span>
                <span class="user-email">{{ row.email }}</span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="department" label="部门" width="120" />
        <el-table-column prop="position" label="职位" width="120" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }"><StatusTag :status="row.status" type="userStatus" size="small" /></template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="160">
          <template #default="{ row }">{{ formatDateTime(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button v-permission="'system:user:edit'" text type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button v-permission="'system:user:reset'" text type="warning" size="small" @click="handleResetPassword(row)">重置密码</el-button>
            <el-button v-permission="'system:user:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>

    <el-dialog v-model="showForm" :title="editTarget ? '编辑用户' : '新建用户'" width="560px">
      <el-form ref="formRef" :model="formData" :rules="rules" label-width="100px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="formData.username" :disabled="!!editTarget" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="formData.nickname" placeholder="请输入昵称" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="formData.email" placeholder="请输入邮箱" />
        </el-form-item>
        <el-form-item v-if="!editTarget" label="密码" prop="password">
          <el-input v-model="formData.password" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
        <el-form-item label="部门">
          <el-input v-model="formData.department" placeholder="请输入部门" />
        </el-form-item>
        <el-form-item label="职位">
          <el-input v-model="formData.position" placeholder="请输入职位" />
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="formData.roleIds" multiple placeholder="请选择角色" style="width: 100%;">
            <el-option v-for="r in roles" :key="r.id" :label="r.name" :value="r.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import { getUsers, createUser, updateUser, deleteUser, resetUserPassword } from '@/api/user'
import { getRoles } from '@/api/role'
import { formatDateTime } from '@/utils/date'
import { USER_STATUS_OPTIONS } from '@/utils/constants'
import type { User, UserQueryParams } from '@/types/user'
import type { Role } from '@/types/user'

const users = ref<User[]>([])
const roles = ref<Role[]>([])
const total = ref(0)
const loading = ref(false)
const showForm = ref(false)
const submitting = ref(false)
const editTarget = ref<User | null>(null)
const formRef = ref<FormInstance>()

const queryParams = reactive<UserQueryParams>({ page: 1, pageSize: 20, keyword: '' })

const formData = reactive({
  username: '', nickname: '', email: '', password: '',
  department: '', position: '', roleIds: [] as number[],
})

const rules: FormRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  email: [{ required: true, message: '请输入邮箱', trigger: 'blur' }, { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }, { min: 6, message: '密码至少6位', trigger: 'blur' }],
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getUsers(queryParams)
    users.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.status = undefined
  queryParams.page = 1
  fetchData()
}

function handleEdit(user: User) {
  editTarget.value = user
  Object.assign(formData, {
    username: user.username, nickname: user.nickname, email: user.email,
    department: user.department, position: user.position,
    roleIds: user.roles?.map((r) => r.id) || [],
  })
  showForm.value = true
}

async function handleResetPassword(user: User) {
  try {
    await ElMessageBox.confirm(`确定要重置用户「${user.nickname || user.username}」的密码吗？`, '确认', { type: 'warning' })
    await resetUserPassword(user.id)
    ElMessage.success('密码已重置')
  } catch {
    // cancelled
  }
}

async function handleDelete(user: User) {
  try {
    await ElMessageBox.confirm(`确定要删除用户「${user.nickname || user.username}」吗？`, '确认', { type: 'warning' })
    await deleteUser(user.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (editTarget.value) {
      await updateUser(editTarget.value.id, formData as any)
      ElMessage.success('更新成功')
    } else {
      await createUser(formData as any)
      ElMessage.success('创建成功')
    }
    showForm.value = false
    editTarget.value = null
    fetchData()
  } catch {
    ElMessage.error('操作失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  try {
    const res = await getRoles()
    roles.value = res.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.user-cell { display: flex; align-items: center; gap: $spacing-sm; }
.user-info { display: flex; flex-direction: column; }
.user-nickname { font-size: $font-size-base; color: $text-primary; }
.user-email { font-size: $font-size-xs; color: $text-secondary; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
