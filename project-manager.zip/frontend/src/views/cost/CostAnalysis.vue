<template>
  <div class="cost-analysis-page page-container">
    <PageHeader title="成本分析">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="全部项目" clearable style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
      </template>
    </PageHeader>

    <el-row :gutter="20">
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>成本类型分布</span></template>
          <div ref="typeChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>月度成本趋势</span></template>
          <div ref="trendChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
    </el-row>

    <el-card class="mt-base" v-loading="loading">
      <template #header><span>项目成本对比</span></template>
      <div ref="projectChartRef" style="height: 400px;" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import PageHeader from '@/components/common/PageHeader.vue'
import { getCostAnalysis } from '@/api/cost'
import { getAllProjects } from '@/api/project'
import { COST_TYPE_OPTIONS } from '@/utils/constants'
import type { CostAnalysis } from '@/types/cost'
import type { Project } from '@/types/project'

const projects = ref<Project[]>([])
const selectedProjectId = ref<number | undefined>(undefined)
const loading = ref(false)
const typeChartRef = ref<HTMLElement>()
const trendChartRef = ref<HTMLElement>()
const projectChartRef = ref<HTMLElement>()

let typeChart: echarts.ECharts | null = null
let trendChart: echarts.ECharts | null = null
let projectChart: echarts.ECharts | null = null

async function loadData() {
  loading.value = true
  try {
    const res = await getCostAnalysis({ projectId: selectedProjectId.value })
    const data: CostAnalysis = res.data
    await nextTick()
    renderTypeChart(data)
    renderTrendChart(data)
    renderProjectChart(data)
  } finally {
    loading.value = false
  }
}

function renderTypeChart(data: CostAnalysis) {
  if (!typeChartRef.value) return
  if (!typeChart) typeChart = echarts.init(typeChartRef.value)
  typeChart.setOption({
    tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      data: data.byType.map((item) => ({
        name: COST_TYPE_OPTIONS.find((o) => o.value === item.type)?.label || item.type,
        value: item.amount,
      })),
      emphasis: { itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0, 0, 0, 0.5)' } },
    }],
  })
}

function renderTrendChart(data: CostAnalysis) {
  if (!trendChartRef.value) return
  if (!trendChart) trendChart = echarts.init(trendChartRef.value)
  trendChart.setOption({
    tooltip: { trigger: 'axis' },
    legend: { data: ['计划', '实际'], bottom: 0 },
    xAxis: { type: 'category', data: data.byMonth.map((m) => m.month) },
    yAxis: { type: 'value', name: '金额' },
    series: [
      { name: '计划', type: 'line', data: data.byMonth.map((m) => m.planned), smooth: true },
      { name: '实际', type: 'line', data: data.byMonth.map((m) => m.actual), smooth: true },
    ],
  })
}

function renderProjectChart(data: CostAnalysis) {
  if (!projectChartRef.value) return
  if (!projectChart) projectChart = echarts.init(projectChartRef.value)
  projectChart.setOption({
    tooltip: { trigger: 'axis' },
    legend: { data: ['预算', '已花费'], bottom: 0 },
    xAxis: { type: 'category', data: data.byProject.map((p) => p.projectName), axisLabel: { rotate: 30 } },
    yAxis: { type: 'value', name: '金额' },
    series: [
      { name: '预算', type: 'bar', data: data.byProject.map((p) => p.budget), itemStyle: { color: '#409EFF' } },
      { name: '已花费', type: 'bar', data: data.byProject.map((p) => p.spent), itemStyle: { color: '#E6A23C' } },
    ],
  })
}

function handleResize() {
  typeChart?.resize()
  trendChart?.resize()
  projectChart?.resize()
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  loadData()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  typeChart?.dispose()
  trendChart?.dispose()
  projectChart?.dispose()
})
</script>
