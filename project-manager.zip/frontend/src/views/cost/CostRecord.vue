<template>
  <div class="cost-record-page page-container">
    <PageHeader title="成本记录">
      <template #actions>
        <el-button v-permission="'cost:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新增记录
        </el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-select v-model="queryParams.projectId" placeholder="项目" clearable style="width: 160px;" @change="fetchData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-select v-model="queryParams.type" placeholder="成本类型" clearable style="width: 140px;" @change="fetchData">
          <el-option v-for="item in COST_TYPE_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始" end-placeholder="结束" value-format="YYYY-MM-DD" style="width: 280px;" @change="fetchData" />
        <el-button type="primary" @click="fetchData">搜索</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="records" v-loading="loading" stripe>
        <el-table-column prop="date" label="日期" width="120" />
        <el-table-column prop="projectName" label="项目" width="140" show-overflow-tooltip />
        <el-table-column prop="type" label="类型" width="100">
          <template #default="{ row }">{{ getCostTypeLabel(row.type) }}</template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
        <el-table-column prop="amount" label="金额" width="120" align="right">
          <template #default="{ row }">{{ formatCurrency(row.amount) }}</template>
        </el-table-column>
        <el-table-column prop="createdByName" label="记录人" width="100" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button v-permission="'cost:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>

    <el-dialog v-model="showForm" title="新增成本记录" width="560px">
      <el-form ref="formRef" :model="formData" :rules="rules" label-width="100px">
        <el-form-item label="项目" prop="projectId">
          <el-select v-model="formData.projectId" placeholder="请选择" style="width: 100%;">
            <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="成本类型" prop="type">
          <el-select v-model="formData.type" style="width: 100%;">
            <el-option v-for="item in COST_TYPE_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="金额" prop="amount">
          <el-input-number v-model="formData.amount" :min="0" :precision="2" style="width: 100%;" />
        </el-form-item>
        <el-form-item label="日期" prop="date">
          <el-date-picker v-model="formData.date" type="date" value-format="YYYY-MM-DD" style="width: 100%;" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="formData.description" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleCreate">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import { getCostRecords, createCostRecord, deleteCostRecord } from '@/api/cost'
import { getAllProjects } from '@/api/project'
import { getCostTypeLabel } from '@/utils/constants'
import { dayjs } from '@/utils/date'
import type { CostRecord, CostQueryParams } from '@/types/cost'
import type { Project } from '@/types/project'

const records = ref<CostRecord[]>([])
const projects = ref<Project[]>([])
const total = ref(0)
const loading = ref(false)
const showForm = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const dateRange = ref<string[]>([])

const queryParams = reactive<CostQueryParams>({ page: 1, pageSize: 20 })

const formData = reactive({
  projectId: undefined as number | undefined,
  type: 'labor' as const,
  amount: 0,
  date: dayjs().format('YYYY-MM-DD'),
  description: '',
})

const rules: FormRules = {
  projectId: [{ required: true, message: '请选择项目', trigger: 'change' }],
  type: [{ required: true, message: '请选择类型', trigger: 'change' }],
  amount: [{ required: true, message: '请输入金额', trigger: 'blur' }],
  date: [{ required: true, message: '请选择日期', trigger: 'change' }],
}

function formatCurrency(amount: number): string {
  return amount.toLocaleString('zh-CN', { style: 'currency', currency: 'CNY' })
}

async function fetchData() {
  loading.value = true
  try {
    if (dateRange.value?.length === 2) {
      queryParams.dateFrom = dateRange.value[0]
      queryParams.dateTo = dateRange.value[1]
    }
    const res = await getCostRecords(queryParams)
    records.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

async function handleDelete(row: CostRecord) {
  try {
    await ElMessageBox.confirm('确定要删除该记录吗？', '确认', { type: 'warning' })
    await deleteCostRecord(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

async function handleCreate() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    await createCostRecord(formData as any)
    ElMessage.success('创建成功')
    showForm.value = false
    fetchData()
  } catch {
    ElMessage.error('创建失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
