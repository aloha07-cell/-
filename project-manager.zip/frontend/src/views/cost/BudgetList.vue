<template>
  <div class="budget-list-page page-container">
    <PageHeader title="预算管理" />

    <el-card>
      <el-table :data="budgets" v-loading="loading" stripe>
        <el-table-column prop="projectName" label="项目名称" min-width="200" show-overflow-tooltip />
        <el-table-column prop="totalBudget" label="总预算" width="140" align="right">
          <template #default="{ row }">{{ formatCurrency(row.totalBudget) }}</template>
        </el-table-column>
        <el-table-column prop="spentBudget" label="已花费" width="140" align="right">
          <template #default="{ row }">{{ formatCurrency(row.spentBudget) }}</template>
        </el-table-column>
        <el-table-column prop="remainingBudget" label="剩余预算" width="140" align="right">
          <template #default="{ row }">
            <span :class="{ 'text-danger': row.remainingBudget < 0 }">{{ formatCurrency(row.remainingBudget) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="使用率" width="160">
          <template #default="{ row }">
            <el-progress :percentage="Math.min(row.varianceRate, 100)" :stroke-width="8" :color="getUsageColor(row.varianceRate)" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="showEditDialog" title="编辑预算" width="480px">
      <el-form label-width="100px">
        <el-form-item label="项目名称">
          <el-input :model-value="editTarget?.projectName" disabled />
        </el-form-item>
        <el-form-item label="总预算">
          <el-input-number v-model="editBudget" :min="0" :precision="2" :step="10000" style="width: 100%;" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showEditDialog = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import { getBudgets, updateProjectBudget } from '@/api/cost'
import type { Budget } from '@/types/cost'

const budgets = ref<Budget[]>([])
const loading = ref(false)
const showEditDialog = ref(false)
const editTarget = ref<Budget | null>(null)
const editBudget = ref(0)
const saving = ref(false)

function formatCurrency(amount: number): string {
  return amount.toLocaleString('zh-CN', { style: 'currency', currency: 'CNY' })
}

function getUsageColor(rate: number): string {
  if (rate >= 90) return '#F56C6C'
  if (rate >= 70) return '#E6A23C'
  return '#67C23A'
}

function handleEdit(budget: Budget) {
  editTarget.value = budget
  editBudget.value = budget.totalBudget
  showEditDialog.value = true
}

async function handleSave() {
  if (!editTarget.value) return
  saving.value = true
  try {
    await updateProjectBudget(editTarget.value.projectId, editBudget.value)
    ElMessage.success('保存成功')
    showEditDialog.value = false
    loadData()
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

async function loadData() {
  loading.value = true
  try {
    const res = await getBudgets()
    budgets.value = res.data
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style lang="scss" scoped>
.text-danger { color: $danger-color; }
</style>
