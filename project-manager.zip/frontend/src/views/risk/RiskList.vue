<template>
  <div class="risk-list-page page-container">
    <PageHeader title="风险管理">
      <template #actions>
        <el-button v-permission="'risk:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新建风险
        </el-button>
        <el-button @click="$router.push('/risks/matrix')">风险矩阵</el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-input v-model="queryParams.keyword" placeholder="搜索风险" clearable style="width: 220px;" @clear="fetchData" @keyup.enter="fetchData" />
        <el-select v-model="queryParams.level" placeholder="风险等级" clearable style="width: 120px;" @change="fetchData">
          <el-option v-for="item in RISK_LEVEL_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="queryParams.status" placeholder="状态" clearable style="width: 120px;" @change="fetchData">
          <el-option v-for="item in RISK_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-button type="primary" @click="fetchData">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="risks" v-loading="loading" stripe>
        <el-table-column prop="title" label="风险标题" min-width="200" show-overflow-tooltip />
        <el-table-column prop="projectName" label="所属项目" width="140" show-overflow-tooltip />
        <el-table-column prop="level" label="等级" width="80">
          <template #default="{ row }"><StatusTag :status="row.level" type="riskLevel" size="small" /></template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }"><StatusTag :status="row.status" type="riskStatus" size="small" /></template>
        </el-table-column>
        <el-table-column prop="ownerName" label="负责人" width="100" />
        <el-table-column prop="dueDate" label="截止日期" width="120">
          <template #default="{ row }">{{ formatDate(row.dueDate) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="handleView(row)">查看</el-button>
            <el-button v-permission="'risk:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>

    <!-- 新建风险对话框 -->
    <el-dialog v-model="showForm" title="新建风险" width="600px" :close-on-click-modal="false">
      <el-form ref="riskFormRef" :model="riskForm" :rules="riskRules" label-width="100px">
        <el-form-item label="风险标题" prop="title">
          <el-input v-model="riskForm.title" placeholder="请输入风险标题" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="riskForm.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="所属项目" prop="projectId">
          <el-select v-model="riskForm.projectId" placeholder="请选择" style="width: 100%;">
            <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="概率" prop="probability">
              <el-input-number v-model="riskForm.probability" :min="1" :max="5" style="width: 100%;" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="影响" prop="impact">
              <el-input-number v-model="riskForm.impact" :min="1" :max="5" style="width: 100%;" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="负责人" prop="ownerId">
          <el-select v-model="riskForm.ownerId" placeholder="请选择" filterable style="width: 100%;">
            <el-option v-for="u in users" :key="u.id" :label="u.nickname || u.username" :value="u.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="截止日期" prop="dueDate">
          <el-date-picker v-model="riskForm.dueDate" type="date" value-format="YYYY-MM-DD" style="width: 100%;" />
        </el-form-item>
        <el-form-item label="缓解计划">
          <el-input v-model="riskForm.mitigationPlan" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="应急计划">
          <el-input v-model="riskForm.contingencyPlan" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleCreateRisk">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import { getRisks, createRisk, deleteRisk } from '@/api/risk'
import { getAllProjects } from '@/api/project'
import { getAllUsers } from '@/api/user'
import { formatDate } from '@/utils/date'
import { RISK_LEVEL_OPTIONS, RISK_STATUS_OPTIONS } from '@/utils/constants'
import type { Risk, RiskQueryParams } from '@/types/risk'
import type { Project } from '@/types/project'
import type { User } from '@/types/user'

const risks = ref<Risk[]>([])
const projects = ref<Project[]>([])
const users = ref<User[]>([])
const total = ref(0)
const loading = ref(false)
const showForm = ref(false)
const submitting = ref(false)
const riskFormRef = ref<FormInstance>()

const queryParams = reactive<RiskQueryParams>({ page: 1, pageSize: 20, keyword: '' })

const riskForm = reactive({
  title: '', description: '', projectId: undefined as number | undefined,
  probability: 3, impact: 3, ownerId: undefined as number | undefined,
  dueDate: '', mitigationPlan: '', contingencyPlan: '', category: 'technical',
})

const riskRules: FormRules = {
  title: [{ required: true, message: '请输入风险标题', trigger: 'blur' }],
  projectId: [{ required: true, message: '请选择项目', trigger: 'change' }],
  ownerId: [{ required: true, message: '请选择负责人', trigger: 'change' }],
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getRisks(queryParams)
    risks.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.level = undefined
  queryParams.status = undefined
  queryParams.page = 1
  fetchData()
}

function handleView(_row: Risk) {
  // view detail
}

async function handleDelete(row: Risk) {
  try {
    await ElMessageBox.confirm('确定要删除该风险吗？', '确认', { type: 'warning' })
    await deleteRisk(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

async function handleCreateRisk() {
  const valid = await riskFormRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    await createRisk(riskForm as any)
    ElMessage.success('创建成功')
    showForm.value = false
    fetchData()
  } catch {
    ElMessage.error('创建失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  try {
    const [projectRes, userRes] = await Promise.allSettled([getAllProjects(), getAllUsers()])
    if (projectRes.status === 'fulfilled') projects.value = projectRes.value.data
    if (userRes.status === 'fulfilled') users.value = userRes.value.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
