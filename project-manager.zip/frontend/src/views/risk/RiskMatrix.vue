<template>
  <div class="risk-matrix-page page-container">
    <PageHeader title="风险矩阵" description="基于概率和影响的风险分布可视化">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="全部项目" clearable style="width: 200px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
      </template>
    </PageHeader>

    <el-card v-loading="loading">
      <div class="matrix-container">
        <div class="matrix-y-label">概率</div>
        <div class="matrix-grid">
          <div class="matrix-header-row">
            <div class="matrix-corner" />
            <div v-for="i in 5" :key="i" class="matrix-header-cell">{{ impactLabels[i - 1] }}</div>
          </div>
          <div v-for="row in 5" :key="row" class="matrix-row">
            <div class="matrix-y-cell">{{ probabilityLabels[5 - row] }}</div>
            <div
              v-for="col in 5"
              :key="col"
              class="matrix-cell"
              :class="getLevelClass(6 - row, col)"
              @click="showCellRisks(6 - row, col)"
            >
              <span class="cell-count">{{ getCellCount(6 - row, col) }}</span>
            </div>
          </div>
        </div>
        <div class="matrix-x-label">影响</div>
      </div>

      <div class="matrix-legend">
        <div class="legend-item"><span class="legend-color low" />低</div>
        <div class="legend-item"><span class="legend-color medium" />中</div>
        <div class="legend-item"><span class="legend-color high" />高</div>
        <div class="legend-item"><span class="legend-color critical" />严重</div>
      </div>
    </el-card>

    <!-- 风险列表弹窗 -->
    <el-dialog v-model="showRiskDialog" :title="`风险列表 (${selectedProbability}x${selectedImpact})`" width="600px">
      <el-table :data="cellRisks" stripe>
        <el-table-column prop="title" label="风险标题" min-width="200" />
        <el-table-column prop="projectName" label="项目" width="120" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }"><StatusTag :status="row.status" type="riskStatus" size="small" /></template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import { getRiskMatrix } from '@/api/risk'
import { getAllProjects } from '@/api/project'
import type { RiskMatrixCell } from '@/types/risk'
import type { Project } from '@/types/project'

const projects = ref<Project[]>([])
const selectedProjectId = ref<number | undefined>(undefined)
const loading = ref(false)
const matrixData = ref<RiskMatrixCell[]>([])
const showRiskDialog = ref(false)
const cellRisks = ref<any[]>([])
const selectedProbability = ref(0)
const selectedImpact = ref(0)

const probabilityLabels = ['很高', '高', '中', '低', '很低']
const impactLabels = ['很低', '低', '中', '高', '很高']

function getRiskLevel(probability: number, impact: number): string {
  const score = probability * impact
  if (score >= 15) return 'critical'
  if (score >= 10) return 'high'
  if (score >= 5) return 'medium'
  return 'low'
}

function getLevelClass(probability: number, impact: number): string {
  return getRiskLevel(probability, impact)
}

function getCellCount(probability: number, impact: number): number {
  const cell = matrixData.value.find((c) => c.probability === probability && c.impact === impact)
  return cell?.count || 0
}

function showCellRisks(probability: number, impact: number) {
  selectedProbability.value = probability
  selectedImpact.value = impact
  const cell = matrixData.value.find((c) => c.probability === probability && c.impact === impact)
  cellRisks.value = cell?.risks || []
  showRiskDialog.value = true
}

async function loadData() {
  loading.value = true
  try {
    const res = await getRiskMatrix(selectedProjectId.value)
    matrixData.value = res.data
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  loadData()
})
</script>

<style lang="scss" scoped>
.matrix-container {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: $spacing-sm;
  padding: $spacing-xl;
}

.matrix-y-label, .matrix-x-label {
  font-size: $font-size-md;
  font-weight: $font-weight-medium;
  color: $text-secondary;
  writing-mode: vertical-lr;
}

.matrix-x-label {
  writing-mode: horizontal-tb;
  margin-top: $spacing-sm;
}

.matrix-grid {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.matrix-header-row {
  display: flex;
  gap: 2px;
}

.matrix-corner {
  width: 60px;
}

.matrix-header-cell {
  width: 100px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: $font-size-sm;
  color: $text-secondary;
}

.matrix-row {
  display: flex;
  gap: 2px;
}

.matrix-y-cell {
  width: 60px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: $font-size-sm;
  color: $text-secondary;
}

.matrix-cell {
  width: 100px;
  height: 80px;
  border-radius: $border-radius-base;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform $transition-duration, box-shadow $transition-duration;

  &:hover {
    transform: scale(1.05);
    box-shadow: $shadow-md;
  }

  &.low { background-color: rgba(#67C23A, 0.2); }
  &.medium { background-color: rgba(#E6A23C, 0.2); }
  &.high { background-color: rgba(#F56C6C, 0.2); }
  &.critical { background-color: rgba(#d32f2f, 0.3); }
}

.cell-count {
  font-size: $font-size-lg;
  font-weight: $font-weight-bold;
  color: $text-primary;
}

.matrix-legend {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: $spacing-lg;
  margin-top: $spacing-lg;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  font-size: $font-size-sm;
  color: $text-secondary;
}

.legend-color {
  width: 16px;
  height: 16px;
  border-radius: $border-radius-sm;

  &.low { background-color: rgba(#67C23A, 0.5); }
  &.medium { background-color: rgba(#E6A23C, 0.5); }
  &.high { background-color: rgba(#F56C6C, 0.5); }
  &.critical { background-color: rgba(#d32f2f, 0.6); }
}
</style>
