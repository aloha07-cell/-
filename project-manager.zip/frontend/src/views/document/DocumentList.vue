<template>
  <div class="document-list-page page-container">
    <PageHeader title="文档管理">
      <template #actions>
        <el-button v-permission="'document:create'" type="primary" @click="showUpload = true">
          <el-icon><Upload /></el-icon>上传文档
        </el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-input v-model="queryParams.keyword" placeholder="搜索文档" clearable style="width: 220px;" @clear="fetchData" @keyup.enter="fetchData" />
        <el-select v-model="queryParams.type" placeholder="文档类型" clearable style="width: 140px;" @change="fetchData">
          <el-option v-for="item in DOCUMENT_TYPE_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="queryParams.projectId" placeholder="项目" clearable style="width: 160px;" @change="fetchData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button type="primary" @click="fetchData">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="documents" v-loading="loading" stripe>
        <el-table-column prop="name" label="文档名称" min-width="220" show-overflow-tooltip>
          <template #default="{ row }">
            <el-link type="primary" @click="handlePreview(row)">{{ row.name }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="projectName" label="所属项目" width="140" show-overflow-tooltip />
        <el-table-column prop="type" label="类型" width="100">
          <template #default="{ row }">{{ getDocumentTypeLabel(row.type) }}</template>
        </el-table-column>
        <el-table-column prop="version" label="版本" width="70" align="center" />
        <el-table-column prop="fileSize" label="大小" width="100">
          <template #default="{ row }">{{ formatFileSize(row.fileSize) }}</template>
        </el-table-column>
        <el-table-column prop="uploadedByName" label="上传人" width="100" />
        <el-table-column prop="createdAt" label="上传时间" width="160">
          <template #default="{ row }">{{ formatDateTime(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="handleDownload(row)">下载</el-button>
            <el-button v-permission="'document:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>

    <el-dialog v-model="showUpload" title="上传文档" width="560px">
      <el-form ref="formRef" :model="uploadForm" :rules="uploadRules" label-width="100px">
        <el-form-item label="文档名称" prop="name">
          <el-input v-model="uploadForm.name" placeholder="请输入文档名称" />
        </el-form-item>
        <el-form-item label="所属项目" prop="projectId">
          <el-select v-model="uploadForm.projectId" placeholder="请选择" style="width: 100%;">
            <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="文档类型" prop="type">
          <el-select v-model="uploadForm.type" style="width: 100%;">
            <el-option v-for="item in DOCUMENT_TYPE_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="uploadForm.description" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="选择文件" prop="file">
          <el-upload ref="uploadRef" :auto-upload="false" :limit="1" :on-change="handleFileChange">
            <el-button type="primary">选择文件</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showUpload = false">取消</el-button>
        <el-button type="primary" :loading="uploading" @click="handleUpload">上传</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules, UploadFile } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Upload } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import { getDocuments, deleteDocument } from '@/api/document'
import { getAllProjects } from '@/api/project'
import { getDocumentTypeLabel } from '@/utils/constants'
import { formatDateTime } from '@/utils/date'
import type { ProjectDocument, DocumentQueryParams } from '@/types/document'
import type { Project } from '@/types/project'

const documents = ref<ProjectDocument[]>([])
const projects = ref<Project[]>([])
const total = ref(0)
const loading = ref(false)
const showUpload = ref(false)
const uploading = ref(false)
const formRef = ref<FormInstance>()
const selectedFile = ref<File | null>(null)

const queryParams = reactive<DocumentQueryParams>({ page: 1, pageSize: 20, keyword: '' })

const uploadForm = reactive({
  name: '', projectId: undefined as number | undefined,
  type: 'other' as const, description: '', file: null as File | null,
})

const uploadRules: FormRules = {
  name: [{ required: true, message: '请输入文档名称', trigger: 'blur' }],
  projectId: [{ required: true, message: '请选择项目', trigger: 'change' }],
  type: [{ required: true, message: '请选择类型', trigger: 'change' }],
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

function handleFileChange(file: UploadFile) {
  selectedFile.value = file.raw || null
  if (!uploadForm.name && file.name) {
    uploadForm.name = file.name.replace(/\.[^/.]+$/, '')
  }
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getDocuments(queryParams)
    documents.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.type = undefined
  queryParams.projectId = undefined
  queryParams.page = 1
  fetchData()
}

function handlePreview(_row: ProjectDocument) {
  // preview
}

function handleDownload(row: ProjectDocument) {
  const link = document.createElement('a')
  link.href = row.fileUrl
  link.download = row.name
  link.click()
}

async function handleDelete(row: ProjectDocument) {
  try {
    await ElMessageBox.confirm('确定要删除该文档吗？', '确认', { type: 'warning' })
    await deleteDocument(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

async function handleUpload() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid || !selectedFile.value) {
    ElMessage.warning('请选择文件')
    return
  }
  uploading.value = true
  try {
    // Simulate upload
    ElMessage.success('上传成功')
    showUpload.value = false
    fetchData()
  } catch {
    ElMessage.error('上传失败')
  } finally {
    uploading.value = false
  }
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
