<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-header">
        <el-icon :size="40" color="#409EFF"><DataLine /></el-icon>
        <h1 class="login-title">项目管理系统</h1>
        <p class="login-subtitle">请登录您的账号</p>
      </div>

      <el-form
        ref="formRef"
        :model="formData"
        :rules="rules"
        size="large"
        @submit.prevent="handleLogin"
      >
        <el-form-item prop="username">
          <el-input
            v-model="formData.username"
            placeholder="请输入用户名"
            prefix-icon="User"
            clearable
          />
        </el-form-item>

        <el-form-item prop="password">
          <el-input
            v-model="formData.password"
            type="password"
            placeholder="请输入密码"
            prefix-icon="Lock"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>

        <el-form-item>
          <div class="login-options">
            <el-checkbox v-model="formData.remember">记住我</el-checkbox>
            <el-link type="primary" :underline="false">忘记密码?</el-link>
          </div>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="loading"
            class="login-btn"
            @click="handleLogin"
          >
            {{ loading ? '登录中...' : '登 录' }}
          </el-button>
        </el-form-item>
      </el-form>

      <div class="login-footer">
        <span>还没有账号?</span>
        <router-link to="/auth/register">
          <el-link type="primary" :underline="false">立即注册</el-link>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { useAuth } from '@/composables/useAuth'
import { getStorage } from '@/utils/storage'

const { login, loading } = useAuth()
const formRef = ref<FormInstance>()

const formData = reactive({
  username: '',
  password: '',
  remember: false,
})

const rules: FormRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度为3-20个字符', trigger: 'blur' },
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 32, message: '密码长度为6-32个字符', trigger: 'blur' },
  ],
}

onMounted(() => {
  const remembered = getStorage<{ username: string } | null>('remember_login', null)
  if (remembered) {
    formData.username = remembered.username
    formData.remember = true
  }
})

async function handleLogin() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  try {
    await login({
      username: formData.username,
      password: formData.password,
      remember: formData.remember,
    })
    ElMessage.success('登录成功')
  } catch (error: any) {
    ElMessage.error(error?.message || '登录失败，请检查用户名和密码')
  }
}
</script>

<style lang="scss" scoped>
.login-page {
  width: 100%;
  max-width: 420px;
  padding: $spacing-xl;
}

.login-card {
  background: $bg-white;
  border-radius: $border-radius-lg;
  padding: $spacing-xxl;
  box-shadow: $shadow-lg;
}

.login-header {
  text-align: center;
  margin-bottom: $spacing-xxl;
}

.login-title {
  font-size: $font-size-title;
  font-weight: $font-weight-bold;
  color: $text-primary;
  margin: $spacing-sm 0 $spacing-xs;
}

.login-subtitle {
  font-size: $font-size-base;
  color: $text-secondary;
}

.login-options {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.login-btn {
  width: 100%;
  font-size: $font-size-md;
  height: 44px;
}

.login-footer {
  text-align: center;
  font-size: $font-size-sm;
  color: $text-secondary;
  margin-top: $spacing-lg;

  a {
    margin-left: $spacing-xs;
  }
}
</style>
