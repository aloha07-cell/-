<template>
  <div class="error-page">
    <div class="error-content">
      <div class="error-code">403</div>
      <h1 class="error-title">访问受限</h1>
      <p class="error-desc">抱歉，您没有权限访问此页面。</p>
      <div class="error-actions">
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
        <el-button @click="$router.back()">返回上页</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
</script>

<style lang="scss" scoped>
.error-page {
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: $bg-page;
}

.error-content {
  text-align: center;
  padding: $spacing-xxl;
}

.error-code {
  font-size: 120px;
  font-weight: $font-weight-bold;
  color: $warning-color;
  line-height: 1;
  margin-bottom: $spacing-lg;
  text-shadow: 4px 4px 0 rgba($warning-color, 0.1);
}

.error-title {
  font-size: $font-size-xxl;
  font-weight: $font-weight-bold;
  color: $text-primary;
  margin-bottom: $spacing-sm;
}

.error-desc {
  font-size: $font-size-base;
  color: $text-secondary;
  margin-bottom: $spacing-xl;
}

.error-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: $spacing-sm;
}
</style>
