<template>
  <div class="progress-report-page page-container">
    <PageHeader title="进度报表">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="全部项目" clearable style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button @click="handleExport">导出报表</el-button>
      </template>
    </PageHeader>

    <el-row :gutter="20">
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>任务状态分布</span></template>
          <div ref="statusChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>项目进度概览</span></template>
          <div ref="progressChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
    </el-row>

    <el-card class="mt-base" v-loading="loading">
      <template #header><span>项目进度明细</span></template>
      <el-table :data="projectProgressList" stripe>
        <el-table-column prop="name" label="项目名称" min-width="200" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }"><StatusTag :status="row.status" type="project" size="small" /></template>
        </el-table-column>
        <el-table-column prop="totalTasks" label="总任务" width="80" align="center" />
        <el-table-column prop="completedTasks" label="已完成" width="80" align="center" />
        <el-table-column label="进度" width="180">
          <template #default="{ row }">
            <el-progress :percentage="row.progress" :stroke-width="8" />
          </template>
        </el-table-column>
        <el-table-column prop="endDate" label="截止日期" width="120">
          <template #default="{ row }">{{ formatDate(row.endDate) }}</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import { getProgressReport } from '@/api/report'
import { getAllProjects } from '@/api/project'
import { TASK_STATUS_OPTIONS } from '@/utils/constants'
import { formatDate } from '@/utils/date'
import type { Project } from '@/types/project'

const projects = ref<Project[]>([])
const selectedProjectId = ref<number | undefined>(undefined)
const loading = ref(false)
const projectProgressList = ref<any[]>([])
const statusChartRef = ref<HTMLElement>()
const progressChartRef = ref<HTMLElement>()

let statusChart: echarts.ECharts | null = null
let progressChart: echarts.ECharts | null = null

async function loadData() {
  loading.value = true
  try {
    const res = await getProgressReport({ projectId: selectedProjectId.value })
    const data = res.data as any
    projectProgressList.value = data.projects || []
    await nextTick()
    renderStatusChart(data.taskStats || {})
    renderProgressChart(data.projects || [])
  } finally {
    loading.value = false
  }
}

function renderStatusChart(stats: any) {
  if (!statusChartRef.value) return
  if (!statusChart) statusChart = echarts.init(statusChartRef.value)
  statusChart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie',
      radius: ['35%', '65%'],
      data: TASK_STATUS_OPTIONS.map((opt) => ({
        name: opt.label,
        value: stats[opt.value] || 0,
      })),
    }],
  })
}

function renderProgressChart(projectsList: any[]) {
  if (!progressChartRef.value) return
  if (!progressChart) progressChart = echarts.init(progressChartRef.value)
  progressChart.setOption({
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: projectsList.map((p) => p.name), axisLabel: { rotate: 30 } },
    yAxis: { type: 'value', max: 100, name: '%' },
    series: [{
      type: 'bar',
      data: projectsList.map((p) => p.progress),
      itemStyle: { color: '#409EFF', borderRadius: [4, 4, 0, 0] },
    }],
  })
}

function handleExport() {
  // export logic
}

function handleResize() {
  statusChart?.resize()
  progressChart?.resize()
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  loadData()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  statusChart?.dispose()
  progressChart?.dispose()
})
</script>
