<template>
  <div class="cost-report-page page-container">
    <PageHeader title="成本报表">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="全部项目" clearable style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button @click="handleExport">导出</el-button>
      </template>
    </PageHeader>

    <el-row :gutter="20">
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>成本类型占比</span></template>
          <div ref="pieChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
      <el-col :xs="24" :md="12">
        <el-card v-loading="loading">
          <template #header><span>月度成本对比</span></template>
          <div ref="barChartRef" style="height: 350px;" />
        </el-card>
      </el-col>
    </el-row>

    <el-card class="mt-base" v-loading="loading">
      <template #header><span>项目成本汇总</span></template>
      <el-table :data="projectCostList" stripe>
        <el-table-column prop="projectName" label="项目" min-width="200" />
        <el-table-column prop="budget" label="预算" width="140" align="right">
          <template #default="{ row }">{{ formatCurrency(row.budget) }}</template>
        </el-table-column>
        <el-table-column prop="spent" label="已花费" width="140" align="right">
          <template #default="{ row }">{{ formatCurrency(row.spent) }}</template>
        </el-table-column>
        <el-table-column prop="variance" label="偏差" width="120" align="right">
          <template #default="{ row }">
            <span :class="{ 'text-danger': row.variance < 0 }">{{ formatCurrency(row.variance) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="使用率" width="160">
          <template #default="{ row }">
            <el-progress :percentage="row.budget ? Math.round((row.spent / row.budget) * 100) : 0" :stroke-width="8" />
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import PageHeader from '@/components/common/PageHeader.vue'
import { getCostReport } from '@/api/report'
import { getAllProjects } from '@/api/project'
import { COST_TYPE_OPTIONS } from '@/utils/constants'
import type { Project } from '@/types/project'

const projects = ref<Project[]>([])
const selectedProjectId = ref<number | undefined>(undefined)
const loading = ref(false)
const projectCostList = ref<any[]>([])
const pieChartRef = ref<HTMLElement>()
const barChartRef = ref<HTMLElement>()

let pieChart: echarts.ECharts | null = null
let barChart: echarts.ECharts | null = null

function formatCurrency(amount: number): string {
  return amount.toLocaleString('zh-CN', { style: 'currency', currency: 'CNY' })
}

async function loadData() {
  loading.value = true
  try {
    const res = await getCostReport({ projectId: selectedProjectId.value })
    const data = res.data as any
    projectCostList.value = data.byProject || []
    await nextTick()
    renderPieChart(data)
    renderBarChart(data)
  } finally {
    loading.value = false
  }
}

function renderPieChart(data: any) {
  if (!pieChartRef.value) return
  if (!pieChart) pieChart = echarts.init(pieChartRef.value)
  pieChart.setOption({
    tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie', radius: ['35%', '65%'],
      data: (data.byType || []).map((item: any) => ({
        name: COST_TYPE_OPTIONS.find((o) => o.value === item.type)?.label || item.type,
        value: item.amount,
      })),
    }],
  })
}

function renderBarChart(data: any) {
  if (!barChartRef.value) return
  if (!barChart) barChart = echarts.init(barChartRef.value)
  barChart.setOption({
    tooltip: { trigger: 'axis' },
    legend: { data: ['预算', '实际'], bottom: 0 },
    xAxis: { type: 'category', data: (data.byMonth || []).map((m: any) => m.month) },
    yAxis: { type: 'value', name: '金额' },
    series: [
      { name: '预算', type: 'bar', data: (data.byMonth || []).map((m: any) => m.planned), itemStyle: { color: '#409EFF' } },
      { name: '实际', type: 'bar', data: (data.byMonth || []).map((m: any) => m.actual), itemStyle: { color: '#E6A23C' } },
    ],
  })
}

function handleExport() {
  // export
}

function handleResize() {
  pieChart?.resize()
  barChart?.resize()
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  loadData()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  pieChart?.dispose()
  barChart?.dispose()
})
</script>

<style lang="scss" scoped>
.text-danger { color: $danger-color; }
</style>
