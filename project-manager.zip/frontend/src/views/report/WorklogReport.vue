<template>
  <div class="worklog-report-page page-container">
    <PageHeader title="工时报表">
      <template #actions>
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始" end-placeholder="结束" value-format="YYYY-MM-DD" style="width: 280px; margin-right: 12px;" @change="loadData" />
        <el-select v-model="selectedProjectId" placeholder="全部项目" clearable style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button @click="handleExport">导出</el-button>
      </template>
    </PageHeader>

    <el-row :gutter="20" class="stat-cards">
      <el-col :xs="12" :sm="6">
        <div class="mini-stat-card">
          <span class="mini-stat-value">{{ stats?.todayHours || 0 }}h</span>
          <span class="mini-stat-label">今日工时</span>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="mini-stat-card">
          <span class="mini-stat-value">{{ stats?.weekHours || 0 }}h</span>
          <span class="mini-stat-label">本周工时</span>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="mini-stat-card">
          <span class="mini-stat-value">{{ stats?.monthHours || 0 }}h</span>
          <span class="mini-stat-label">本月工时</span>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="mini-stat-card">
          <span class="mini-stat-value">{{ stats?.dailyAverage || 0 }}h</span>
          <span class="mini-stat-label">日均工时</span>
        </div>
      </el-col>
    </el-row>

    <el-card v-loading="loading">
      <template #header><span>每日工时趋势</span></template>
      <div ref="chartRef" style="height: 400px;" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import PageHeader from '@/components/common/PageHeader.vue'
import { getWorklogReport } from '@/api/report'
import { getWorklogStats } from '@/api/worklog'
import { getAllProjects } from '@/api/project'
import type { WorklogStats } from '@/types/worklog'
import type { Project } from '@/types/project'

const projects = ref<Project[]>([])
const selectedProjectId = ref<number | undefined>(undefined)
const loading = ref(false)
const stats = ref<WorklogStats | null>(null)
const dateRange = ref<string[]>([])
const chartRef = ref<HTMLElement>()
let chart: echarts.ECharts | null = null

async function loadData() {
  loading.value = true
  try {
    const params: any = {}
    if (selectedProjectId.value) params.projectId = selectedProjectId.value
    if (dateRange.value?.length === 2) {
      params.dateFrom = dateRange.value[0]
      params.dateTo = dateRange.value[1]
    }
    const [statsRes, reportRes] = await Promise.allSettled([
      getWorklogStats(params),
      getWorklogReport(params),
    ])
    if (statsRes.status === 'fulfilled') stats.value = statsRes.value.data
    if (reportRes.status === 'fulfilled') {
      await nextTick()
      renderChart(reportRes.value.data)
    }
  } finally {
    loading.value = false
  }
}

function renderChart(data: any) {
  if (!chartRef.value) return
  if (!chart) chart = echarts.init(chartRef.value)
  chart.setOption({
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: (data.daily || []).map((d: any) => d.date) },
    yAxis: { type: 'value', name: '工时(h)' },
    series: [{
      type: 'bar',
      data: (data.daily || []).map((d: any) => d.hours),
      itemStyle: { color: '#409EFF', borderRadius: [4, 4, 0, 0] },
    }],
  })
}

function handleExport() {
  // export
}

function handleResize() {
  chart?.resize()
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  loadData()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  chart?.dispose()
})
</script>

<style lang="scss" scoped>
.stat-cards {
  margin-bottom: $spacing-base;
}

.mini-stat-card {
  background: $bg-white;
  border-radius: $border-radius-md;
  padding: $spacing-lg;
  text-align: center;
  box-shadow: $shadow-sm;
}

.mini-stat-value {
  display: block;
  font-size: $font-size-xxl;
  font-weight: $font-weight-bold;
  color: $primary-color;
}

.mini-stat-label {
  display: block;
  font-size: $font-size-sm;
  color: $text-secondary;
  margin-top: $spacing-xs;
}
</style>
