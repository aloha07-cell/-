<template>
  <el-dialog
    v-model="visible"
    title="创建项目"
    width="640px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <el-form
      ref="formRef"
      :model="formData"
      :rules="rules"
      label-width="100px"
      label-position="right"
    >
      <el-form-item label="项目名称" prop="name">
        <el-input v-model="formData.name" placeholder="请输入项目名称" maxlength="50" show-word-limit />
      </el-form-item>

      <el-form-item label="项目编号" prop="code">
        <el-input v-model="formData.code" placeholder="请输入项目编号（如 PRJ-001）" maxlength="20" />
      </el-form-item>

      <el-form-item label="项目描述" prop="description">
        <el-input v-model="formData.description" type="textarea" :rows="3" placeholder="请输入项目描述" maxlength="500" show-word-limit />
      </el-form-item>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="项目状态" prop="status">
            <el-select v-model="formData.status" placeholder="请选择" style="width: 100%;">
              <el-option v-for="item in PROJECT_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="优先级" prop="priority">
            <el-select v-model="formData.priority" placeholder="请选择" style="width: 100%;">
              <el-option v-for="item in PROJECT_PRIORITY_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="开始日期" prop="startDate">
            <el-date-picker v-model="formData.startDate" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" style="width: 100%;" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="结束日期" prop="endDate">
            <el-date-picker v-model="formData.endDate" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" style="width: 100%;" />
          </el-form-item>
        </el-col>
      </el-row>

      <el-form-item label="预算金额" prop="budget">
        <el-input-number v-model="formData.budget" :min="0" :precision="2" :step="10000" placeholder="请输入预算金额" style="width: 100%;" />
      </el-form-item>

      <el-form-item label="负责人" prop="ownerId">
        <el-select v-model="formData.ownerId" placeholder="请选择负责人" filterable style="width: 100%;">
          <el-option v-for="user in users" :key="user.id" :label="user.nickname || user.username" :value="user.id" />
        </el-select>
      </el-form-item>

      <el-form-item label="标签">
        <el-select v-model="formData.tags" multiple filterable allow-create placeholder="添加标签" style="width: 100%;" />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" :loading="loading" @click="handleSubmit">创建</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { createProject } from '@/api/project'
import { getAllUsers } from '@/api/user'
import { PROJECT_STATUS_OPTIONS, PROJECT_PRIORITY_OPTIONS } from '@/utils/constants'
import type { User } from '@/types/user'

const props = defineProps<{
  modelValue: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  created: []
}>()

const visible = ref(false)
const formRef = ref<FormInstance>()
const loading = ref(false)
const users = ref<User[]>([])

watch(() => props.modelValue, (val) => {
  visible.value = val
  if (val) {
    loadUsers()
  }
})

watch(visible, (val) => {
  emit('update:modelValue', val)
})

const formData = reactive({
  name: '',
  code: '',
  description: '',
  status: 'not_started' as const,
  priority: 'medium' as const,
  startDate: '',
  endDate: '',
  budget: 0,
  ownerId: undefined as number | undefined,
  tags: [] as string[],
})

const rules: FormRules = {
  name: [{ required: true, message: '请输入项目名称', trigger: 'blur' }],
  code: [{ required: true, message: '请输入项目编号', trigger: 'blur' }],
  status: [{ required: true, message: '请选择项目状态', trigger: 'change' }],
  priority: [{ required: true, message: '请选择优先级', trigger: 'change' }],
  startDate: [{ required: true, message: '请选择开始日期', trigger: 'change' }],
  endDate: [{ required: true, message: '请选择结束日期', trigger: 'change' }],
  ownerId: [{ required: true, message: '请选择负责人', trigger: 'change' }],
}

async function loadUsers() {
  try {
    const res = await getAllUsers()
    users.value = res.data
  } catch {
    // silent
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    await createProject(formData as any)
    ElMessage.success('项目创建成功')
    handleClose()
    emit('created')
  } catch {
    ElMessage.error('创建失败')
  } finally {
    loading.value = false
  }
}

function handleClose() {
  visible.value = false
  formRef.value?.resetFields()
  formData.name = ''
  formData.code = ''
  formData.description = ''
  formData.status = 'not_started'
  formData.priority = 'medium'
  formData.startDate = ''
  formData.endDate = ''
  formData.budget = 0
  formData.ownerId = undefined
  formData.tags = []
}
</script>
