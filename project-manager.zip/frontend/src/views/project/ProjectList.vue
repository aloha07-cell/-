<template>
  <div class="project-list-page page-container">
    <PageHeader title="项目列表">
      <template #actions>
        <el-button v-permission="'project:create'" type="primary" @click="$router.push('/projects/create')">
          <el-icon><Plus /></el-icon>创建项目
        </el-button>
      </template>
    </PageHeader>

    <!-- 搜索筛选 -->
    <el-card class="search-card">
      <div class="search-bar">
        <el-input
          v-model="queryParams.keyword"
          placeholder="搜索项目名称或编号"
          prefix-icon="Search"
          clearable
          style="width: 260px;"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <el-select v-model="queryParams.status" placeholder="项目状态" clearable style="width: 140px;" @change="handleSearch">
          <el-option v-for="item in PROJECT_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="queryParams.priority" placeholder="优先级" clearable style="width: 120px;" @change="handleSearch">
          <el-option v-for="item in PROJECT_PRIORITY_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-button type="primary" @click="handleSearch">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
        <div style="flex: 1;" />
        <el-radio-group v-model="viewMode" size="small">
          <el-radio-button value="card">卡片</el-radio-button>
          <el-radio-button value="list">列表</el-radio-button>
        </el-radio-group>
      </div>
    </el-card>

    <!-- 卡片视图 -->
    <div v-if="viewMode === 'card'" class="project-grid">
      <el-card
        v-for="project in projects"
        :key="project.id"
        class="project-card"
        shadow="hover"
        @click="$router.push(`/projects/${project.id}`)"
      >
        <div class="project-cover" :style="{ backgroundColor: getCoverColor(project.id) }">
          <span class="project-code">{{ project.code }}</span>
        </div>
        <div class="project-body">
          <div class="project-name text-ellipsis">{{ project.name }}</div>
          <div class="project-desc text-ellipsis">{{ project.description || '暂无描述' }}</div>
          <div class="project-meta">
            <StatusTag :status="project.status" type="project" size="small" />
            <StatusTag :status="project.priority" type="taskPriority" size="small" />
          </div>
          <el-progress :percentage="project.progress" :stroke-width="6" :color="getProgressColor(project.progress)" class="project-progress" />
          <div class="project-footer">
            <div class="project-dates">
              <span>{{ formatDate(project.startDate) }}</span>
              <span>~</span>
              <span>{{ formatDate(project.endDate) }}</span>
            </div>
            <div class="project-members">
              <UserAvatar v-for="member in project.members?.slice(0, 3)" :key="member.id" :name="member.nickname" :src="member.avatar" :size="24" />
              <span v-if="(project.memberCount || 0) > 3" class="member-count">+{{ project.memberCount - 3 }}</span>
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 列表视图 -->
    <el-card v-else>
      <el-table :data="projects" v-loading="loading" stripe>
        <el-table-column prop="code" label="编号" width="120" />
        <el-table-column prop="name" label="项目名称" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <el-link type="primary" @click="$router.push(`/projects/${row.id}`)">{{ row.name }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <StatusTag :status="row.status" type="project" size="small" />
          </template>
        </el-table-column>
        <el-table-column prop="priority" label="优先级" width="80">
          <template #default="{ row }">
            <StatusTag :status="row.priority" type="taskPriority" size="small" />
          </template>
        </el-table-column>
        <el-table-column prop="progress" label="进度" width="150">
          <template #default="{ row }">
            <el-progress :percentage="row.progress" :stroke-width="6" :color="getProgressColor(row.progress)" />
          </template>
        </el-table-column>
        <el-table-column prop="ownerName" label="负责人" width="100" />
        <el-table-column prop="endDate" label="截止日期" width="120">
          <template #default="{ row }">{{ formatDate(row.endDate) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/projects/${row.id}`)">详情</el-button>
            <el-button v-permission="'project:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 分页 -->
    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="queryParams.page"
        v-model:page-size="queryParams.pageSize"
        :total="total"
        :page-sizes="[12, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="fetchData"
        @current-change="fetchData"
      />
    </div>

    <ConfirmDialog
      v-model="deleteDialogVisible"
      title="删除项目"
      :message="`确定要删除项目「${deleteTarget?.name}」吗？此操作不可恢复。`"
      type="danger"
      confirm-text="删除"
      @confirm="confirmDelete"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import ConfirmDialog from '@/components/common/ConfirmDialog.vue'
import { getProjects, deleteProject } from '@/api/project'
import { formatDate } from '@/utils/date'
import { PROJECT_STATUS_OPTIONS, PROJECT_PRIORITY_OPTIONS } from '@/utils/constants'
import type { Project, ProjectQueryParams } from '@/types/project'

const projects = ref<Project[]>([])
const total = ref(0)
const loading = ref(false)
const viewMode = ref<'card' | 'list'>('card')
const deleteDialogVisible = ref(false)
const deleteTarget = ref<Project | null>(null)

const queryParams = reactive<ProjectQueryParams>({
  page: 1,
  pageSize: 12,
  keyword: '',
  status: undefined,
  priority: undefined,
})

const coverColors = ['#409EFF', '#67C23A', '#E6A23C', '#F56C6C', '#909399', '#764ba2', '#667eea', '#f093fb']

function getCoverColor(id: number): string {
  return coverColors[id % coverColors.length]
}

function getProgressColor(progress: number): string {
  if (progress >= 80) return '#67C23A'
  if (progress >= 50) return '#409EFF'
  if (progress >= 30) return '#E6A23C'
  return '#F56C6C'
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getProjects(queryParams)
    projects.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  queryParams.page = 1
  fetchData()
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.status = undefined
  queryParams.priority = undefined
  queryParams.page = 1
  fetchData()
}

function handleDelete(project: Project) {
  deleteTarget.value = project
  deleteDialogVisible.value = true
}

async function confirmDelete() {
  if (!deleteTarget.value) return
  try {
    await deleteProject(deleteTarget.value.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    ElMessage.error('删除失败')
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card {
  margin-bottom: $spacing-base;
}

.project-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: $spacing-base;
}

.project-card {
  cursor: pointer;
  border-radius: $border-radius-md;
  overflow: hidden;

  :deep(.el-card__body) {
    padding: 0;
  }
}

.project-cover {
  height: 120px;
  display: flex;
  align-items: flex-end;
  padding: $spacing-base;
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.project-code {
  font-size: $font-size-sm;
  color: rgba(255, 255, 255, 0.8);
  background: rgba(0, 0, 0, 0.2);
  padding: $spacing-xs $spacing-sm;
  border-radius: $border-radius-sm;
}

.project-body {
  padding: $spacing-base;
}

.project-name {
  font-size: $font-size-md;
  font-weight: $font-weight-medium;
  color: $text-primary;
  margin-bottom: $spacing-xs;
}

.project-desc {
  font-size: $font-size-sm;
  color: $text-secondary;
  margin-bottom: $spacing-sm;
}

.project-meta {
  display: flex;
  gap: $spacing-sm;
  margin-bottom: $spacing-sm;
}

.project-progress {
  margin-bottom: $spacing-sm;
}

.project-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.project-dates {
  font-size: $font-size-xs;
  color: $text-secondary;
  display: flex;
  gap: $spacing-xs;
}

.project-members {
  display: flex;
  align-items: center;

  .el-avatar {
    margin-left: -6px;
    border: 2px solid white;
  }

  .el-avatar:first-child {
    margin-left: 0;
  }
}

.member-count {
  font-size: $font-size-xs;
  color: $text-secondary;
  margin-left: $spacing-xs;
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: $spacing-base;
}
</style>
