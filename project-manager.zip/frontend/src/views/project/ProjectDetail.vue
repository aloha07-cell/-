<template>
  <div class="project-detail-page page-container">
    <PageHeader :title="project?.name || '项目详情'" :description="project?.description">
      <template #actions>
        <el-button @click="$router.back()">返回</el-button>
        <el-button v-permission="'project:edit'" type="primary" @click="showEditDialog = true">编辑</el-button>
      </template>
    </PageHeader>

    <el-tabs v-model="activeTab" class="project-tabs">
      <!-- 概览 -->
      <el-tab-pane label="概览" name="overview">
        <el-row :gutter="20">
          <el-col :xs="24" :md="16">
            <el-card>
              <div class="overview-info">
                <div class="info-grid">
                  <div class="info-item">
                    <span class="info-label">项目编号</span>
                    <span class="info-value">{{ project?.code }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">项目状态</span>
                    <StatusTag v-if="project" :status="project.status" type="project" />
                  </div>
                  <div class="info-item">
                    <span class="info-label">优先级</span>
                    <StatusTag v-if="project" :status="project.priority" type="taskPriority" />
                  </div>
                  <div class="info-item">
                    <span class="info-label">负责人</span>
                    <span class="info-value">{{ project?.ownerName }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">开始日期</span>
                    <span class="info-value">{{ formatDate(project?.startDate) }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">截止日期</span>
                    <span class="info-value">{{ formatDate(project?.endDate) }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">预算</span>
                    <span class="info-value">{{ formatBudget(project?.budget) }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">已花费</span>
                    <span class="info-value">{{ formatBudget(project?.spentBudget) }}</span>
                  </div>
                </div>
                <div class="progress-section">
                  <span class="progress-label">项目进度</span>
                  <el-progress :percentage="project?.progress || 0" :stroke-width="12" :color="getProgressColor(project?.progress || 0)" />
                </div>
              </div>
            </el-card>
          </el-col>
          <el-col :xs="24" :md="8">
            <el-card>
              <template #header><span>项目统计</span></template>
              <div class="stats-grid">
                <div class="stat-item">
                  <span class="stat-number">{{ project?.taskCount || 0 }}</span>
                  <span class="stat-label">总任务</span>
                </div>
                <div class="stat-item">
                  <span class="stat-number">{{ project?.completedTaskCount || 0 }}</span>
                  <span class="stat-label">已完成</span>
                </div>
                <div class="stat-item">
                  <span class="stat-number">{{ project?.memberCount || 0 }}</span>
                  <span class="stat-label">成员</span>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>

      <!-- 任务 -->
      <el-tab-pane label="任务" name="tasks">
        <div class="tab-actions">
          <el-button v-permission="'task:create'" type="primary" size="small" @click="showTaskForm = true">
            <el-icon><Plus /></el-icon>新建任务
          </el-button>
        </div>
        <el-table :data="tasks" v-loading="tasksLoading" stripe>
          <el-table-column prop="wbsCode" label="WBS" width="80" />
          <el-table-column prop="title" label="任务名称" min-width="200" show-overflow-tooltip />
          <el-table-column prop="status" label="状态" width="100">
            <template #default="{ row }"><StatusTag :status="row.status" type="task" size="small" /></template>
          </el-table-column>
          <el-table-column prop="priority" label="优先级" width="80">
            <template #default="{ row }"><StatusTag :status="row.priority" type="taskPriority" size="small" /></template>
          </el-table-column>
          <el-table-column prop="assigneeName" label="负责人" width="100" />
          <el-table-column prop="dueDate" label="截止日期" width="120">
            <template #default="{ row }">{{ formatDate(row.dueDate) }}</template>
          </el-table-column>
          <el-table-column prop="progress" label="进度" width="100">
            <template #default="{ row }">
              <el-progress :percentage="row.progress" :stroke-width="6" />
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>

      <!-- 成员 -->
      <el-tab-pane label="成员" name="members">
        <div class="tab-actions">
          <el-button v-permission="'project:member:add'" type="primary" size="small" @click="showAddMember = true">
            <el-icon><Plus /></el-icon>添加成员
          </el-button>
        </div>
        <el-table :data="members" v-loading="membersLoading" stripe>
          <el-table-column label="成员" min-width="200">
            <template #default="{ row }">
              <div class="member-cell">
                <UserAvatar :name="row.nickname" :src="row.avatar" :size="32" />
                <div class="member-info">
                  <span class="member-name">{{ row.nickname }}</span>
                  <span class="member-email">{{ row.email }}</span>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="role" label="角色" width="120" />
          <el-table-column prop="joinedAt" label="加入时间" width="120">
            <template #default="{ row }">{{ formatDate(row.joinedAt) }}</template>
          </el-table-column>
          <el-table-column label="操作" width="100">
            <template #default="{ row }">
              <el-button v-permission="'project:member:remove'" text type="danger" size="small" @click="handleRemoveMember(row)">移除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>

      <!-- 设置 -->
      <el-tab-pane label="设置" name="settings">
        <el-card>
          <el-form label-width="120px">
            <el-form-item label="项目名称">
              <el-input v-model="editForm.name" />
            </el-form-item>
            <el-form-item label="项目描述">
              <el-input v-model="editForm.description" type="textarea" :rows="3" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="handleSaveSettings">保存</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <TaskForm v-if="showTaskForm" v-model="showTaskForm" :project-id="projectId" @created="loadTasks" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import TaskForm from '@/views/task/TaskForm.vue'
import { getProject, updateProject, getProjectMembers, removeProjectMember } from '@/api/project'
import { getTasks } from '@/api/task'
import { formatDate } from '@/utils/date'
import type { Project, ProjectMember } from '@/types/project'
import type { Task } from '@/types/task'

const route = useRoute()
const projectId = Number(route.params.id)

const project = ref<Project | null>(null)
const tasks = ref<Task[]>([])
const members = ref<ProjectMember[]>([])
const activeTab = ref('overview')
const tasksLoading = ref(false)
const membersLoading = ref(false)
const showEditDialog = ref(false)
const showTaskForm = ref(false)
const showAddMember = ref(false)
const saving = ref(false)

const editForm = reactive({
  name: '',
  description: '',
})

function getProgressColor(progress: number): string {
  if (progress >= 80) return '#67C23A'
  if (progress >= 50) return '#409EFF'
  if (progress >= 30) return '#E6A23C'
  return '#F56C6C'
}

function formatBudget(budget?: number): string {
  if (!budget) return '0.00'
  return budget.toLocaleString('zh-CN', { style: 'currency', currency: 'CNY' })
}

async function loadProject() {
  try {
    const res = await getProject(projectId)
    project.value = res.data
    editForm.name = res.data.name
    editForm.description = res.data.description
  } catch {
    ElMessage.error('加载项目失败')
  }
}

async function loadTasks() {
  tasksLoading.value = true
  try {
    const res = await getTasks({ page: 1, pageSize: 100, projectId })
    tasks.value = res.data.items
  } finally {
    tasksLoading.value = false
  }
}

async function loadMembers() {
  membersLoading.value = true
  try {
    const res = await getProjectMembers(projectId)
    members.value = res.data
  } finally {
    membersLoading.value = false
  }
}

async function handleRemoveMember(member: ProjectMember) {
  try {
    await ElMessageBox.confirm(`确定要移除成员「${member.nickname}」吗？`, '确认')
    await removeProjectMember(projectId, member.userId)
    ElMessage.success('移除成功')
    loadMembers()
  } catch {
    // cancelled
  }
}

async function handleSaveSettings() {
  saving.value = true
  try {
    await updateProject(projectId, { name: editForm.name, description: editForm.description })
    ElMessage.success('保存成功')
    loadProject()
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadProject()
  loadTasks()
  loadMembers()
})
</script>

<style lang="scss" scoped>
.project-tabs {
  :deep(.el-tabs__header) {
    margin-bottom: $spacing-base;
  }
}

.tab-actions {
  display: flex;
  justify-content: flex-end;
  margin-bottom: $spacing-base;
}

.overview-info {
  .info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: $spacing-lg;
    margin-bottom: $spacing-xl;

    @media (max-width: $breakpoint-sm) {
      grid-template-columns: 1fr;
    }
  }

  .info-item {
    display: flex;
    flex-direction: column;
    gap: $spacing-xs;
  }

  .info-label {
    font-size: $font-size-sm;
    color: $text-secondary;
  }

  .info-value {
    font-size: $font-size-base;
    color: $text-primary;
    font-weight: $font-weight-medium;
  }
}

.progress-section {
  .progress-label {
    display: block;
    font-size: $font-size-sm;
    color: $text-secondary;
    margin-bottom: $spacing-sm;
  }
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: $spacing-base;
  text-align: center;
}

.stat-item {
  display: flex;
  flex-direction: column;
  gap: $spacing-xs;
}

.stat-number {
  font-size: $font-size-xxl;
  font-weight: $font-weight-bold;
  color: $primary-color;
}

.stat-label {
  font-size: $font-size-sm;
  color: $text-secondary;
}

.member-cell {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.member-info {
  display: flex;
  flex-direction: column;
}

.member-name {
  font-size: $font-size-base;
  color: $text-primary;
}

.member-email {
  font-size: $font-size-xs;
  color: $text-secondary;
}
</style>
