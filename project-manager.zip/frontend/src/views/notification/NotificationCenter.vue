<template>
  <div class="notification-page page-container">
    <PageHeader title="消息中心">
      <template #actions>
        <el-button type="primary" :disabled="notificationStore.unreadCount === 0" @click="handleMarkAllRead">
          全部已读
        </el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-tabs v-model="activeTab" @tab-change="handleTabChange">
        <el-tab-pane label="全部" name="all" />
        <el-tab-pane label="未读" name="unread" />
        <el-tab-pane label="系统通知" name="system" />
        <el-tab-pane label="任务通知" name="task" />
        <el-tab-pane label="项目通知" name="project" />
      </el-tabs>

      <div class="notification-list" v-loading="loading">
        <div
          v-for="item in notifications"
          :key="item.id"
          class="notification-item"
          :class="{ unread: item.status === 'unread' }"
          @click="handleClick(item)"
        >
          <div class="notification-icon">
            <el-icon :size="20">
              <Bell v-if="item.type === 'system'" />
              <List v-else-if="item.type === 'task'" />
              <Folder v-else-if="item.type === 'project'" />
              <ChatDotRound v-else-if="item.type === 'mention'" />
              <Warning v-else />
            </el-icon>
          </div>
          <div class="notification-content">
            <div class="notification-title">{{ item.title }}</div>
            <div class="notification-body">{{ item.content }}</div>
            <div class="notification-meta">
              <span v-if="item.senderName" class="meta-sender">{{ item.senderName }}</span>
              <span class="meta-time">{{ formatRelativeTime(item.createdAt) }}</span>
            </div>
          </div>
          <div class="notification-actions">
            <el-badge v-if="item.status === 'unread'" is-dot />
            <el-button text type="danger" size="small" @click.stop="handleDelete(item)">
              <el-icon><Delete /></el-icon>
            </el-button>
          </div>
        </div>

        <EmptyState v-if="notifications.length === 0" description="暂无消息" />
      </div>

      <div v-if="total > queryParams.pageSize" class="pagination-wrapper">
        <el-pagination
          v-model:current-page="queryParams.page"
          :page-size="queryParams.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="fetchData"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Bell, List, Folder, ChatDotRound, Warning, Delete } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import { useNotificationStore } from '@/stores/useNotificationStore'
import { formatRelativeTime } from '@/utils/date'
import type { Notification } from '@/types/notification'

const notificationStore = useNotificationStore()
const notifications = ref<Notification[]>([])
const total = ref(0)
const loading = ref(false)
const activeTab = ref('all')

const queryParams = reactive({
  page: 1,
  pageSize: 20,
  type: undefined as string | undefined,
  status: undefined as string | undefined,
})

async function fetchData() {
  loading.value = true
  try {
    const res = await notificationStore.fetchNotifications(queryParams)
    notifications.value = notificationStore.notifications
    total.value = notificationStore.total
  } finally {
    loading.value = false
  }
}

function handleTabChange(tab: string | number) {
  queryParams.page = 1
  if (tab === 'all') {
    queryParams.type = undefined
    queryParams.status = undefined
  } else if (tab === 'unread') {
    queryParams.type = undefined
    queryParams.status = 'unread'
  } else {
    queryParams.type = tab as string
    queryParams.status = undefined
  }
  fetchData()
}

async function handleClick(item: Notification) {
  if (item.status === 'unread') {
    await notificationStore.markRead(item.id)
    item.status = 'read'
  }
  if (item.link) {
    window.location.href = item.link
  }
}

async function handleMarkAllRead() {
  await notificationStore.markAllRead()
  notifications.value.forEach((n) => { n.status = 'read' })
  ElMessage.success('已全部标记为已读')
}

async function handleDelete(item: Notification) {
  const index = notifications.value.findIndex((n) => n.id === item.id)
  if (index !== -1) {
    notifications.value.splice(index, 1)
    total.value--
  }
}

onMounted(() => {
  fetchData()
  notificationStore.fetchUnreadCount()
})
</script>

<style lang="scss" scoped>
.notification-list {
  display: flex;
  flex-direction: column;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: $spacing-base;
  padding: $spacing-base;
  border-radius: $border-radius-base;
  cursor: pointer;
  transition: background-color $transition-duration;
  border-bottom: 1px solid $border-lighter;

  &:hover {
    background-color: $bg-color;
  }

  &.unread {
    background-color: rgba($primary-color, 0.04);
  }
}

.notification-icon {
  width: 40px;
  height: 40px;
  border-radius: $border-radius-circle;
  background: $bg-color;
  display: flex;
  align-items: center;
  justify-content: center;
  color: $primary-color;
  flex-shrink: 0;
}

.notification-content {
  flex: 1;
  min-width: 0;
}

.notification-title {
  font-size: $font-size-base;
  font-weight: $font-weight-medium;
  color: $text-primary;
  margin-bottom: $spacing-xs;
}

.notification-body {
  font-size: $font-size-sm;
  color: $text-regular;
  margin-bottom: $spacing-xs;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.notification-meta {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  font-size: $font-size-xs;
  color: $text-secondary;
}

.notification-actions {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
  flex-shrink: 0;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: $spacing-base;
}
</style>
