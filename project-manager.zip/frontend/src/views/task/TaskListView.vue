<template>
  <div class="task-list-page page-container">
    <PageHeader title="任务列表">
      <template #actions>
        <el-button v-permission="'task:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新建任务
        </el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-input v-model="queryParams.keyword" placeholder="搜索任务" prefix-icon="Search" clearable style="width: 220px;" @clear="fetchData" @keyup.enter="fetchData" />
        <el-select v-model="queryParams.projectId" placeholder="项目" clearable style="width: 160px;" @change="fetchData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-select v-model="queryParams.status" placeholder="状态" clearable style="width: 120px;" @change="fetchData">
          <el-option v-for="item in TASK_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-select v-model="queryParams.priority" placeholder="优先级" clearable style="width: 120px;" @change="fetchData">
          <el-option v-for="item in TASK_PRIORITY_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-button type="primary" @click="fetchData">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="tasks" v-loading="loading" stripe @sort-change="handleSortChange">
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="wbsCode" label="WBS" width="80" />
        <el-table-column prop="title" label="任务名称" min-width="220" show-overflow-tooltip>
          <template #default="{ row }">
            <el-link type="primary" @click="openDetail(row)">{{ row.title }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="projectName" label="所属项目" width="140" show-overflow-tooltip />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }"><StatusTag :status="row.status" type="task" size="small" /></template>
        </el-table-column>
        <el-table-column prop="priority" label="优先级" width="80">
          <template #default="{ row }"><StatusTag :status="row.priority" type="taskPriority" size="small" /></template>
        </el-table-column>
        <el-table-column prop="assigneeName" label="负责人" width="100">
          <template #default="{ row }">
            <div v-if="row.assigneeName" class="assignee-cell">
              <UserAvatar :name="row.assigneeName" :src="row.assigneeAvatar || ''" :size="24" />
              <span>{{ row.assigneeName }}</span>
            </div>
            <span v-else class="text-placeholder">未分配</span>
          </template>
        </el-table-column>
        <el-table-column prop="dueDate" label="截止日期" width="120" sortable="custom">
          <template #default="{ row }">
            <span :class="{ 'text-danger': isOverdue(row.dueDate) && row.status !== 'done' }">
              {{ formatDate(row.dueDate) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="progress" label="进度" width="100">
          <template #default="{ row }">
            <el-progress :percentage="row.progress" :stroke-width="6" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="openDetail(row)">详情</el-button>
            <el-button v-permission="'task:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="queryParams.page"
          v-model:page-size="queryParams.pageSize"
          :total="total"
          :page-sizes="[20, 50, 100]"
          layout="total, sizes, prev, pager, next"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <TaskForm v-if="showForm" v-model="showForm" @created="fetchData" />
    <TaskDetail v-if="showDetail" v-model="showDetail" :task-id="selectedTaskId" @updated="fetchData" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import TaskForm from './TaskForm.vue'
import TaskDetail from './TaskDetail.vue'
import { getTasks, deleteTask } from '@/api/task'
import { getAllProjects } from '@/api/project'
import { formatDate, isOverdue } from '@/utils/date'
import { TASK_STATUS_OPTIONS, TASK_PRIORITY_OPTIONS } from '@/utils/constants'
import type { Task, TaskQueryParams } from '@/types/task'
import type { Project } from '@/types/project'

const tasks = ref<Task[]>([])
const projects = ref<Project[]>([])
const total = ref(0)
const loading = ref(false)
const showForm = ref(false)
const showDetail = ref(false)
const selectedTaskId = ref<number>(0)

const queryParams = reactive<TaskQueryParams>({
  page: 1,
  pageSize: 20,
  keyword: '',
  projectId: undefined,
  status: undefined,
  priority: undefined,
  sortBy: '',
  sortOrder: 'desc',
})

async function fetchData() {
  loading.value = true
  try {
    const res = await getTasks(queryParams)
    tasks.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function resetQuery() {
  queryParams.keyword = ''
  queryParams.projectId = undefined
  queryParams.status = undefined
  queryParams.priority = undefined
  queryParams.page = 1
  fetchData()
}

function handleSortChange({ prop, order }: any) {
  queryParams.sortBy = prop || ''
  queryParams.sortOrder = order === 'ascending' ? 'asc' : 'desc'
  fetchData()
}

function openDetail(task: Task) {
  selectedTaskId.value = task.id
  showDetail.value = true
}

async function handleDelete(task: Task) {
  try {
    await ElMessageBox.confirm(`确定要删除任务「${task.title}」吗？`, '确认', { type: 'warning' })
    await deleteTask(task.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }

.assignee-cell {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.text-placeholder {
  color: $text-placeholder;
  font-size: $font-size-sm;
}

.text-danger {
  color: $danger-color;
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: $spacing-base;
}
</style>
