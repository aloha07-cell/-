<template>
  <el-dialog
    v-model="visible"
    :title="isEdit ? '编辑任务' : '新建任务'"
    width="640px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <el-form ref="formRef" :model="formData" :rules="rules" label-width="100px">
      <el-form-item label="任务标题" prop="title">
        <el-input v-model="formData.title" placeholder="请输入任务标题" maxlength="100" show-word-limit />
      </el-form-item>

      <el-form-item label="任务描述" prop="description">
        <el-input v-model="formData.description" type="textarea" :rows="3" placeholder="请输入任务描述" />
      </el-form-item>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="所属项目" prop="projectId">
            <el-select v-model="formData.projectId" placeholder="请选择项目" style="width: 100%;" :disabled="!!projectId">
              <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="父任务">
            <el-select v-model="formData.parentId" placeholder="无（顶级任务）" clearable style="width: 100%;">
              <el-option v-for="t in parentTasks" :key="t.id" :label="t.wbsCode + ' - ' + t.title" :value="t.id" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="状态" prop="status">
            <el-select v-model="formData.status" style="width: 100%;">
              <el-option v-for="item in TASK_STATUS_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="优先级" prop="priority">
            <el-select v-model="formData.priority" style="width: 100%;">
              <el-option v-for="item in TASK_PRIORITY_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="负责人">
            <el-select v-model="formData.assigneeId" placeholder="请选择" clearable filterable style="width: 100%;">
              <el-option v-for="u in users" :key="u.id" :label="u.nickname || u.username" :value="u.id" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="预估工时">
            <el-input-number v-model="formData.estimatedHours" :min="0" :max="999" :step="0.5" style="width: 100%;" />
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="开始日期">
            <el-date-picker v-model="formData.startDate" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" style="width: 100%;" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="截止日期">
            <el-date-picker v-model="formData.dueDate" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" style="width: 100%;" />
          </el-form-item>
        </el-col>
      </el-row>

      <el-form-item label="标签">
        <el-select v-model="formData.tags" multiple filterable allow-create placeholder="添加标签" style="width: 100%;" />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { createTask } from '@/api/task'
import { getAllProjects } from '@/api/project'
import { getAllUsers } from '@/api/user'
import { TASK_STATUS_OPTIONS, TASK_PRIORITY_OPTIONS } from '@/utils/constants'
import type { User } from '@/types/user'
import type { Project } from '@/types/project'
import type { Task } from '@/types/task'

const props = withDefaults(defineProps<{
  modelValue: boolean
  projectId?: number
  editTask?: Task | null
}>(), {
  projectId: 0,
  editTask: null,
})

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  created: []
  updated: []
}>()

const visible = ref(false)
const formRef = ref<FormInstance>()
const submitting = ref(false)
const projects = ref<Project[]>([])
const users = ref<User[]>([])
const parentTasks = ref<Task[]>([])
const isEdit = ref(false)

watch(() => props.modelValue, (val) => {
  visible.value = val
  if (val) {
    loadData()
    if (props.editTask) {
      isEdit.value = true
      Object.assign(formData, {
        title: props.editTask.title,
        description: props.editTask.description,
        projectId: props.editTask.projectId,
        parentId: props.editTask.parentId,
        status: props.editTask.status,
        priority: props.editTask.priority,
        assigneeId: props.editTask.assigneeId,
        startDate: props.editTask.startDate,
        dueDate: props.editTask.dueDate,
        estimatedHours: props.editTask.estimatedHours,
        tags: props.editTask.tags || [],
      })
    } else {
      isEdit.value = false
      formData.projectId = props.projectId || undefined
    }
  }
})

watch(visible, (val) => {
  emit('update:modelValue', val)
})

const formData = reactive({
  title: '',
  description: '',
  projectId: undefined as number | undefined,
  parentId: undefined as number | undefined,
  status: 'todo' as const,
  priority: 'medium' as const,
  assigneeId: undefined as number | undefined,
  startDate: '',
  dueDate: '',
  estimatedHours: 0,
  tags: [] as string[],
})

const rules: FormRules = {
  title: [{ required: true, message: '请输入任务标题', trigger: 'blur' }],
  projectId: [{ required: true, message: '请选择项目', trigger: 'change' }],
  status: [{ required: true, message: '请选择状态', trigger: 'change' }],
  priority: [{ required: true, message: '请选择优先级', trigger: 'change' }],
}

async function loadData() {
  try {
    const [projectRes, userRes] = await Promise.allSettled([getAllProjects(), getAllUsers()])
    if (projectRes.status === 'fulfilled') projects.value = projectRes.value.data
    if (userRes.status === 'fulfilled') users.value = userRes.value.data
  } catch {
    // silent
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitting.value = true
  try {
    await createTask(formData as any)
    ElMessage.success(isEdit.value ? '更新成功' : '创建成功')
    handleClose()
    emit(isEdit.value ? 'updated' : 'created')
  } catch {
    ElMessage.error(isEdit.value ? '更新失败' : '创建失败')
  } finally {
    submitting.value = false
  }
}

function handleClose() {
  visible.value = false
  formRef.value?.resetFields()
  formData.title = ''
  formData.description = ''
  formData.projectId = undefined
  formData.parentId = undefined
  formData.status = 'todo'
  formData.priority = 'medium'
  formData.assigneeId = undefined
  formData.startDate = ''
  formData.dueDate = ''
  formData.estimatedHours = 0
  formData.tags = []
}
</script>
