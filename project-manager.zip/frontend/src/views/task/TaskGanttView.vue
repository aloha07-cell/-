<template>
  <div class="task-gantt-page page-container">
    <PageHeader title="甘特图">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="选择项目" style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
      </template>
    </PageHeader>

    <div class="gantt-wrapper" v-loading="loading">
      <GanttView v-if="selectedProjectId && tasks.length > 0" :tasks="tasks" @task-click="openTask" />
      <EmptyState v-else description="请选择一个项目查看甘特图" />
    </div>

    <TaskDetail v-if="showDetail" v-model="showDetail" :task-id="selectedTaskId" @updated="loadData" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import GanttView from '@/components/gantt/GanttView.vue'
import TaskDetail from './TaskDetail.vue'
import { useTaskStore } from '@/stores/useTaskStore'
import { getAllProjects } from '@/api/project'
import type { Project } from '@/types/project'
import type { Task } from '@/types/task'

const taskStore = useTaskStore()
const projects = ref<Project[]>([])
const selectedProjectId = ref<number>(0)
const loading = ref(false)
const showDetail = ref(false)
const selectedTaskId = ref<number>(0)

const tasks = ref<Task[]>([])

async function loadData() {
  if (!selectedProjectId.value) return
  loading.value = true
  try {
    const res = await taskStore.fetchTasks({ page: 1, pageSize: 200, projectId: selectedProjectId.value })
    tasks.value = taskStore.tasks
  } finally {
    loading.value = false
  }
}

function openTask(task: Task) {
  selectedTaskId.value = task.id
  showDetail.value = true
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
    if (projects.value.length > 0) {
      selectedProjectId.value = projects.value[0].id
      loadData()
    }
  } catch {
    // silent
  }
})
</script>

<style lang="scss" scoped>
.gantt-wrapper {
  height: calc(100vh - 180px);
  min-height: 400px;
}
</style>
