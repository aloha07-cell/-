<template>
  <div class="task-kanban-page page-container">
    <PageHeader title="看板视图">
      <template #actions>
        <el-select v-model="selectedProjectId" placeholder="选择项目" style="width: 200px; margin-right: 12px;" @change="loadData">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button v-permission="'task:create'" type="primary" @click="showForm = true">
          <el-icon><Plus /></el-icon>新建任务
        </el-button>
      </template>
    </PageHeader>

    <div class="kanban-wrapper" v-loading="loading">
      <KanbanBoard v-if="selectedProjectId" @task-click="openTask" @task-drag="handleDrag" />
      <EmptyState v-else description="请选择一个项目查看看板" />
    </div>

    <TaskForm v-if="showForm" v-model="showForm" :project-id="selectedProjectId" @created="loadData" />
    <TaskDetail v-if="showDetail" v-model="showDetail" :task-id="selectedTaskId" @updated="loadData" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import KanbanBoard from '@/components/kanban/KanbanBoard.vue'
import TaskForm from './TaskForm.vue'
import TaskDetail from './TaskDetail.vue'
import { useTaskStore } from '@/stores/useTaskStore'
import { getAllProjects } from '@/api/project'
import type { Project } from '@/types/project'
import type { Task, TaskDragParams } from '@/types/task'

const taskStore = useTaskStore()
const projects = ref<Project[]>([])
const selectedProjectId = ref<number>(0)
const loading = ref(false)
const showForm = ref(false)
const showDetail = ref(false)
const selectedTaskId = ref<number>(0)

async function loadData() {
  if (!selectedProjectId.value) return
  loading.value = true
  try {
    await Promise.all([
      taskStore.fetchTasks({ page: 1, pageSize: 200, projectId: selectedProjectId.value }),
      taskStore.fetchKanbanData(selectedProjectId.value),
    ])
  } finally {
    loading.value = false
  }
}

function openTask(task: Task) {
  selectedTaskId.value = task.id
  showDetail.value = true
}

async function handleDrag(data: TaskDragParams) {
  await taskStore.drag(data)
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
    if (projects.value.length > 0) {
      selectedProjectId.value = projects.value[0].id
      loadData()
    }
  } catch {
    // silent
  }
})
</script>

<style lang="scss" scoped>
.kanban-wrapper {
  height: calc(100vh - 180px);
  min-height: 400px;
}
</style>
