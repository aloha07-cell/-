<template>
  <el-drawer
    v-model="visible"
    title="任务详情"
    size="500px"
    direction="rtl"
    :close-on-click-modal="false"
  >
    <div v-if="task" class="task-detail">
      <div class="detail-header">
        <h3 class="task-title">{{ task.title }}</h3>
        <div class="task-meta">
          <span class="task-id">#{{ task.id }}</span>
          <StatusTag :status="task.status" type="task" />
          <StatusTag :status="task.priority" type="taskPriority" size="small" />
        </div>
      </div>

      <el-descriptions :column="1" border size="small" class="detail-info">
        <el-descriptions-item label="所属项目">{{ task.projectName }}</el-descriptions-item>
        <el-descriptions-item label="WBS编号">{{ task.wbsCode }}</el-descriptions-item>
        <el-descriptions-item label="负责人">
          <div v-if="task.assigneeName" class="assignee-cell">
            <UserAvatar :name="task.assigneeName" :src="task.assigneeAvatar || ''" :size="24" />
            <span>{{ task.assigneeName }}</span>
          </div>
          <span v-else>未分配</span>
        </el-descriptions-item>
        <el-descriptions-item label="报告人">{{ task.reporterName }}</el-descriptions-item>
        <el-descriptions-item label="开始日期">{{ formatDate(task.startDate) }}</el-descriptions-item>
        <el-descriptions-item label="截止日期">{{ formatDate(task.dueDate) }}</el-descriptions-item>
        <el-descriptions-item label="预估工时">{{ task.estimatedHours }}h</el-descriptions-item>
        <el-descriptions-item label="实际工时">{{ task.actualHours }}h</el-descriptions-item>
      </el-descriptions>

      <div class="detail-section">
        <h4 class="section-title">进度</h4>
        <el-progress :percentage="task.progress" :stroke-width="10" />
      </div>

      <div class="detail-section">
        <h4 class="section-title">描述</h4>
        <div class="task-description">{{ task.description || '暂无描述' }}</div>
      </div>

      <div v-if="task.tags && task.tags.length > 0" class="detail-section">
        <h4 class="section-title">标签</h4>
        <div class="task-tags">
          <el-tag v-for="tag in task.tags" :key="tag" size="small" type="info">{{ tag }}</el-tag>
        </div>
      </div>
    </div>

    <template #footer>
      <el-button @click="visible = false">关闭</el-button>
      <el-button v-permission="'task:edit'" type="primary" @click="handleEdit">编辑</el-button>
    </template>
  </el-drawer>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import StatusTag from '@/components/common/StatusTag.vue'
import UserAvatar from '@/components/common/UserAvatar.vue'
import { getTask } from '@/api/task'
import { formatDate } from '@/utils/date'
import type { Task } from '@/types/task'

const props = defineProps<{
  modelValue: boolean
  taskId: number
}>()

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  updated: []
}>()

const visible = ref(false)
const task = ref<Task | null>(null)

watch(() => props.modelValue, (val) => {
  visible.value = val
  if (val && props.taskId) {
    loadTask()
  }
})

watch(visible, (val) => {
  emit('update:modelValue', val)
})

async function loadTask() {
  try {
    const res = await getTask(props.taskId)
    task.value = res.data
  } catch {
    task.value = null
  }
}

function handleEdit() {
  emit('updated')
}
</script>

<style lang="scss" scoped>
.task-detail {
  padding: $spacing-sm 0;
}

.detail-header {
  margin-bottom: $spacing-lg;
}

.task-title {
  font-size: $font-size-lg;
  font-weight: $font-weight-bold;
  color: $text-primary;
  margin: 0 0 $spacing-sm;
}

.task-meta {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.task-id {
  font-size: $font-size-sm;
  color: $text-secondary;
}

.detail-info {
  margin-bottom: $spacing-lg;
}

.assignee-cell {
  display: flex;
  align-items: center;
  gap: $spacing-sm;
}

.detail-section {
  margin-bottom: $spacing-lg;
}

.section-title {
  font-size: $font-size-base;
  font-weight: $font-weight-medium;
  color: $text-primary;
  margin-bottom: $spacing-sm;
}

.task-description {
  font-size: $font-size-base;
  color: $text-regular;
  line-height: $line-height-base;
  white-space: pre-wrap;
}

.task-tags {
  display: flex;
  flex-wrap: wrap;
  gap: $spacing-sm;
}
</style>
