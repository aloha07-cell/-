<template>
  <div class="worklog-submit-page page-container">
    <PageHeader title="工时填报" />

    <el-card>
      <el-form ref="formRef" :model="formData" :rules="rules" label-width="100px" style="max-width: 600px;">
        <el-form-item label="日期" prop="date">
          <el-date-picker v-model="formData.date" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" style="width: 100%;" />
        </el-form-item>

        <el-form-item label="项目" prop="projectId">
          <el-select v-model="formData.projectId" placeholder="请选择项目" style="width: 100%;" @change="handleProjectChange">
            <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="任务" prop="taskId">
          <el-select v-model="formData.taskId" placeholder="请选择任务" filterable style="width: 100%;" :disabled="!formData.projectId">
            <el-option v-for="t in tasks" :key="t.id" :label="t.title" :value="t.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="工时(h)" prop="hours">
          <el-input-number v-model="formData.hours" :min="0.5" :max="24" :step="0.5" style="width: 100%;" />
        </el-form-item>

        <el-form-item label="描述" prop="description">
          <el-input v-model="formData.description" type="textarea" :rows="3" placeholder="请描述工作内容" maxlength="500" show-word-limit />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="submitting" @click="handleSubmit">提交</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import { createWorklog } from '@/api/worklog'
import { getAllProjects } from '@/api/project'
import { getTasks } from '@/api/task'
import { dayjs } from '@/utils/date'
import type { Project } from '@/types/project'
import type { Task } from '@/types/task'

const router = useRouter()
const formRef = ref<FormInstance>()
const submitting = ref(false)
const projects = ref<Project[]>([])
const tasks = ref<Task[]>([])

const formData = reactive({
  date: dayjs().format('YYYY-MM-DD'),
  projectId: undefined as number | undefined,
  taskId: undefined as number | undefined,
  hours: 8,
  description: '',
})

const rules: FormRules = {
  date: [{ required: true, message: '请选择日期', trigger: 'change' }],
  projectId: [{ required: true, message: '请选择项目', trigger: 'change' }],
  taskId: [{ required: true, message: '请选择任务', trigger: 'change' }],
  hours: [{ required: true, message: '请输入工时', trigger: 'blur' }],
  description: [{ required: true, message: '请输入描述', trigger: 'blur' }],
}

async function handleProjectChange(projectId: number) {
  formData.taskId = undefined
  if (!projectId) {
    tasks.value = []
    return
  }
  try {
    const res = await getTasks({ page: 1, pageSize: 100, projectId })
    tasks.value = res.data.items
  } catch {
    tasks.value = []
  }
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitting.value = true
  try {
    await createWorklog(formData as any)
    ElMessage.success('工时填报成功')
    router.push('/worklogs')
  } catch {
    ElMessage.error('填报失败')
  } finally {
    submitting.value = false
  }
}

function handleReset() {
  formRef.value?.resetFields()
  formData.date = dayjs().format('YYYY-MM-DD')
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
})
</script>
