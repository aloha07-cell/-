<template>
  <div class="worklog-list-page page-container">
    <PageHeader title="工时记录">
      <template #actions>
        <el-button v-permission="'worklog:create'" type="primary" @click="$router.push('/worklogs/submit')">
          <el-icon><Plus /></el-icon>填报工时
        </el-button>
      </template>
    </PageHeader>

    <el-card class="search-card">
      <div class="search-bar">
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 280px;" @change="handleSearch" />
        <el-select v-model="queryParams.projectId" placeholder="项目" clearable style="width: 160px;" @change="handleSearch">
          <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-button type="primary" @click="handleSearch">搜索</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </div>
    </el-card>

    <el-card>
      <el-table :data="worklogs" v-loading="loading" stripe>
        <el-table-column prop="date" label="日期" width="120" />
        <el-table-column prop="projectName" label="项目" width="140" show-overflow-tooltip />
        <el-table-column prop="taskTitle" label="任务" min-width="200" show-overflow-tooltip />
        <el-table-column prop="hours" label="工时(h)" width="90" align="center" />
        <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button v-permission="'worklog:edit'" text type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button v-permission="'worklog:delete'" text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="queryParams.page" v-model:page-size="queryParams.pageSize" :total="total" :page-sizes="[20, 50]" layout="total, sizes, prev, pager, next" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import { getWorklogs, deleteWorklog } from '@/api/worklog'
import { getAllProjects } from '@/api/project'
import type { Worklog, WorklogQueryParams } from '@/types/worklog'
import type { Project } from '@/types/project'

const worklogs = ref<Worklog[]>([])
const projects = ref<Project[]>([])
const total = ref(0)
const loading = ref(false)
const dateRange = ref<string[]>([])

const queryParams = reactive<WorklogQueryParams>({
  page: 1,
  pageSize: 20,
  projectId: undefined,
  dateFrom: '',
  dateTo: '',
})

async function fetchData() {
  loading.value = true
  try {
    if (dateRange.value?.length === 2) {
      queryParams.dateFrom = dateRange.value[0]
      queryParams.dateTo = dateRange.value[1]
    } else {
      queryParams.dateFrom = ''
      queryParams.dateTo = ''
    }
    const res = await getWorklogs(queryParams)
    worklogs.value = res.data.items
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  queryParams.page = 1
  fetchData()
}

function resetQuery() {
  dateRange.value = []
  queryParams.projectId = undefined
  queryParams.page = 1
  fetchData()
}

function handleEdit(_row: Worklog) {
  // navigate to edit
}

async function handleDelete(row: Worklog) {
  try {
    await ElMessageBox.confirm('确定要删除该工时记录吗？', '确认', { type: 'warning' })
    await deleteWorklog(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // cancelled
  }
}

onMounted(async () => {
  try {
    const res = await getAllProjects()
    projects.value = res.data
  } catch {
    // silent
  }
  fetchData()
})
</script>

<style lang="scss" scoped>
.search-card { margin-bottom: $spacing-base; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: $spacing-base; }
</style>
