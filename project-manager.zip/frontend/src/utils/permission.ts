import { useUserStore } from '@/stores/useUserStore'

/** 检查用户是否拥有指定权限 */
export function hasPermission(permission: string | string[]): boolean {
  const userStore = useUserStore()
  const permissions = userStore.permissions || []

  if (Array.isArray(permission)) {
    return permission.some((p) => permissions.includes(p))
  }
  return permissions.includes(permission)
}

/** 检查用户是否拥有所有指定权限 */
export function hasAllPermissions(permissions: string[]): boolean {
  const userStore = useUserStore()
  const userPermissions = userStore.permissions || []
  return permissions.every((p) => userPermissions.includes(p))
}

/** 检查用户是否拥有指定角色 */
export function hasRole(role: string | string[]): boolean {
  const userStore = useUserStore()
  const roles = userStore.roles || []

  if (Array.isArray(role)) {
    return role.some((r) => roles.includes(r))
  }
  return roles.includes(role)
}

/** 检查用户是否为管理员 */
export function isAdmin(): boolean {
  return hasRole('admin') || hasRole('super_admin')
}

/** 检查用户是否为项目负责人 */
export function isProjectOwner(projectOwnerId: number): boolean {
  const userStore = useUserStore()
  return userStore.userInfo?.id === projectOwnerId
}

/** 检查用户是否为任务负责人 */
export function isTaskAssignee(assigneeId: number | null): boolean {
  if (!assigneeId) return false
  const userStore = useUserStore()
  return userStore.userInfo?.id === assigneeId
}
