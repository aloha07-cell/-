import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import 'dayjs/locale/zh-cn'

dayjs.extend(relativeTime)
dayjs.locale('zh-cn')

const DEFAULT_FORMAT = 'YYYY-MM-DD'
const DEFAULT_DATETIME_FORMAT = 'YYYY-MM-DD HH:mm:ss'
const DEFAULT_TIME_FORMAT = 'HH:mm:ss'

export function formatDate(date: string | Date | null | undefined, format: string = DEFAULT_FORMAT): string {
  if (!date) return '-'
  return dayjs(date).format(format)
}

export function formatDateTime(date: string | Date | null | undefined): string {
  return formatDate(date, DEFAULT_DATETIME_FORMAT)
}

export function formatTime(date: string | Date | null | undefined): string {
  return formatDate(date, DEFAULT_TIME_FORMAT)
}

export function formatRelativeTime(date: string | Date | null | undefined): string {
  if (!date) return '-'
  return dayjs(date).fromNow()
}

export function formatDuration(hours: number): string {
  if (!hours && hours !== 0) return '-'
  const h = Math.floor(hours)
  const m = Math.round((hours - h) * 60)
  if (h === 0) return `${m}分钟`
  if (m === 0) return `${h}小时`
  return `${h}小时${m}分钟`
}

export function isToday(date: string | Date): boolean {
  return dayjs(date).isSame(dayjs(), 'day')
}

export function isOverdue(date: string | Date): boolean {
  return dayjs(date).isBefore(dayjs(), 'day')
}

export function daysUntil(date: string | Date): number {
  return dayjs(date).diff(dayjs(), 'day')
}

export function getStartOfWeek(): string {
  return dayjs().startOf('week').format(DEFAULT_FORMAT)
}

export function getEndOfWeek(): string {
  return dayjs().endOf('week').format(DEFAULT_FORMAT)
}

export function getStartOfMonth(): string {
  return dayjs().startOf('month').format(DEFAULT_FORMAT)
}

export function getEndOfMonth(): string {
  return dayjs().endOf('month').format(DEFAULT_FORMAT)
}

export { dayjs }
