const PREFIX = 'pm_'

export function getToken(key: string): string {
  try {
    return localStorage.getItem(PREFIX + key) || ''
  } catch {
    return ''
  }
}

export function setToken(key: string, value: string): void {
  try {
    localStorage.setItem(PREFIX + key, value)
  } catch {
    console.warn('localStorage is not available')
  }
}

export function removeToken(key: string): void {
  try {
    localStorage.removeItem(PREFIX + key)
  } catch {
    console.warn('localStorage is not available')
  }
}

export function getStorage<T = any>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key)
    if (raw === null) return defaultValue
    return JSON.parse(raw) as T
  } catch {
    return defaultValue
  }
}

export function setStorage(key: string, value: any): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value))
  } catch {
    console.warn('localStorage is not available')
  }
}

export function removeStorage(key: string): void {
  try {
    localStorage.removeItem(PREFIX + key)
  } catch {
    console.warn('localStorage is not available')
  }
}

export function clearStorage(): void {
  try {
    const keys = Object.keys(localStorage)
    keys.forEach((key) => {
      if (key.startsWith(PREFIX)) {
        localStorage.removeItem(key)
      }
    })
  } catch {
    console.warn('localStorage is not available')
  }
}
