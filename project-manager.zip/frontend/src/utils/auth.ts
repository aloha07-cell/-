import { getToken as getStorageToken, setToken as setStorageToken, removeToken as removeStorageToken } from './storage'

const ACCESS_TOKEN_KEY = 'access_token'
const REFRESH_TOKEN_KEY = 'refresh_token'
const TOKEN_EXPIRES_KEY = 'token_expires'

export function getAccessToken(): string {
  return getStorageToken(ACCESS_TOKEN_KEY) || ''
}

export function setAccessToken(token: string, expiresIn: number = 86400): void {
  setStorageToken(ACCESS_TOKEN_KEY, token)
  const expiresAt = Date.now() + expiresIn * 1000
  setStorageToken(TOKEN_EXPIRES_KEY, String(expiresAt))
}

export function getRefreshToken(): string {
  return getStorageToken(REFRESH_TOKEN_KEY) || ''
}

export function setRefreshToken(token: string): void {
  setStorageToken(REFRESH_TOKEN_KEY, token)
}

export function removeToken(): void {
  removeStorageToken(ACCESS_TOKEN_KEY)
  removeStorageToken(REFRESH_TOKEN_KEY)
  removeStorageToken(TOKEN_EXPIRES_KEY)
}

export function isTokenExpired(): boolean {
  const expiresAt = Number(getStorageToken(TOKEN_EXPIRES_KEY))
  if (!expiresAt) return true
  return Date.now() >= expiresAt
}

export function getToken(): string {
  return getAccessToken()
}
