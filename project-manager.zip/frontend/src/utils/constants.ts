/** 任务状态选项 */
export const TASK_STATUS_OPTIONS = [
  { label: '待办', value: 'todo', color: '#909399', bgColor: '#f4f4f5' },
  { label: '进行中', value: 'in_progress', color: '#409EFF', bgColor: '#ecf5ff' },
  { label: '审核中', value: 'in_review', color: '#E6A23C', bgColor: '#fdf6ec' },
  { label: '已完成', value: 'done', color: '#67C23A', bgColor: '#f0f9eb' },
  { label: '已取消', value: 'cancelled', color: '#909399', bgColor: '#f4f4f5' },
] as const

/** 任务优先级选项 */
export const TASK_PRIORITY_OPTIONS = [
  { label: '最低', value: 'lowest', color: '#909399', rank: 1 },
  { label: '低', value: 'low', color: '#67C23A', rank: 2 },
  { label: '中', value: 'medium', color: '#E6A23C', rank: 3 },
  { label: '高', value: 'high', color: '#F56C6C', rank: 4 },
  { label: '最高', value: 'highest', color: '#d32f2f', rank: 5 },
] as const

/** 项目状态选项 */
export const PROJECT_STATUS_OPTIONS = [
  { label: '未开始', value: 'not_started', color: '#909399', bgColor: '#f4f4f5' },
  { label: '进行中', value: 'in_progress', color: '#409EFF', bgColor: '#ecf5ff' },
  { label: '暂停', value: 'on_hold', color: '#E6A23C', bgColor: '#fdf6ec' },
  { label: '已完成', value: 'completed', color: '#67C23A', bgColor: '#f0f9eb' },
  { label: '已取消', value: 'cancelled', color: '#909399', bgColor: '#f4f4f5' },
] as const

/** 项目优先级选项 */
export const PROJECT_PRIORITY_OPTIONS = [
  { label: '低', value: 'low', color: '#67C23A' },
  { label: '中', value: 'medium', color: '#E6A23C' },
  { label: '高', value: 'high', color: '#F56C6C' },
  { label: '紧急', value: 'critical', color: '#d32f2f' },
] as const

/** 风险等级选项 */
export const RISK_LEVEL_OPTIONS = [
  { label: '低', value: 'low', color: '#67C23A' },
  { label: '中', value: 'medium', color: '#E6A23C' },
  { label: '高', value: 'high', color: '#F56C6C' },
  { label: '严重', value: 'critical', color: '#d32f2f' },
] as const

/** 风险状态选项 */
export const RISK_STATUS_OPTIONS = [
  { label: '已识别', value: 'identified', color: '#409EFF' },
  { label: '分析中', value: 'analyzing', color: '#E6A23C' },
  { label: '缓解中', value: 'mitigating', color: '#F56C6C' },
  { label: '已解决', value: 'resolved', color: '#67C23A' },
  { label: '已关闭', value: 'closed', color: '#909399' },
] as const

/** 成本类型选项 */
export const COST_TYPE_OPTIONS = [
  { label: '人力成本', value: 'labor' },
  { label: '材料成本', value: 'material' },
  { label: '设备成本', value: 'equipment' },
  { label: '差旅费用', value: 'travel' },
  { label: '外包费用', value: 'outsourcing' },
  { label: '其他', value: 'other' },
] as const

/** 文档类型选项 */
export const DOCUMENT_TYPE_OPTIONS = [
  { label: '需求文档', value: 'requirement' },
  { label: '设计文档', value: 'design' },
  { label: '会议纪要', value: 'meeting' },
  { label: '报告', value: 'report' },
  { label: '计划', value: 'plan' },
  { label: '其他', value: 'other' },
] as const

/** 通知类型选项 */
export const NOTIFICATION_TYPE_OPTIONS = [
  { label: '系统通知', value: 'system' },
  { label: '任务通知', value: 'task' },
  { label: '项目通知', value: 'project' },
  { label: '提及我', value: 'mention' },
  { label: '截止提醒', value: 'deadline' },
  { label: '风险提醒', value: 'risk' },
] as const

/** 用户状态选项 */
export const USER_STATUS_OPTIONS = [
  { label: '活跃', value: 'active', color: '#67C23A' },
  { label: '未激活', value: 'inactive', color: '#909399' },
  { label: '已锁定', value: 'locked', color: '#F56C6C' },
] as const

/** 默认分页大小 */
export const DEFAULT_PAGE_SIZE = 20

/** 分页大小选项 */
export const PAGE_SIZE_OPTIONS = [10, 20, 50, 100]

/** 侧边栏宽度 */
export const SIDEBAR_WIDTH = 220
export const SIDEBAR_COLLAPSED_WIDTH = 64

/** 顶部栏高度 */
export const HEADER_HEIGHT = 56

/** 标签页高度 */
export const TABS_HEIGHT = 40

/** 内容区域内边距 */
export const CONTENT_PADDING = 20

/** 获取任务状态标签 */
export function getTaskStatusLabel(status: string): string {
  const found = TASK_STATUS_OPTIONS.find((item) => item.value === status)
  return found ? found.label : status
}

/** 获取任务状态颜色 */
export function getTaskStatusColor(status: string): string {
  const found = TASK_STATUS_OPTIONS.find((item) => item.value === status)
  return found ? found.color : '#909399'
}

/** 获取任务优先级标签 */
export function getTaskPriorityLabel(priority: string): string {
  const found = TASK_PRIORITY_OPTIONS.find((item) => item.value === priority)
  return found ? found.label : priority
}

/** 获取任务优先级颜色 */
export function getTaskPriorityColor(priority: string): string {
  const found = TASK_PRIORITY_OPTIONS.find((item) => item.value === priority)
  return found ? found.color : '#909399'
}

/** 获取项目状态标签 */
export function getProjectStatusLabel(status: string): string {
  const found = PROJECT_STATUS_OPTIONS.find((item) => item.value === status)
  return found ? found.label : status
}

/** 获取风险等级标签 */
export function getRiskLevelLabel(level: string): string {
  const found = RISK_LEVEL_OPTIONS.find((item) => item.value === level)
  return found ? found.label : level
}

/** 获取成本类型标签 */
export function getCostTypeLabel(type: string): string {
  const found = COST_TYPE_OPTIONS.find((item) => item.value === type)
  return found ? found.label : type
}

/** 获取文档类型标签 */
export function getDocumentTypeLabel(type: string): string {
  const found = DOCUMENT_TYPE_OPTIONS.find((item) => item.value === type)
  return found ? found.label : type
}
