<template>
  <el-container class="layout-container">
    <el-aside :width="appStore.isMobile ? '0px' : (appStore.sidebarCollapsed ? '64px' : '220px')" class="layout-aside">
      <AppSidebar />
    </el-aside>

    <el-container class="layout-main-container">
      <el-header class="layout-header" :height="'56px'">
        <AppHeader />
      </el-header>

      <div v-if="appStore.showBreadcrumb" class="layout-breadcrumb">
        <AppBreadcrumb />
      </div>

      <el-main class="layout-content">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>

    <!-- 移动端遮罩 -->
    <div
      v-if="appStore.isMobile && !appStore.sidebarCollapsed"
      class="mobile-overlay"
      @click="appStore.toggleSidebar"
    />
  </el-container>
</template>

<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue'
import { useAppStore } from '@/stores/useAppStore'
import AppHeader from '@/components/common/AppHeader.vue'
import AppSidebar from '@/components/common/AppSidebar.vue'
import AppBreadcrumb from '@/components/common/AppBreadcrumb.vue'

const appStore = useAppStore()

function handleResize() {
  const isMobile = window.innerWidth < 992
  appStore.setMobile(isMobile)
}

onMounted(() => {
  handleResize()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
})
</script>

<style lang="scss" scoped>
.layout-container {
  height: 100vh;
  overflow: hidden;
}

.layout-aside {
  background-color: #304156;
  transition: width $transition-duration $transition-timing;
  overflow: hidden;
  position: relative;
  z-index: $z-index-sidebar;
}

.layout-main-container {
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.layout-header {
  background: $bg-white;
  border-bottom: 1px solid $border-lighter;
  padding: 0;
  display: flex;
  align-items: center;
  z-index: $z-index-header;
  box-shadow: $shadow-sm;
}

.layout-breadcrumb {
  background: $bg-white;
  padding: $spacing-sm $content-padding;
  border-bottom: 1px solid $border-lighter;
}

.layout-content {
  background: $bg-page;
  overflow-y: auto;
  padding: 0;
}

.mobile-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: $bg-overlay;
  z-index: $z-index-sidebar - 1;
}
</style>
