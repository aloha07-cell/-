import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/useUserStore'
import type { LoginParams } from '@/types/auth'

export function useAuth() {
  const router = useRouter()
  const userStore = useUserStore()

  const isLoggedIn = computed(() => userStore.isLoggedIn)
  const userInfo = computed(() => userStore.userInfo)
  const nickname = computed(() => userStore.nickname)
  const avatar = computed(() => userStore.avatar)
  const loading = computed(() => userStore.loading)

  async function login(params: LoginParams) {
    const data = await userStore.login(params)
    const redirect = (router.currentRoute.value.query.redirect as string) || '/'
    await router.push(redirect)
    return data
  }

  async function logout() {
    await userStore.logout()
    await router.push('/auth/login')
  }

  async function fetchUserInfo() {
    return userStore.fetchUserInfo()
  }

  return {
    isLoggedIn,
    userInfo,
    nickname,
    avatar,
    loading,
    login,
    logout,
    fetchUserInfo,
  }
}
