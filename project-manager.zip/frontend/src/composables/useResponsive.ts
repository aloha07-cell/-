import { ref, onMounted, onUnmounted } from 'vue'

export type Breakpoint = 'xs' | 'sm' | 'md' | 'lg' | 'xl'

const BREAKPOINTS = {
  xs: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
}

export function useResponsive() {
  const width = ref(window.innerWidth)
  const currentBreakpoint = ref<Breakpoint>('xl')

  function getBreakpoint(w: number): Breakpoint {
    if (w < BREAKPOINTS.sm) return 'xs'
    if (w < BREAKPOINTS.md) return 'sm'
    if (w < BREAKPOINTS.lg) return 'md'
    if (w < BREAKPOINTS.xl) return 'lg'
    return 'xl'
  }

  function update() {
    width.value = window.innerWidth
    currentBreakpoint.value = getBreakpoint(width.value)
  }

  const isMobile = ref(width.value < BREAKPOINTS.md)
  const isTablet = ref(width.value >= BREAKPOINTS.md && width.value < BREAKPOINTS.lg)
  const isDesktop = ref(width.value >= BREAKPOINTS.lg)

  let resizeHandler: (() => void) | null = null

  onMounted(() => {
    resizeHandler = () => {
      update()
      isMobile.value = width.value < BREAKPOINTS.md
      isTablet.value = width.value >= BREAKPOINTS.md && width.value < BREAKPOINTS.lg
      isDesktop.value = width.value >= BREAKPOINTS.lg
    }
    window.addEventListener('resize', resizeHandler)
  })

  onUnmounted(() => {
    if (resizeHandler) {
      window.removeEventListener('resize', resizeHandler)
    }
  })

  return {
    width,
    currentBreakpoint,
    isMobile,
    isTablet,
    isDesktop,
    BREAKPOINTS,
  }
}
