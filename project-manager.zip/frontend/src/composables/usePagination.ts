import { ref, reactive, computed } from 'vue'
import type { PaginationParams, PaginatedData } from '@/types/api'
import { DEFAULT_PAGE_SIZE } from '@/utils/constants'

export function usePagination(fetchFn: (params: any) => Promise<PaginatedData>, defaultPageSize: number = DEFAULT_PAGE_SIZE) {
  const pagination = reactive<PaginationParams>({
    page: 1,
    pageSize: defaultPageSize,
  })

  const total = ref(0)
  const loading = ref(false)
  const data = ref<any[]>([])

  const totalPages = computed(() => Math.ceil(total.value / pagination.pageSize))

  async function fetchData(extraParams: Record<string, any> = {}) {
    loading.value = true
    try {
      const res = await fetchFn({ ...pagination, ...extraParams })
      data.value = res.items
      total.value = res.total
      return res
    } finally {
      loading.value = false
    }
  }

  function handlePageChange(page: number) {
    pagination.page = page
    fetchData()
  }

  function handleSizeChange(size: number) {
    pagination.pageSize = size
    pagination.page = 1
    fetchData()
  }

  function reset() {
    pagination.page = 1
    pagination.pageSize = defaultPageSize
    total.value = 0
    data.value = []
  }

  return {
    pagination,
    total,
    totalPages,
    loading,
    data,
    fetchData,
    handlePageChange,
    handleSizeChange,
    reset,
  }
}
