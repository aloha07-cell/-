import { computed } from 'vue'
import { useUserStore } from '@/stores/useUserStore'
import { hasPermission as checkPermission, hasRole as checkRole, isAdmin as checkAdmin } from '@/utils/permission'

export function usePermission() {
  const userStore = useUserStore()

  const permissions = computed(() => userStore.permissions)
  const roles = computed(() => userStore.roles)
  const isAdminUser = computed(() => checkAdmin())

  function hasPermission(permission: string | string[]): boolean {
    return checkPermission(permission)
  }

  function hasRole(role: string | string[]): boolean {
    return checkRole(role)
  }

  function hasAllPermissions(perms: string[]): boolean {
    return perms.every((p) => permissions.value.includes(p))
  }

  return {
    permissions,
    roles,
    isAdminUser,
    hasPermission,
    hasRole,
    hasAllPermissions,
  }
}
