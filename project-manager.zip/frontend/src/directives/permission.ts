import type { Directive, DirectiveBinding } from 'vue'
import { hasPermission } from '@/utils/permission'

const permissionDirective: Directive = {
  mounted(el: HTMLElement, binding: DirectiveBinding<string | string[]>) {
    const { value } = binding
    if (value) {
      const hasAuth = hasPermission(value)
      if (!hasAuth) {
        el.parentNode?.removeChild(el)
      }
    }
  },
  updated(el: HTMLElement, binding: DirectiveBinding<string | string[]>) {
    const { value } = binding
    if (value) {
      const hasAuth = hasPermission(value)
      if (!hasAuth) {
        el.parentNode?.removeChild(el)
      }
    }
  },
}

export default permissionDirective
