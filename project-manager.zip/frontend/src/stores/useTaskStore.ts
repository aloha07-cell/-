import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { getTasks, getTask, createTask, updateTask, deleteTask, dragTask, getKanbanData, getWbsTree, getTaskStats } from '@/api/task'
import type { Task, CreateTaskParams, KanbanData, WbsTreeNode, TaskStats, TaskQueryParams, TaskDragParams } from '@/types/task'

export const useTaskStore = defineStore('task', () => {
  const tasks = ref<Task[]>([])
  const currentTask = ref<Task | null>(null)
  const kanbanData = ref<KanbanData | null>(null)
  const wbsTree = ref<WbsTreeNode[]>([])
  const taskStats = ref<TaskStats | null>(null)
  const total = ref(0)
  const loading = ref(false)

  const tasksByStatus = computed(() => {
    const map: Record<string, Task[]> = {
      todo: [],
      in_progress: [],
      in_review: [],
      done: [],
      cancelled: [],
    }
    tasks.value.forEach((task) => {
      if (map[task.status]) {
        map[task.status].push(task)
      }
    })
    return map
  })

  const taskTree = computed(() => {
    function buildTree(items: Task[], parentId: number | null = null): Task[] {
      return items
        .filter((item) => item.parentId === parentId)
        .map((item) => ({
          ...item,
          children: buildTree(items, item.id),
        }))
        .sort((a, b) => a.order - b.order)
    }
    return buildTree(tasks.value)
  })

  async function fetchTasks(params: TaskQueryParams) {
    loading.value = true
    try {
      const res = await getTasks(params)
      tasks.value = res.data.items
      total.value = res.data.total
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function fetchTask(id: number) {
    loading.value = true
    try {
      const res = await getTask(id)
      currentTask.value = res.data
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function create(data: CreateTaskParams) {
    const res = await createTask(data)
    tasks.value.unshift(res.data)
    return res.data
  }

  async function update(id: number, data: Partial<CreateTaskParams>) {
    const res = await updateTask(id, data)
    const index = tasks.value.findIndex((t) => t.id === id)
    if (index !== -1) {
      tasks.value[index] = res.data
    }
    if (currentTask.value?.id === id) {
      currentTask.value = res.data
    }
    return res.data
  }

  async function remove(id: number) {
    await deleteTask(id)
    tasks.value = tasks.value.filter((t) => t.id !== id)
    if (currentTask.value?.id === id) {
      currentTask.value = null
    }
  }

  async function drag(data: TaskDragParams) {
    const res = await dragTask(data)
    const index = tasks.value.findIndex((t) => t.id === data.taskId)
    if (index !== -1) {
      tasks.value[index] = { ...tasks.value[index], status: data.status, order: data.order }
    }
    return res.data
  }

  async function fetchKanbanData(projectId: number) {
    loading.value = true
    try {
      const res = await getKanbanData(projectId)
      kanbanData.value = res.data
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function fetchWbsTree(projectId: number) {
    loading.value = true
    try {
      const res = await getWbsTree(projectId)
      wbsTree.value = res.data
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function fetchTaskStats(projectId?: number) {
    const res = await getTaskStats(projectId)
    taskStats.value = res.data
    return res.data
  }

  function clearCurrent() {
    currentTask.value = null
  }

  return {
    tasks,
    currentTask,
    kanbanData,
    wbsTree,
    taskStats,
    total,
    loading,
    tasksByStatus,
    taskTree,
    fetchTasks,
    fetchTask,
    create,
    update,
    remove,
    drag,
    fetchKanbanData,
    fetchWbsTree,
    fetchTaskStats,
    clearCurrent,
  }
})
