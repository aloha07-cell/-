import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { getNotifications, markNotificationRead, markAllNotificationsRead, getUnreadCount, getNotificationStats } from '@/api/notification'
import type { Notification, NotificationQueryParams, NotificationStats } from '@/types/notification'

export const useNotificationStore = defineStore('notification', () => {
  const notifications = ref<Notification[]>([])
  const stats = ref<NotificationStats | null>(null)
  const total = ref(0)
  const loading = ref(false)

  const unreadCount = computed(() => stats.value?.unreadCount || 0)

  async function fetchNotifications(params: NotificationQueryParams) {
    loading.value = true
    try {
      const res = await getNotifications(params)
      notifications.value = res.data.items
      total.value = res.data.total
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function fetchUnreadCount() {
    try {
      const res = await getUnreadCount()
      if (stats.value) {
        stats.value.unreadCount = res.data
      } else {
        stats.value = { unreadCount: res.data, totalCount: 0, byType: [] }
      }
      return res.data
    } catch {
      return 0
    }
  }

  async function fetchStats() {
    const res = await getNotificationStats()
    stats.value = res.data
    return res.data
  }

  async function markRead(id: number) {
    await markNotificationRead(id)
    const notification = notifications.value.find((n) => n.id === id)
    if (notification) {
      notification.status = 'read'
    }
    if (stats.value && stats.value.unreadCount > 0) {
      stats.value.unreadCount--
    }
  }

  async function markAllRead() {
    await markAllNotificationsRead()
    notifications.value.forEach((n) => {
      n.status = 'read'
    })
    if (stats.value) {
      stats.value.unreadCount = 0
    }
  }

  return {
    notifications,
    stats,
    total,
    loading,
    unreadCount,
    fetchNotifications,
    fetchUnreadCount,
    fetchStats,
    markRead,
    markAllRead,
  }
})
