import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getProjects, getProject, createProject, updateProject, deleteProject, getProjectMembers, addProjectMember, removeProjectMember, getProjectStats } from '@/api/project'
import type { Project, CreateProjectParams, ProjectMember, ProjectStats, ProjectQueryParams, AddProjectMemberParams } from '@/types/project'

export const useProjectStore = defineStore('project', () => {
  const projects = ref<Project[]>([])
  const currentProject = ref<Project | null>(null)
  const members = ref<ProjectMember[]>([])
  const stats = ref<ProjectStats | null>(null)
  const total = ref(0)
  const loading = ref(false)

  async function fetchProjects(params: ProjectQueryParams) {
    loading.value = true
    try {
      const res = await getProjects(params)
      projects.value = res.data.items
      total.value = res.data.total
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function fetchProject(id: number) {
    loading.value = true
    try {
      const res = await getProject(id)
      currentProject.value = res.data
      return res.data
    } finally {
      loading.value = false
    }
  }

  async function create(data: CreateProjectParams) {
    const res = await createProject(data)
    return res.data
  }

  async function update(id: number, data: Partial<CreateProjectParams>) {
    const res = await updateProject(id, data)
    if (currentProject.value?.id === id) {
      currentProject.value = res.data
    }
    return res.data
  }

  async function remove(id: number) {
    await deleteProject(id)
    projects.value = projects.value.filter((p) => p.id !== id)
    if (currentProject.value?.id === id) {
      currentProject.value = null
    }
  }

  async function fetchMembers(projectId: number) {
    const res = await getProjectMembers(projectId)
    members.value = res.data
    return res.data
  }

  async function addMember(data: AddProjectMemberParams) {
    const res = await addProjectMember(data)
    members.value.push(res.data)
    return res.data
  }

  async function removeMember(projectId: number, userId: number) {
    await removeProjectMember(projectId, userId)
    members.value = members.value.filter((m) => m.userId !== userId)
  }

  async function fetchStats() {
    const res = await getProjectStats()
    stats.value = res.data
    return res.data
  }

  function clearCurrent() {
    currentProject.value = null
    members.value = []
  }

  return {
    projects,
    currentProject,
    members,
    stats,
    total,
    loading,
    fetchProjects,
    fetchProject,
    create,
    update,
    remove,
    fetchMembers,
    addMember,
    removeMember,
    fetchStats,
    clearCurrent,
  }
})
