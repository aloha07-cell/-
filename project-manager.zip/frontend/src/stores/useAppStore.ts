import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { getStorage, setStorage } from '@/utils/storage'

const APP_SETTINGS_KEY = 'app_settings'

interface AppSettings {
  sidebarCollapsed: boolean
  theme: 'light' | 'dark'
  language: string
  showBreadcrumb: boolean
  showTagsView: boolean
}

const defaultSettings: AppSettings = {
  sidebarCollapsed: false,
  theme: 'light',
  language: 'zh-CN',
  showBreadcrumb: true,
  showTagsView: false,
}

export const useAppStore = defineStore('app', () => {
  const savedSettings = getStorage<AppSettings>(APP_SETTINGS_KEY, defaultSettings)

  const sidebarCollapsed = ref(savedSettings.sidebarCollapsed)
  const theme = ref<'light' | 'dark'>(savedSettings.theme)
  const language = ref(savedSettings.language)
  const showBreadcrumb = ref(savedSettings.showBreadcrumb)
  const showTagsView = ref(savedSettings.showTagsView)
  const isMobile = ref(false)

  const sidebarWidth = computed(() => (sidebarCollapsed.value ? 64 : 220))

  function toggleSidebar() {
    sidebarCollapsed.value = !sidebarCollapsed.value
    saveSettings()
  }

  function setSidebarCollapsed(value: boolean) {
    sidebarCollapsed.value = value
    saveSettings()
  }

  function setTheme(newTheme: 'light' | 'dark') {
    theme.value = newTheme
    document.documentElement.setAttribute('data-theme', newTheme)
    saveSettings()
  }

  function setLanguage(lang: string) {
    language.value = lang
    saveSettings()
  }

  function setMobile(value: boolean) {
    isMobile.value = value
    if (value) {
      sidebarCollapsed.value = true
    }
  }

  function saveSettings() {
    setStorage(APP_SETTINGS_KEY, {
      sidebarCollapsed: sidebarCollapsed.value,
      theme: theme.value,
      language: language.value,
      showBreadcrumb: showBreadcrumb.value,
      showTagsView: showTagsView.value,
    })
  }

  return {
    sidebarCollapsed,
    theme,
    language,
    showBreadcrumb,
    showTagsView,
    isMobile,
    sidebarWidth,
    toggleSidebar,
    setSidebarCollapsed,
    setTheme,
    setLanguage,
    setMobile,
  }
})
