import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { login as loginApi, logout as logoutApi, getCurrentUser } from '@/api/auth'
import { setAccessToken, setRefreshToken, removeToken, getAccessToken } from '@/utils/auth'
import { getStorage, setStorage, removeStorage } from '@/utils/storage'
import type { LoginParams, CurrentUser } from '@/types/auth'

const USER_INFO_KEY = 'user_info'

export const useUserStore = defineStore('user', () => {
  const token = ref<string>(getAccessToken())
  const userInfo = ref<CurrentUser | null>(getStorage<CurrentUser | null>(USER_INFO_KEY, null))
  const loading = ref(false)

  const isLoggedIn = computed(() => !!token.value)
  const roles = computed(() => userInfo.value?.roles || [])
  const permissions = computed(() => userInfo.value?.permissions || [])
  const nickname = computed(() => userInfo.value?.nickname || userInfo.value?.username || '')
  const avatar = computed(() => userInfo.value?.avatar || '')

  async function login(params: LoginParams) {
    loading.value = true
    try {
      const res = await loginApi(params)
      const data = res.data
      token.value = data.accessToken
      setAccessToken(data.accessToken, data.expiresIn)
      setRefreshToken(data.refreshToken)

      await fetchUserInfo()

      if (params.remember) {
        setStorage('remember_login', JSON.stringify({ username: params.username }))
      } else {
        removeStorage('remember_login')
      }

      return data
    } finally {
      loading.value = false
    }
  }

  async function fetchUserInfo() {
    try {
      const res = await getCurrentUser()
      userInfo.value = res.data
      setStorage(USER_INFO_KEY, res.data)
    } catch {
      userInfo.value = null
      removeStorage(USER_INFO_KEY)
    }
  }

  async function logout() {
    try {
      await logoutApi()
    } catch {
      // ignore
    }
    token.value = ''
    userInfo.value = null
    removeToken()
    removeStorage(USER_INFO_KEY)
  }

  function hasPermission(permission: string | string[]): boolean {
    const perms = permissions.value
    if (Array.isArray(permission)) {
      return permission.some((p) => perms.includes(p))
    }
    return perms.includes(permission)
  }

  function hasRole(role: string | string[]): boolean {
    const userRoles = roles.value
    if (Array.isArray(role)) {
      return role.some((r) => userRoles.includes(r))
    }
    return userRoles.includes(role)
  }

  return {
    token,
    userInfo,
    loading,
    isLoggedIn,
    roles,
    permissions,
    nickname,
    avatar,
    login,
    logout,
    fetchUserInfo,
    hasPermission,
    hasRole,
  }
})
