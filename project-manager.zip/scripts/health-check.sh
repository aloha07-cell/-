#!/bin/bash
# ============================================
# 健康检查脚本
# 用法: bash scripts/health-check.sh
# ============================================

set -euo pipefail

# ============================================
# 配置
# ============================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 从.env文件加载环境变量
if [ -f "${PROJECT_DIR}/.env" ]; then
    export $(grep -v '^#' "${PROJECT_DIR}/.env" | grep -v '^$' | xargs)
fi

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 结果统计
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0

# ============================================
# 函数
# ============================================

log_info() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# 检查Docker服务状态
check_docker_service() {
    local service_name="$1"
    local container_name="$2"
    local description="$3"

    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

    echo -n "检查 ${description} (${container_name})... "

    if ! docker ps --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log_error "容器未运行"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi

    # 检查容器健康状态
    local health_status
    health_status=$(docker inspect --format='{{.State.Health.Status}}' "${container_name}" 2>/dev/null || echo "none")

    if [ "$health_status" = "healthy" ]; then
        log_info "运行正常 (healthy)"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    elif [ "$health_status" = "none" ]; then
        log_info "运行中 (无健康检查)"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    elif [ "$health_status" = "starting" ]; then
        log_warn "启动中..."
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        log_error "状态异常 (${health_status})"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
}

# 检查MySQL
check_mysql() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查 MySQL 连接... "

    local mysql_host="${MYSQL_HOST:-mysql}"
    local mysql_port="${MYSQL_PORT:-3306}"
    local mysql_password="${MYSQL_ROOT_PASSWORD:-root123456}"

    if docker exec pm-mysql mysqladmin ping -h localhost -u root -p"${mysql_password}" --silent 2>/dev/null; then
        log_info "连接正常"

        # 检查数据库是否存在
        TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
        echo -n "检查数据库 project_manager... "
        local db_exists
        db_exists=$(docker exec pm-mysql mysql -u root -p"${mysql_password}" -sN -e "SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='project_manager'" 2>/dev/null || echo "0")

        if [ "$db_exists" -gt 0 ]; then
            log_info "数据库存在"

            # 检查表数量
            TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
            echo -n "检查数据表... "
            local table_count
            table_count=$(docker exec pm-mysql mysql -u root -p"${mysql_password}" -sN -e "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='project_manager'" 2>/dev/null || echo "0")

            if [ "$table_count" -gt 0 ]; then
                log_info "${table_count} 张表已初始化"
                PASSED_CHECKS=$((PASSED_CHECKS + 1))
            else
                log_warn "数据库为空，请运行初始化脚本"
                PASSED_CHECKS=$((PASSED_CHECKS + 1))
            fi
        else
            log_error "数据库不存在"
            FAILED_CHECKS=$((FAILED_CHECKS + 1))
        fi

        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        log_error "连接失败"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
}

# 检查Redis
check_redis() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查 Redis 连接... "

    local redis_password="${REDIS_PASSWORD:-redis123}"

    if docker exec pm-redis redis-cli -a "${redis_password}" ping 2>/dev/null | grep -q "PONG"; then
        log_info "连接正常"

        # 检查内存使用
        TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
        echo -n "检查 Redis 内存... "
        local used_memory
        used_memory=$(docker exec pm-redis redis-cli -a "${redis_password}" info memory 2>/dev/null | grep "used_memory_human:" | cut -d: -f2 | tr -d '\r' || echo "N/A")
        log_info "已用内存: ${used_memory}"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        log_error "连接失败"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
}

# 检查MinIO
check_minio() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查 MinIO 服务... "

    local minio_endpoint="${MINIO_ENDPOINT:-minio:9000}"

    if docker exec pm-minio curl -s -o /dev/null -w "%{http_code}" "http://localhost:9000/minio/health/live" 2>/dev/null | grep -q "200\|403"; then
        log_info "服务正常"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        log_error "服务异常"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
}

# 检查后端API
check_backend() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查后端 API (http://localhost:8000)... "

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:8000/api/health" 2>/dev/null || echo "000")

    if [ "$http_code" = "200" ]; then
        log_info "API 正常 (HTTP ${http_code})"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    elif [ "$http_code" = "000" ]; then
        log_error "无法连接"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    else
        log_warn "API 返回 HTTP ${http_code}"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    fi
}

# 检查Nginx
check_nginx() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查 Nginx (http://localhost:80)... "

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:80" 2>/dev/null || echo "000")

    if [ "$http_code" = "200" ] || [ "$http_code" = "301" ] || [ "$http_code" = "302" ]; then
        log_info "Nginx 正常 (HTTP ${http_code})"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    elif [ "$http_code" = "000" ]; then
        log_error "无法连接"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    else
        log_warn "Nginx 返回 HTTP ${http_code}"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    fi
}

# 检查磁盘空间
check_disk_space() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "检查磁盘空间... "

    local disk_usage
    disk_usage=$(df -h "${PROJECT_DIR}" | awk 'NR==2 {print $5}' | tr -d '%')

    if [ -n "$disk_usage" ] && [ "$disk_usage" -lt 90 ]; then
        log_info "已用 ${disk_usage}%"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    elif [ -n "$disk_usage" ]; then
        log_warn "磁盘使用率 ${disk_usage}%，建议清理"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        log_error "无法获取磁盘信息"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
}

# ============================================
# 主流程
# ============================================
main() {
    echo "=========================================="
    echo "项目管理系统 - 健康检查"
    echo "=========================================="
    echo ""

    # 检查Docker是否运行
    if ! docker info &> /dev/null; then
        echo -e "${RED}[ERROR]${NC} Docker 未运行，请先启动 Docker"
        exit 1
    fi

    # 检查Docker Compose服务
    check_docker_service "mysql" "pm-mysql" "MySQL"
    check_docker_service "redis" "pm-redis" "Redis"
    check_docker_service "minio" "pm-minio" "MinIO"
    check_docker_service "backend" "pm-backend" "后端服务"
    check_docker_service "frontend" "pm-frontend" "前端服务"
    check_docker_service "nginx" "pm-nginx" "Nginx"

    echo ""

    # 深度检查
    check_mysql
    check_redis
    check_minio
    check_backend
    check_nginx
    check_disk_space

    # 输出汇总
    echo ""
    echo "=========================================="
    echo "检查结果汇总"
    echo "=========================================="
    echo -e "总计: ${TOTAL_CHECKS} 项检查"
    echo -e "${GREEN}通过: ${PASSED_CHECKS}${NC}"
    echo -e "${RED}失败: ${FAILED_CHECKS}${NC}"
    echo "=========================================="

    if [ "$FAILED_CHECKS" -gt 0 ]; then
        exit 1
    fi

    exit 0
}

main "$@"
