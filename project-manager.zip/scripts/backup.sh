#!/bin/bash
# ============================================
# 数据库备份脚本
# 用法: bash scripts/backup.sh
# ============================================

set -euo pipefail

# ============================================
# 配置
# ============================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKUP_DIR="${PROJECT_DIR}/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/backup_${TIMESTAMP}.sql.gz"
RETENTION_DAYS=30

# 从.env文件加载环境变量
if [ -f "${PROJECT_DIR}/.env" ]; then
    export $(grep -v '^#' "${PROJECT_DIR}/.env" | grep -v '^$' | xargs)
fi

# 数据库配置（带默认值）
MYSQL_HOST="${MYSQL_HOST:-mysql}"
MYSQL_PORT="${MYSQL_PORT:-3306}"
MYSQL_USER="${MYSQL_ROOT_PASSWORD:-root}"
MYSQL_PASSWORD="${MYSQL_ROOT_PASSWORD:-root123456}"
MYSQL_DATABASE="${MYSQL_DATABASE:-project_manager}"

# ============================================
# 函数
# ============================================

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" >&2
}

# 检查依赖
check_dependencies() {
    if ! command -v mysqldump &> /dev/null; then
        error "mysqldump 未找到，请安装 mysql-client"
        exit 1
    fi

    if ! command -v gzip &> /dev/null; then
        error "gzip 未找到"
        exit 1
    fi
}

# 创建备份目录
create_backup_dir() {
    if [ ! -d "$BACKUP_DIR" ]; then
        mkdir -p "$BACKUP_DIR"
        log "创建备份目录: $BACKUP_DIR"
    fi
}

# 执行备份
do_backup() {
    log "开始备份数据库: ${MYSQL_DATABASE}"

    # 尝试Docker方式备份
    if docker ps --format '{{.Names}}' | grep -q "pm-mysql"; then
        log "通过Docker容器执行备份..."
        docker exec pm-mysql mysqldump \
            -u root \
            -p"${MYSQL_PASSWORD}" \
            --single-transaction \
            --routines \
            --triggers \
            --events \
            --set-gtid-purged=OFF \
            "${MYSQL_DATABASE}" 2>/dev/null | gzip > "${BACKUP_FILE}"
    else
        # 直接连接备份
        mysqldump \
            -h "${MYSQL_HOST}" \
            -P "${MYSQL_PORT}" \
            -u root \
            -p"${MYSQL_PASSWORD}" \
            --single-transaction \
            --routines \
            --triggers \
            --events \
            "${MYSQL_DATABASE}" 2>/dev/null | gzip > "${BACKUP_FILE}"
    fi

    if [ -f "${BACKUP_FILE}" ]; then
        FILE_SIZE=$(du -h "${BACKUP_FILE}" | cut -f1)
        log "备份成功: ${BACKUP_FILE} (${FILE_SIZE})"

        # 生成MD5校验
        if command -v md5sum &> /dev/null; then
            md5sum "${BACKUP_FILE}" > "${BACKUP_FILE}.md5"
            log "MD5校验文件已生成"
        fi
    else
        error "备份失败"
        exit 1
    fi
}

# 清理过期备份
cleanup_old_backups() {
    log "清理 ${RETENTION_DAYS} 天前的备份文件..."
    DELETED_COUNT=0

    while IFS= read -r -d '' file; do
        rm -f "$file"
        rm -f "${file}.md5"
        DELETED_COUNT=$((DELETED_COUNT + 1))
    done < <(find "${BACKUP_DIR}" -name "backup_*.sql.gz" -mtime +${RETENTION_DAYS} -print0 2>/dev/null)

    log "已清理 ${DELETED_COUNT} 个过期备份"
}

# ============================================
# 主流程
# ============================================
main() {
    log "=========================================="
    log "项目管理系统 - 数据库备份"
    log "=========================================="

    check_dependencies
    create_backup_dir
    do_backup
    cleanup_old_backups

    log "=========================================="
    log "备份完成"
    log "=========================================="
}

main "$@"
