#!/usr/bin/env python3
"""
初始化脚本 - 创建MinIO Bucket、管理员账户等初始化操作
用法: python scripts/init-data.py
"""

import os
import sys
import logging
import time
from urllib.parse import urlparse
from urllib.request import urlopen, Request
from urllib.error import URLError

# 添加backend到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)


def get_env(key: str, default: str = "") -> str:
    """从环境变量获取值"""
    return os.environ.get(key, default)


def wait_for_service(url: str, timeout: int = 60, interval: int = 3) -> bool:
    """等待服务可用"""
    logger.info(f"等待服务启动: {url}")
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            req = Request(url, method='GET')
            with urlopen(req, timeout=5) as resp:
                if resp.status < 500:
                    logger.info(f"服务已就绪: {url}")
                    return True
        except (URLError, OSError):
            pass
        time.sleep(interval)
    logger.error(f"服务启动超时: {url}")
    return False


def create_minio_bucket():
    """创建MinIO Bucket"""
    endpoint = get_env("MINIO_ENDPOINT", "minio:9000")
    access_key = get_env("MINIO_ROOT_USER", "minioadmin")
    secret_key = get_env("MINIO_ROOT_PASSWORD", "minioadmin123")
    bucket_name = get_env("MINIO_BUCKET", "project-manager")

    logger.info(f"正在创建MinIO Bucket: {bucket_name}")

    try:
        import subprocess
        # 使用mc命令行工具创建bucket
        # 先配置mc别名
        subprocess.run([
            "mc", "alias", "set", "local",
            f"http://{endpoint}",
            access_key,
            secret_key
        ], check=True, capture_output=True)

        # 创建bucket
        result = subprocess.run([
            "mc", "mb", "--ignore-existing", f"local/{bucket_name}"
        ], capture_output=True, text=True)

        if result.returncode == 0:
            logger.info(f"Bucket '{bucket_name}' 创建成功")
        else:
            logger.warning(f"Bucket创建返回: {result.stderr}")

        # 设置bucket策略为公开读
        subprocess.run([
            "mc", "anonymous", "set", "download", f"local/{bucket_name}"
        ], capture_output=True, text=True)
        logger.info(f"Bucket '{bucket_name}' 策略设置完成")

    except FileNotFoundError:
        logger.warning("mc命令未找到，请安装MinIO Client (mc)")
        logger.info("可手动执行以下命令创建Bucket:")
        logger.info(f"  mc alias set local http://{endpoint} {access_key} {secret_key}")
        logger.info(f"  mc mb --ignore-existing local/{bucket_name}")
        logger.info(f"  mc anonymous set download local/{bucket_name}")
    except subprocess.CalledProcessError as e:
        logger.error(f"MinIO Bucket创建失败: {e.stderr}")


def check_mysql_connection():
    """检查MySQL连接"""
    db_url = get_env("DATABASE_URL", "mysql+asyncmy://pm_user:pm123456@localhost:3306/project_manager")
    logger.info(f"检查MySQL连接...")

    try:
        import pymysql
        # 解析数据库URL
        parsed = urlparse(db_url.replace("mysql+asyncmy://", "mysql://"))
        host = parsed.hostname or "localhost"
        port = parsed.port or 3306
        user = parsed.username or "pm_user"
        password = parsed.password or "pm123456"
        database = parsed.path.lstrip("/") or "project_manager"

        connection = pymysql.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database,
            connect_timeout=10
        )
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            if result:
                logger.info("MySQL连接成功")

                # 检查表是否已初始化
                cursor.execute("SHOW TABLES")
                tables = cursor.fetchall()
                logger.info(f"数据库中已有 {len(tables)} 张表")

        connection.close()
        return True
    except ImportError:
        logger.warning("pymysql未安装，跳过MySQL连接检查")
        return True
    except Exception as e:
        logger.error(f"MySQL连接失败: {e}")
        return False


def check_redis_connection():
    """检查Redis连接"""
    redis_url = get_env("REDIS_URL", "redis://localhost:6379/0")
    logger.info("检查Redis连接...")

    try:
        import redis
        r = redis.from_url(redis_url)
        r.ping()
        logger.info("Redis连接成功")
        info = r.info("memory")
        logger.info(f"Redis已用内存: {info.get('used_memory_human', 'N/A')}")
        return True
    except ImportError:
        logger.warning("redis包未安装，跳过Redis连接检查")
        return True
    except Exception as e:
        logger.error(f"Redis连接失败: {e}")
        return False


def create_admin_user():
    """创建管理员账户"""
    logger.info("创建管理员账户...")

    try:
        from app.utils.database import async_session_factory
        from app.models.user import User
        from app.models.role import Role
        from app.core.security import hash_password
        import asyncio

        async def create_admin():
            async with async_session_factory() as session:
                try:
                    # 检查是否已有管理员账户
                    from sqlalchemy import select
                    result = await session.execute(
                        select(User).where(User.username == "admin")
                    )
                    existing_admin = result.scalar_one_or_none()

                    if existing_admin:
                        logger.info("管理员账户已存在，跳过创建")
                        return

                    # 创建管理员角色
                    admin_role = Role(
                        name="admin",
                        display_name="管理员",
                        description="系统管理员角色",
                        permissions="*"
                    )
                    session.add(admin_role)
                    await session.flush()

                    # 创建管理员用户
                    admin_user = User(
                        username="admin",
                        email="admin@example.com",
                        full_name="系统管理员",
                        password=hash_password("admin123"),
                        role_id=admin_role.id,
                        is_active=True,
                        is_superuser=True
                    )
                    session.add(admin_user)
                    await session.commit()

                    logger.info("管理员账户创建成功！")
                    logger.info("默认登录信息:")
                    logger.info("  用户名: admin@example.com")
                    logger.info("  密码: admin123")
                    logger.info("  请在生产环境修改默认密码")

                except Exception as e:
                    await session.rollback()
                    logger.error(f"创建管理员账户失败: {e}")

        asyncio.run(create_admin())
        return True
    except ImportError as e:
        logger.warning(f"导入模块失败: {e}")
        logger.info("请确保已安装所有依赖并正确配置环境")
        return False
    except Exception as e:
        logger.error(f"创建管理员账户失败: {e}")
        return False


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("项目管理系统 - 数据初始化")
    logger.info("=" * 60)

    # 检查MySQL连接
    if check_mysql_connection():
        # 创建管理员账户
        create_admin_user()

    # 检查Redis连接
    check_redis_connection()

    # 尝试创建MinIO Bucket
    try:
        create_minio_bucket()
    except Exception as e:
        logger.warning(f"MinIO初始化失败: {e}")
        logger.info("MinIO为可选组件，系统仍可正常运行")

    logger.info("=" * 60)
    logger.info("初始化完成")
    logger.info("=" * 60)
    logger.info("系统访问地址:")
    logger.info("  - 后端API: http://localhost:8000/api/v1")
    logger.info("  - API文档: http://localhost:8000/api/v1/docs")
    logger.info("  - 前端: http://localhost:3000")


if __name__ == "__main__":
    main()
