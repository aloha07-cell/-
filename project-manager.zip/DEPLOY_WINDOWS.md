# 项目管理系统 - Windows 部署指南

## 📋 部署方式

本项目提供两种部署方式：

1. **自动部署**（推荐）：使用 `deploy_windows.bat` 脚本自动检测环境并部署
2. **手动部署**：按照步骤手动操作

## 🚀 自动部署（推荐）

### 1. 前置条件

- **Windows 10/11** 操作系统
- **Docker Desktop** 已安装并启动
- **Git** 已安装（用于代码克隆）

### 2. 操作步骤

1. **克隆项目代码**
   ```bash
   git clone https://github.com/your-repo/project-manager.git
   cd project-manager
   ```

2. **运行部署脚本**
   - 双击运行 `deploy_windows.bat` 文件
   - 脚本会自动：
     - 检查 Docker Desktop 是否已安装
     - 检查 Git 是否已安装
     - 验证项目目录
     - 自动创建 .env 文件（如果不存在）
     - 启动 Docker 服务
     - 等待服务初始化
     - 显示服务状态

3. **访问系统**
   脚本运行完成后，会显示访问地址：
   - 前端：http://localhost
   - 后端 API：http://localhost/api/v1
   - API 文档：http://localhost/api/v1/docs
   - MinIO 控制台：http://localhost:9001

4. **默认登录信息**
   - 用户名：admin@example.com
   - 密码：admin123

## ⚙️ 手动部署

### 1. 安装依赖

- **安装 Docker Desktop**：https://www.docker.com/products/docker-desktop
- **安装 Git**：https://git-scm.com/downloads

### 2. 克隆项目

```bash
git clone https://github.com/your-repo/project-manager.git
cd project-manager
```

### 3. 配置环境变量

复制 `.env.example` 文件为 `.env` 并根据需要修改配置：

```bash
copy .env.example .env
```

### 4. 启动服务

```bash
docker-compose up -d
```

### 5. 等待服务初始化

首次启动时，需要等待：
- Docker 拉取镜像（约5-10分钟，取决于网络速度）
- 数据库初始化（约1-2分钟）
- 服务启动（约1-2分钟）

### 6. 检查服务状态

```bash
docker-compose ps
```

### 7. 访问系统

- 前端：http://localhost
- 后端 API：http://localhost/api/v1
- API 文档：http://localhost/api/v1/docs
- MinIO 控制台：http://localhost:9001

## 🔧 常见问题

### 1. Docker 启动失败
- **问题**：脚本提示 "Docker 命令无法执行"
- **解决方案**：
  - 确保 Docker Desktop 已启动
  - 检查系统是否有足够的内存（建议至少4GB）
  - 重启 Docker Desktop

### 2. 端口冲突
- **问题**：服务启动失败，提示端口被占用
- **解决方案**：
  - 检查是否有其他服务占用了 80、3306、6379、8000、9000、9001 端口
  - 修改 `docker-compose.yml` 中的端口映射

### 3. 数据库连接失败
- **问题**：后端服务无法连接到数据库
- **解决方案**：
  - 等待数据库完全初始化（首次启动需要时间）
  - 检查 `.env` 文件中的数据库配置

### 4. 服务无法访问
- **问题**：浏览器无法访问系统
- **解决方案**：
  - 检查 Docker 服务是否正在运行
  - 检查防火墙是否阻止了端口访问
  - 等待服务完全启动（首次启动需要时间）

## 📁 项目结构

```
project-manager/
├── backend/          # 后端代码（FastAPI）
├── frontend/         # 前端代码（Vue 3）
├── mysql/            # MySQL 配置
├── nginx/            # Nginx 配置
├── redis/            # Redis 配置
├── scripts/          # 脚本文件
├── deploy_windows.bat  # Windows 部署脚本
├── docker-compose.yml  # Docker 编排文件
└── .env.example       # 环境变量示例
```

## 📞 技术支持

如果遇到部署问题，请联系技术支持：
- 邮箱：support@example.com
- 文档：https://docs.example.com

---

**注意**：本部署指南适用于开发和测试环境。生产环境部署时，请修改 `.env` 文件中的敏感配置，如密码、密钥等。